import os
import json
import torch
import numpy as np
import pickle
import re
import gc
from transformers import AutoModelForCausalLM, AutoTokenizer
import torch.nn.functional as F

# ================= 配置区域 =================
# 模型路径
MODEL_PATH = "/WORK/PUBLIC/dongyinp_work/lingp/models/Qwen3-4B-Thinking-2507"
# 输入数据 (Pickle)
INPUT_PKL_FILE = "aime2024_cot_results_new_now.pkl"
# Ground Truth 文件
GT_DATA_FILE = "aime2024.jsonl"
# 输出结果文件
OUTPUT_FILE = "aime2024_full_analysis_metrics_4000.jsonl"

# 配置：最大计算 Token 数 (只计算 CoT 的前 N 个 Token)
MAX_CALC_TOKENS = 4000 

GROUP_SIZE = 5
CPU_LAYER_CACHE = {}

# ================= 工具函数 =================

def normalize_answer(ans):
    """标准化答案，用于比对正确性"""
    if ans is None: return ""
    ans = str(ans).strip()
    ans = ans.replace(r"\boxed", "").replace("{", "").replace("}", "")
    try:
        val = float(ans)
        if val.is_integer(): return str(int(val))
        return str(val)
    except ValueError:
        pass 
    ans = ans.replace(" ", "")
    ans = re.sub(r"\\[a-zA-Z]+", "", ans) 
    ans = re.sub(r"[^0-9a-zA-Z\.]", "", ans).lower()
    return ans

def clean_cot_content(text):
    """清洗模型输出中可能的复读机或格式错误内容"""
    if not text: return ""
    match = re.search(r'\\boxed\{', text)
    if not match: return text
    
    start_idx = match.start()
    content_start = start_idx + 7
    balance = 1
    end_idx = -1
    
    for i in range(content_start, len(text)):
        if text[i] == '{': balance += 1
        elif text[i] == '}': balance -= 1
        if balance == 0:
            end_idx = i + 1
            break
            
    if end_idx != -1:
        return text[:end_idx]
    return text

def load_ground_truth_as_list():
    """加载标准答案"""
    gt_list = []
    print(f"📖 Loading Ground Truth from {GT_DATA_FILE}...")
    if not os.path.exists(GT_DATA_FILE): return []
    with open(GT_DATA_FILE, 'r', encoding='utf-8') as f:
        for line in f:
            if line.strip():
                try:
                    item = json.loads(line)
                    ans = item.get("answer") or item.get("Answer")
                    pid = str(item.get("ID") or item.get("id"))
                    gt_list.append({"id": pid, "answer": str(ans) if ans else ""})
                except: continue
    print(f"✅ Loaded {len(gt_list)} ground truth records.")
    return gt_list

def load_inference_results():
    """加载推理结果 (Pickle)"""
    results = []
    print(f"📦 Loading inference results from {INPUT_PKL_FILE}...")
    if not os.path.exists(INPUT_PKL_FILE): return results
    try:
        with open(INPUT_PKL_FILE, 'rb') as f:
            try:
                data = pickle.load(f)
                if isinstance(data, list): results = data
                else:
                    results.append(data)
                    while True:
                        try: results.append(pickle.load(f))
                        except EOFError: break
            except Exception:
                f.seek(0)
                while True:
                    try: results.append(pickle.load(f))
                    except EOFError: break
    except Exception as e:
        print(f"⚠️ Error reading pickle: {e}")
    print(f"✅ Loaded {len(results)} total inference chains.")
    return results

def calculate_metrics_cpu(layer_dict, attention_mask_cpu):
    """
    计算两种 Metric:
    Method 1: Layer Mean -> Diff/Angle
    Method 2: Layer-wise Diff/Angle -> Mean
    """
    sorted_keys = sorted(layer_dict.keys())
    if not sorted_keys: return None

    # Stack layers: [Num_Layers, Seq_Len, Hidden_Dim]
    stacked_layers = torch.stack([layer_dict[k] for k in sorted_keys], dim=0)
    
    # 准备 Mask
    if attention_mask_cpu.dim() == 1: attention_mask_cpu = attention_mask_cpu.unsqueeze(0)
    # valid_mask shape: [Seq_Len-1] (对应 t 和 t-1 的关系)
    valid_mask = (attention_mask_cpu[:, 1:] == 1).reshape(-1)

    # ================= Method 1: Mean then Metric =================
    # [Seq_Len, Hidden_Dim]
    avg_hidden_states = torch.mean(stacked_layers, dim=0)
    if avg_hidden_states.dim() == 2: avg_hidden_states = avg_hidden_states.unsqueeze(0)
    
    curr_m1 = avg_hidden_states[:, 1:, :]
    prev_m1 = avg_hidden_states[:, :-1, :]
    
    # Diff Norm 1
    diff_norms_1 = torch.norm(curr_m1 - prev_m1, p=2, dim=-1).reshape(-1)
    
    # Angle 1
    cos_sim_1 = F.cosine_similarity(curr_m1, prev_m1, dim=-1, eps=1e-8)
    cos_sim_1 = torch.clamp(cos_sim_1, -1.0 + 1e-7, 1.0 - 1e-7)
    angles_1 = torch.rad2deg(torch.acos(cos_sim_1)).reshape(-1)

    # ================= Method 2: Metric then Mean =================
    # 使用 stacked_layers: [Num_Layers, Seq_Len, Hidden_Dim]
    curr_layers = stacked_layers[:, 1:, :] # [L, S-1, D]
    prev_layers = stacked_layers[:, :-1, :] # [L, S-1, D]
    
    # Diff Norm 2 (Layer-wise)
    # 计算每一层的 diff: [L, S-1]
    diff_layerwise = torch.norm(curr_layers - prev_layers, p=2, dim=-1)
    # 对层取平均 -> [S-1]
    diff_norms_2 = torch.mean(diff_layerwise, dim=0).reshape(-1)
    
    # Angle 2 (Layer-wise)
    # 计算每一层的 cos: [L, S-1]
    cos_layerwise = F.cosine_similarity(curr_layers, prev_layers, dim=-1, eps=1e-8)
    cos_layerwise = torch.clamp(cos_layerwise, -1.0 + 1e-7, 1.0 - 1e-7)
    ang_layerwise = torch.rad2deg(torch.acos(cos_layerwise))
    # 对层取平均 -> [S-1]
    angles_2 = torch.mean(ang_layerwise, dim=0).reshape(-1)

    # 清理大张量显存/内存
    del stacked_layers, curr_layers, prev_layers, diff_layerwise, ang_layerwise, avg_hidden_states
    
    # 应用 Mask 并返回
    return (
        diff_norms_1[valid_mask].tolist(),
        angles_1[valid_mask].tolist(),
        diff_norms_2[valid_mask].tolist(),
        angles_2[valid_mask].tolist()
    )

def get_layer_output_hook(layer_idx):
    def hook(module, input, output):
        # 捕获并缓存每一层的输出，转到CPU以节省显存
        CPU_LAYER_CACHE[layer_idx] = output[0].detach().cpu().to(torch.float32)
    return hook

# ================= 主流程 =================

def main():
    gt_list = load_ground_truth_as_list()
    inference_data = load_inference_results()
    if not inference_data: return

    print(f"🔧 Loading Model: {MODEL_PATH}")
    # 加载模型，使用 bfloat16 加速
    model = AutoModelForCausalLM.from_pretrained(
        MODEL_PATH, 
        device_map="auto", 
        torch_dtype=torch.bfloat16, 
        trust_remote_code=True
    ).eval()
    
    tokenizer = AutoTokenizer.from_pretrained(MODEL_PATH, trust_remote_code=True)
    if tokenizer.pad_token is None: tokenizer.pad_token = tokenizer.eos_token
        
    # 注册 Hook
    layers = model.model.layers if hasattr(model, "model") else model.layers
    hooks = [layer.register_forward_hook(get_layer_output_hook(i)) for i, layer in enumerate(layers)]
    
    print(f"🚀 Starting Optimized Analysis (Truncating input to first {MAX_CALC_TOKENS} CoT tokens) -> Output: {OUTPUT_FILE}")
    
    # 清空或创建输出文件
    with open(OUTPUT_FILE, 'w', encoding='utf-8') as f: pass
    
    correct_count = 0
    with open(OUTPUT_FILE, 'a', encoding='utf-8') as f_out:
        for i, item in enumerate(inference_data):
            problem_idx = i // GROUP_SIZE
            cot_idx = i % GROUP_SIZE
            
            # 获取 Ground Truth
            if problem_idx < len(gt_list):
                gt_ans = gt_list[problem_idx]['answer']
            else:
                gt_ans = ""
            
            display_id = item.get('ID', 'Unknown')
            
            print("-" * 80)
            print(f"[{i+1}/{len(inference_data)}] Prob {problem_idx+1} (ID: {display_id}) | CoT {cot_idx}")

            CPU_LAYER_CACHE.clear()
            torch.cuda.empty_cache()

            try:
                # 1. 准备 Prompt 和 原始 CoT 文本
                question = item['question']
                instruction = f"{question}\n\nPlease reason step by step and put your final answer within \\boxed{{}}."
                prompt_text = f"<|im_start|>user\n{instruction}<|im_end|>\n<|im_start|>assistant\n"
                
                raw_cot = item['cot_inference']
                cleaned_cot = clean_cot_content(raw_cot)
                
                # 2. 【关键优化】分离 Tokenize 并截断
                #    使用 add_special_tokens=False 手动拼接
                prompt_ids = tokenizer.encode(prompt_text, add_special_tokens=False)
                cot_ids = tokenizer.encode(cleaned_cot, add_special_tokens=False)
                
                prompt_len = len(prompt_ids)
                cot_len_original = len(cot_ids)
                
                # 核心逻辑：直接截取前 MAX_CALC_TOKENS 个 CoT token
                cot_ids_truncated = cot_ids[:MAX_CALC_TOKENS]
                cot_len_calc = len(cot_ids_truncated)
                
                print(f"   [Length] Original CoT: {cot_len_original} -> Truncated Input: {cot_len_calc} tokens")

                # 拼接 input_ids (Prompt + Truncated CoT)
                # 注意：这里我们重新构造了 Tensor，只包含我们想计算的部分
                full_input_ids = prompt_ids + cot_ids_truncated
                input_tensor = torch.tensor([full_input_ids], dtype=torch.long).to(model.device)
                attention_mask = torch.ones_like(input_tensor).to(model.device)
                
                # 3. 提取答案用于判断正确性 (使用原始完整文本判断，不影响正确率计算)
                cot_preview = cleaned_cot[:100].replace("\n", "\\n")
                model_ans = item.get('cot_answer', "")
                print(f"   CoT Preview: \"{cot_preview}...\"")
                print(f"   Model: \"{model_ans}\" | GT: \"{gt_ans}\"")
                
                is_correct = False
                if gt_ans:
                    if normalize_answer(model_ans) == normalize_answer(gt_ans):
                        is_correct = True
                        correct_count += 1

                # 4. 模型前向传播 (Forward Pass)
                #    只计算截断后的短序列，极大节省显存和时间
                with torch.no_grad():
                    model(input_ids=input_tensor, attention_mask=attention_mask)
                
                # 5. 计算 Metrics
                metrics_result = calculate_metrics_cpu(CPU_LAYER_CACHE, attention_mask.cpu())
                
                avg_d1, avg_a1 = 0.0, 0.0
                avg_d2, avg_a2 = 0.0, 0.0

                if metrics_result:
                    d_norms_1, angs_1, d_norms_2, angs_2 = metrics_result
                    
                    # start_pos 设置为 prompt_len - 1
                    # 索引含义：metrics[i] 表示 token[i] 和 token[i+1] 之间的变化 (或者 i 和 i-1，取决于具体实现)
                    # 在 calculate_metrics_cpu 中，metrics 对应 valid_mask (attention_mask[:, 1:])
                    # 所以 metrics[k] 对应 input_ids[k+1] 相对于 input_ids[k] 的变化。
                    # 我们希望从 CoT 的第一个 token 开始统计。
                    # CoT 第一个 token 在 input_ids 中的索引是 prompt_len。
                    # 它相对于前一个 token (Prompt 最后一个 token) 的变化，对应的 metrics 索引是 prompt_len - 1。
                    start_pos = max(0, prompt_len - 1)
                    
                    # 截取 CoT 部分的指标
                    cot_d1 = d_norms_1[start_pos:]
                    cot_a1 = angs_1[start_pos:]
                    
                    cot_d2 = d_norms_2[start_pos:]
                    cot_a2 = angs_2[start_pos:]
                    
                    # 计算平均值
                    avg_d1 = float(np.mean(cot_d1)) if cot_d1 else 0.0
                    avg_a1 = float(np.mean(cot_a1)) if cot_a1 else 0.0
                    avg_d2 = float(np.mean(cot_d2)) if cot_d2 else 0.0
                    avg_a2 = float(np.mean(cot_a2)) if cot_a2 else 0.0
                    
                    calc_len = len(cot_d1)
                else:
                    calc_len = 0
                
                print(f"   -> Result: Correct={is_correct}")
                print(f"      M1 (Calc on {calc_len} toks): AvgDiff={avg_d1:.4f} | AvgAngle={avg_a1:.4f}")
                print(f"      M2 (Calc on {calc_len} toks): AvgDiff={avg_d2:.4f} | AvgAngle={avg_a2:.4f}")

                record = {
                    "unique_index": f"{problem_idx}_{cot_idx}",
                    "problem_index": problem_idx,
                    "ID": display_id,
                    "cot_index": cot_idx,
                    "is_correct": is_correct,
                    "model_answer": model_ans,
                    "ground_truth": gt_ans,
                    "avg_diff_norm_1": avg_d1,
                    "avg_angle_1": avg_a1,
                    "avg_diff_norm_2": avg_d2,
                    "avg_angle_2": avg_a2,
                    "calc_token_count": calc_len
                }
                f_out.write(json.dumps(record, ensure_ascii=False) + "\n")
                f_out.flush()

            except Exception as e:
                import traceback
                traceback.print_exc()
                print(f"❌ Error on index {i}: {e}")
                
    for h in hooks: h.remove()
    print("=" * 80)
    print(f"✅ Full Analysis Completed. Overall Accuracy: {correct_count}/{len(inference_data)}")

if __name__ == "__main__":
    main()