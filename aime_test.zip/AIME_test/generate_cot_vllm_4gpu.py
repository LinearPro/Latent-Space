import json
import os
import re
from vllm import LLM, SamplingParams

# ================= 配置区域 =================

# 模型路径
MODEL_PATH = "/WORK/PUBLIC/dongyinp_work/lingp/models/Qwen3-4B-Thinking-2507"

# 输入文件 (AIME 题目)
INPUT_FILE = "aime2024.jsonl"

# 输出文件
OUTPUT_FILE = "aime2024_cot_20_samples_ids_5_26_29_30.jsonl"

# 需要处理的目标题目 ID
TARGET_IDS = ["5", "26", "29", "30"]

# 生成配置
NUM_SAMPLES = 20        # 每题生成 20 条
MAX_TOKENS = 81920       # 最大 Token 数
SEED = 42               # 固定随机数种子，保证复现
TEMPERATURE = 0.6       # 温度
REPETITION_PENALTY = 1.05 

# 【核心修改】并行配置
# 设置为 4 以利用 4 张 A800
TENSOR_PARALLEL_SIZE = 4 

# ===========================================

def load_target_problems(file_path, target_ids):
    """加载指定 ID 的题目"""
    problems = []
    if not os.path.exists(file_path):
        print(f"Error: Input file {file_path} not found.")
        return []
    
    with open(file_path, 'r', encoding='utf-8') as f:
        for line in f:
            if not line.strip(): continue
            try:
                item = json.loads(line)
                curr_id = str(item.get('ID'))
                if curr_id in target_ids:
                    problems.append(item)
            except json.JSONDecodeError:
                continue
    return problems

def normalize_answer(ans):
    """标准化答案格式"""
    if ans is None: return ""
    ans_str = str(ans).strip()
    ans_str = re.sub(r'\\text\{([^}]+)\}', r'\1', ans_str)
    if ans_str.endswith('.0'):
        ans_str = ans_str[:-2]
    return ans_str

def extract_boxed_answer(text):
    """提取 \boxed{...} 内容"""
    matches = re.findall(r'\\boxed\{([^}]+)\}', text)
    if matches:
        return matches[-1].strip()
    return None

def main():
    # 1. 加载题目
    print(f"Loading problems from {INPUT_FILE}...")
    problems = load_target_problems(INPUT_FILE, TARGET_IDS)
    print(f"Found {len(problems)} target problems (IDs: {TARGET_IDS}).")
    
    if not problems:
        print("No problems found. Exiting.")
        return

    # 2. 初始化 vLLM (4卡并行)
    print(f"Initializing LLM from {MODEL_PATH} with TP={TENSOR_PARALLEL_SIZE}...")
    llm = LLM(
        model=MODEL_PATH, 
        tensor_parallel_size=TENSOR_PARALLEL_SIZE, # 修改这里
        trust_remote_code=True,
        gpu_memory_utilization=0.8 # A800 显存很大，可以适当调高
    )

    # 3. 设置采样参数
    sampling_params = SamplingParams(
        n=NUM_SAMPLES,
        temperature=TEMPERATURE,
        top_p=0.95,
        max_tokens=MAX_TOKENS,
        seed=SEED,
        stop=["<|im_end|>", "<|endoftext|>"], 
        repetition_penalty=REPETITION_PENALTY
    )

    # 4. 构建 Prompts
    prompts = []
    problem_map = [] 

    for p in problems:
        q = p.get('question', '')
        # 强制要求使用 \boxed{}
        prompt_text = (
            "<|im_start|>user\n"
            f"{q}\n\n"
            "Please reason step by step and put your final answer within \\boxed{}.\n"
            "<|im_start|>assistant\n"
        )
        prompts.append(prompt_text)
        problem_map.append(p)

    # 5. 批量生成
    print(f"Generating {len(prompts)} problems x {NUM_SAMPLES} samples on 4 GPUs...")
    outputs = llm.generate(prompts, sampling_params)

    # 6. 保存结果
    print(f"Saving results to {OUTPUT_FILE}...")
    with open(OUTPUT_FILE, 'w', encoding='utf-8') as f_out:
        for problem_info, output in zip(problem_map, outputs):
            p_id = str(problem_info.get('ID'))
            ground_truth = normalize_answer(problem_info.get('answer'))
            
            for i, sequence in enumerate(output.outputs):
                gen_text = sequence.text
                token_ids = sequence.token_ids
                token_count = len(token_ids)
                
                extracted = extract_boxed_answer(gen_text)
                
                is_correct = False
                if extracted:
                    norm_extracted = normalize_answer(extracted)
                    if norm_extracted == ground_truth:
                        is_correct = True
                
                record = {
                    "id": p_id,
                    "sample_index": i,
                    "question": problem_info.get('question'),
                    "ground_truth": ground_truth,
                    "model_answer_raw": extracted,
                    "is_correct": is_correct,
                    "token_count": token_count,
                    "response": gen_text
                }
                
                f_out.write(json.dumps(record, ensure_ascii=False) + "\n")

    print("Done!")

if __name__ == "__main__":
    main()