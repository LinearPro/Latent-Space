import os
import json
import pickle
from transformers import AutoTokenizer

# ================= 配置区域 =================
# 请确保此路径指向您本地正确的 Qwen 模型文件夹
MODEL_PATH = "/WORK/PUBLIC/dongyinp_work/lingp/models/Qwen3-4B-Thinking-2507"

# 输入文件路径
PKL_FILE = "aime2024_cot_results_new_now.pkl"

# 指标文件路径 (请确保这些文件存在)
METRIC_FILES = {
    '2000': 'aime2024_full_analysis_metrics_2000.jsonl',
    '4000': 'aime2024_full_analysis_metrics_4000.jsonl',
    '8000': 'aime2024_analysis_filtered_8000.jsonl',
    'all':  'aime2024_full_analysis_metrics_all.jsonl'
}

# 输出报告文件
OUTPUT_REPORT = "aime2024_semantic_trend_target_only.txt"

# 仅处理这些题目 Index (用于加速)
TARGET_INDICES = [2, 4, 25, 28, 29]

# 每一组题目的 CoT 数量
GROUP_SIZE = 5

# 文本查看窗口大小 (查看切分点前后多少个 token 的文本)
WINDOW_SIZE = 60

# ================= 工具函数 =================

def load_metrics_map(filepath):
    """
    快速加载指标文件到内存字典中。
    Key: unique_index (e.g., "2_0"), Value: data dict
    """
    data_map = {}
    if not os.path.exists(filepath):
        print(f"⚠️ 警告: 找不到文件 {filepath}，该阶段指标将缺失。")
        return data_map
    
    with open(filepath, 'r', encoding='utf-8') as f:
        for line in f:
            if line.strip():
                try:
                    item = json.loads(line)
                    uid = item.get('unique_index')
                    if uid:
                        data_map[uid] = item
                except:
                    pass
    return data_map

def load_pkl_generator(filepath):
    """
    使用生成器加载 PKL 数据，节省内存。
    """
    if not os.path.exists(filepath):
        print(f"❌ 错误: 找不到 PKL 文件 {filepath}")
        return
    
    with open(filepath, 'rb') as f:
        while True:
            try:
                data = pickle.load(f)
                if isinstance(data, list):
                    for item in data:
                        yield item
                else:
                    yield data
            except EOFError:
                break
            except Exception as e:
                print(f"⚠️ 读取 PKL 出错: {e}")
                break

def get_context_text(tokenizer, full_token_ids, target_pos, window=50):
    """
    获取指定 Token 位置附近的文本内容。
    """
    if target_pos > len(full_token_ids):
        return "[已结束] (长度不足)"
    
    # 确定截取范围
    start_idx = max(0, target_pos - window)
    end_idx = min(len(full_token_ids), target_pos + window)
    
    # 解码
    text_prev = tokenizer.decode(full_token_ids[start_idx:target_pos], skip_special_tokens=True)
    text_curr = tokenizer.decode(full_token_ids[target_pos:end_idx], skip_special_tokens=True)
    
    # 格式化输出，移除换行符以便在一行显示
    clean_prev = text_prev.replace('\n', ' ').replace('\r', '')
    clean_curr = text_curr.replace('\n', ' ').replace('\r', '')
    
    return f"...{clean_prev} 【Token {target_pos}】 {clean_curr}..."

# ================= 主流程 =================

def main():
    # 1. 加载 Tokenizer
    print("🚀 正在加载 Tokenizer (只需加载一次)...")
    try:
        tokenizer = AutoTokenizer.from_pretrained(MODEL_PATH, trust_remote_code=True)
    except Exception as e:
        print(f"❌ 无法加载 Tokenizer: {e}")
        return

    # 2. 预加载所有阶段的指标数据 (内存占用很小)
    print("📊 正在预加载各阶段指标数据...")
    metrics_db = {}
    for stage, path in METRIC_FILES.items():
        metrics_db[stage] = load_metrics_map(path)
        print(f"   - {stage}: 加载了 {len(metrics_db[stage])} 条记录")

    # 3. 开始处理并生成报告
    print(f"📝 开始处理 PKL 并生成报告 (仅处理 Indices: {TARGET_INDICES})...")
    
    processed_count = 0
    
    with open(OUTPUT_REPORT, 'w', encoding='utf-8') as f_out:
        f_out.write(f"AIME 2024 Metric & Semantic Evolution Analysis\n")
        f_out.write(f"Targets: {TARGET_INDICES}\n")
        f_out.write("==================================================\n\n")

        # 遍历原始数据
        # 使用 enumerate 来追踪当前的全局索引，从而计算 problem_index
        for global_idx, item in enumerate(load_pkl_generator(PKL_FILE)):
            
            # 计算当前题目编号
            problem_idx = global_idx // GROUP_SIZE
            cot_idx = global_idx % GROUP_SIZE
            unique_index = f"{problem_idx}_{cot_idx}"

            # 【核心优化】如果不属于目标题目，直接跳过！
            # 不进行 Tokenize，也不进行文件写入，速度极快
            if problem_idx not in TARGET_INDICES:
                continue

            processed_count += 1
            print(f"   正在分析: Problem {problem_idx} - CoT {cot_idx}...")

            # 获取 Prompt 和 CoT 文本
            question = item.get('question', "")
            raw_cot = item.get('cot_inference', "")
            
            # 构造完整的输入以对齐 Token Index (需要和计算指标时的逻辑一致)
            instruction = f"{question}\n\nPlease reason step by step and put your final answer within \\boxed{{}}."
            prompt_text = f"<|im_start|>user\n{instruction}<|im_end|>\n<|im_start|>assistant\n"
            
            # Tokenize (这是最耗时的步骤，现在只对目标题目执行)
            # 注意：add_special_tokens=False 因为我们需要手动拼接
            prompt_ids = tokenizer.encode(prompt_text, add_special_tokens=False)
            cot_ids = tokenizer.encode(raw_cot, add_special_tokens=False)
            
            # 指标文件中的 index 是相对于 CoT 开始的 (因为计算 metrics 时切片了)
            # 但 Token 长度通常指包含 Prompt 的长度吗？
            # 回顾之前的代码： `cot_d1 = d_norms_1[start_pos:][:MAX_CALC_TOKENS]`
            # 这意味着 metrics 的 index 0 对应 CoT 的第 1 个 token。
            # 所以 2000, 4000, 8000 指的是 CoT 生成部分的长度。
            
            # 从 'all' 阶段获取元数据 (如是否正确)
            # 如果 'all' 里没有，尝试其他阶段
            base_meta = metrics_db['all'].get(unique_index) or \
                        metrics_db['8000'].get(unique_index) or \
                        metrics_db['2000'].get(unique_index)
            
            display_id = base_meta.get('ID', str(problem_idx+1)) if base_meta else str(problem_idx+1)
            is_correct = base_meta.get('is_correct', False) if base_meta else "Unknown"
            status_mark = "✅ CORRECT" if is_correct is True else "❌ INCORRECT"

            # 写入报告头
            f_out.write(f"Problem Index: {problem_idx} (ID: {display_id}) | CoT: {cot_idx} | {status_mark}\n")
            f_out.write("-" * 80 + "\n")

            # 定义要分析的四个检查点
            checkpoints = [
                ('2000', 2000), 
                ('4000', 4000), 
                ('8000', 8000), 
                ('all', len(cot_ids)) # All 对应最后位置
            ]

            for stage_name, token_pos in checkpoints:
                # 获取该阶段的指标
                meta = metrics_db[stage_name].get(unique_index)
                
                # 获取该位置的文本上下文
                # 注意：token_pos 是相对于 CoT 开始的位置
                context_str = get_context_text(tokenizer, cot_ids, token_pos, WINDOW_SIZE)
                
                # 格式化指标字符串
                if meta:
                    m1_str = f"Diff1={meta.get('avg_diff_norm_1', 0):.2f}, Ang1={meta.get('avg_angle_1', 0):.2f}"
                    m2_str = f"Diff2={meta.get('avg_diff_norm_2', 0):.2f}, Ang2={meta.get('avg_angle_2', 0):.2f}"
                else:
                    m1_str = "Metrics: N/A"
                    m2_str = "Metrics: N/A"
                    if stage_name != 'all' and token_pos > len(cot_ids):
                        context_str = "(CoT已结束)"

                f_out.write(f"  🔹 [Stage {stage_name}] @ Token {token_pos}\n")
                f_out.write(f"     {m1_str} | {m2_str}\n")
                f_out.write(f"     💬 Context: {context_str}\n\n")
            
            f_out.write("\n") # 题目间空行

    print("=" * 60)
    print(f"✅ 处理完成！")
    print(f"共分析了 {processed_count} 条数据 (Indices: {TARGET_INDICES})")
    print(f"报告已保存至: {os.path.abspath(OUTPUT_REPORT)}")

if __name__ == "__main__":
    main()