import json
import os
import re
from vllm import LLM, SamplingParams

# ================= Configuration Area =================

# Model Path
MODEL_PATH = "/WORK/PUBLIC/dongyinp_work/lingp/models/Qwen3-4B-Thinking-2507"

# Input File (AIME 2025 Problems)
INPUT_FILE = "aime2025.jsonl"

# Output File (Updated name to reflect all samples)
OUTPUT_FILE = "aime2025_cot_all_samples1.jsonl"

# Generation Configuration
NUM_SAMPLES = 1        # Generate 20 samples per problem
MAX_TOKENS = 81920       # Max tokens
SEED = 42                # Fixed seed for reproducibility
TEMPERATURE = 0        # Temperature
REPETITION_PENALTY = 1.00 

# Parallel Configuration
# Set to 4 to utilize 4 A800 GPUs
TENSOR_PARALLEL_SIZE = 4 

# ======================================================

def load_all_problems(file_path):
    """Load all problems from the file without filtering by ID"""
    problems = []
    if not os.path.exists(file_path):
        print(f"Error: Input file {file_path} not found.")
        return []
    
    with open(file_path, 'r', encoding='utf-8') as f:
        for line in f:
            if not line.strip(): continue
            try:
                item = json.loads(line)
                # Ensure the item has at least an ID and a Question
                if 'ID' in item and 'question' in item:
                    problems.append(item)
            except json.JSONDecodeError:
                continue
    return problems

def normalize_answer(ans):
    """Normalize answer format for comparison"""
    if ans is None: return ""
    ans_str = str(ans).strip()
    ans_str = re.sub(r'\\text\{([^}]+)\}', r'\1', ans_str)
    if ans_str.endswith('.0'):
        ans_str = ans_str[:-2]
    return ans_str

def extract_boxed_answer(text):
    """Extract content inside \boxed{...}"""
    matches = re.findall(r'\\boxed\{([^}]+)\}', text)
    if matches:
        return matches[-1].strip()
    return None

def main():
    # 1. Load Problems
    print(f"Loading problems from {INPUT_FILE}...")
    # Changed to load ALL problems
    problems = load_all_problems(INPUT_FILE)
    print(f"Found {len(problems)} total problems.")
    
    if not problems:
        print("No problems found. Exiting.")
        return

    # 2. Initialize vLLM (4-GPU Parallel)
    print(f"Initializing LLM from {MODEL_PATH} with TP={TENSOR_PARALLEL_SIZE}...")
    llm = LLM(
        model=MODEL_PATH, 
        tensor_parallel_size=TENSOR_PARALLEL_SIZE, 
        trust_remote_code=True,
        gpu_memory_utilization=0.8, # Increased slightly for efficiency
        max_model_len=MAX_TOKENS # Ensure model context length is sufficient
    )

    # 3. Set Sampling Parameters
    sampling_params = SamplingParams(
        n=NUM_SAMPLES,
        temperature=TEMPERATURE,
        top_p=0.95,
        max_tokens=MAX_TOKENS,
        seed=SEED,
        stop=["<|im_end|>", "<|endoftext|>"], 
        repetition_penalty=REPETITION_PENALTY
    )

    # 4. Construct Prompts
    prompts = []
    problem_map = [] 

    for p in problems:
        q = p.get('question', '')
        # Force the model to use \boxed{}
        prompt_text = (
            "<|im_start|>user\n"
            f"{q}\n\n"
            "Please reason step by step and put your final answer within \\boxed{}.\n"
            "<|im_start|>assistant\n"
        )
        prompts.append(prompt_text)
        problem_map.append(p)

    # 5. Batch Generation
    print(f"Generating {len(prompts)} problems x {NUM_SAMPLES} samples on {TENSOR_PARALLEL_SIZE} GPUs...")
    outputs = llm.generate(prompts, sampling_params)

    # 6. Save Results
    print(f"Saving results to {OUTPUT_FILE}...")
    with open(OUTPUT_FILE, 'w', encoding='utf-8') as f_out:
        # Iterate over problems and their corresponding outputs
        for problem_info, output in zip(problem_map, outputs):
            p_id = str(problem_info.get('ID'))
            # Use 'answer' or 'Target' depending on dataset format
            ground_truth_raw = problem_info.get('answer') or problem_info.get('Target')
            ground_truth = normalize_answer(ground_truth_raw)
            
            # Iterate over the N samples generated for this problem
            for i, sequence in enumerate(output.outputs):
                gen_text = sequence.text
                token_ids = sequence.token_ids
                token_count = len(token_ids)
                
                extracted = extract_boxed_answer(gen_text)
                
                is_correct = False
                if extracted:
                    norm_extracted = normalize_answer(extracted)
                    if norm_extracted == ground_truth:
                        is_correct = True
                
                record = {
                    "id": p_id,
                    "sample_index": i,
                    "question": problem_info.get('question'),
                    "ground_truth": ground_truth,
                    "model_answer_raw": extracted,
                    "is_correct": is_correct,
                    "token_count": token_count,
                    "response": gen_text
                }
                
                f_out.write(json.dumps(record, ensure_ascii=False) + "\n")

    print("Done!")

if __name__ == "__main__":
    main()