import os
import json
import torch
import numpy as np
import random
import re
import gc
from tqdm import tqdm
from scipy.stats import zscore
from vllm import LLM, SamplingParams
from transformers import AutoModelForCausalLM, AutoTokenizer
from vllm.distributed.parallel_state import destroy_model_parallel

# ================= 配置区域 =================

MODEL_PATH = "/WORK/PUBLIC/dongyinp_work/lingp/models/Qwen3-4B-Thinking-2507"
INPUT_FILE = "aime2025.jsonl"
OUTPUT_FILE = "aime2025_cot_labeled_20samples1.jsonl"
INTERMEDIATE_FILE = "aime2025_cot_intermediate_labeled1.jsonl"

CANDIDATE_POOL_SIZE = 20
TOP_CUT = CANDIDATE_POOL_SIZE // 2 

PREFIX_LEN = 8000           
MAX_TOTAL_LEN = 81920  # 注意：32k通常是该模型的上限，设81920可能会OOM，这里保守调整
W_DECEL = 1.5  
W_FRIC  = 1.2  
W_CONV  = 1.0  
GLOBAL_SEED = 42

# ================= 工具函数 =================

def set_global_seed(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed(seed)
        torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False
    print(f"🔒 Global seed set to {seed}")

def clean_gpu():
    gc.collect()
    torch.cuda.empty_cache()
    try:
        import torch.distributed as dist
        if dist.is_initialized():
            dist.destroy_process_group()
    except:
        pass

def normalize_answer(ans):
    """
    增强版答案标准化，处理 LaTeX 和格式差异
    """
    if ans is None: return ""
    ans_str = str(ans).strip()
    # 移除 \boxed{}
    ans_str = re.sub(r'\\boxed\{([^}]+)\}', r'\1', ans_str)
    # 移除 \text{}
    ans_str = re.sub(r'\\text\{([^}]+)\}', r'\1', ans_str)
    # 移除 $ 符号
    ans_str = ans_str.replace('$', '')
    # 处理 .0 结尾
    if ans_str.endswith('.0'): ans_str = ans_str[:-2]
    return ans_str.strip()

def calculate_dual_metrics(hidden_states, seq_len):
    """ 计算 Macro/Micro 动力学指标 (保持原逻辑) """
    num_layers = len(hidden_states)
    checkpoints = [2000, 4000, 8000]
    window = 100
    results = {}
    
    for cp in checkpoints:
        if cp > seq_len:
            results[cp] = None
            continue
            
        start = max(0, cp - window)
        end = min(seq_len, cp + window)
        
        layer_tensors = [hidden_states[l][0, start:end, :].float() for l in range(num_layers)]
        stack = torch.stack(layer_tensors, dim=0) 
        
        # --- Micro Metrics ---
        stack_micro = stack.permute(1, 0, 2) 
        diffs_micro = stack_micro[1:] - stack_micro[:-1]
        d2 = torch.norm(diffs_micro, p=2, dim=-1).mean().item()
        
        if diffs_micro.shape[0] < 2:
            a2 = 0.0
        else:
            v_curr = diffs_micro[1:]
            v_prev = diffs_micro[:-1]
            dot = (v_curr * v_prev).sum(dim=-1)
            n_c = torch.norm(v_curr, p=2, dim=-1)
            n_p = torch.norm(v_prev, p=2, dim=-1)
            cos = torch.clamp(dot / (n_c * n_p + 1e-8), -1.0, 1.0)
            a2 = (torch.acos(cos) * (180/np.pi)).mean().item()

        # --- Macro Metrics ---
        avg_hidden = stack.mean(dim=0) 
        diffs_macro = avg_hidden[1:] - avg_hidden[:-1]
        d1 = torch.norm(diffs_macro, p=2, dim=-1).mean().item()
        
        if diffs_macro.shape[0] < 2:
            a1 = 0.0
        else:
            v_curr = diffs_macro[1:]
            v_prev = diffs_macro[:-1]
            dot = (v_curr * v_prev).sum(dim=-1)
            n_c = torch.norm(v_curr, p=2, dim=-1)
            n_p = torch.norm(v_prev, p=2, dim=-1)
            cos = torch.clamp(dot / (n_c * n_p + 1e-8), -1.0, 1.0)
            a1 = (torch.acos(cos) * (180/np.pi)).mean().item()
            
        results[cp] = {'D1': d1, 'A1': a1, 'D2': d2, 'A2': a2}
        
    return results

# ================= Stage 1: vLLM 强制生成前缀 =================

def stage_1_generate_prefixes(problems):
    print("\n🚀 [Stage 1] vLLM Generating Prefixes (FORCE 8000 tokens)...")
    
    clean_gpu()
    llm = LLM(
        model=MODEL_PATH, 
        tensor_parallel_size=4, 
        trust_remote_code=True,
        gpu_memory_utilization=0.7,
        seed=GLOBAL_SEED,
        enforce_eager=True 
    )
    
    sampling_params = SamplingParams(
        n=1,
        temperature=0.6,
        top_p=0.95,
        max_tokens=PREFIX_LEN, 
        min_tokens=PREFIX_LEN, 
        ignore_eos=True,        
        repetition_penalty=1.05,
        seed=GLOBAL_SEED 
    )
    
    prompts = []
    metadata = []
    
    for p in problems:
        # [修改点1] 使用唯一的 composite key，防止 ID 重复导致的覆盖
        # 同时直接在这里提取 ground_truth
        p_id = str(p.get('ID', 'unknown'))
        unique_key = p.get('unique_key') # 在 main 函数中生成的
        ground_truth = str(p.get('answer', '')) # 假设字段名是 answer

        prompt_text = f"<|im_start|>user\n{p['question']}\n\nPlease reason step by step and put your final answer within \\boxed{{}}.\n<|im_start|>assistant\n"
        
        for i in range(CANDIDATE_POOL_SIZE):
            prompts.append(prompt_text)
            metadata.append({
                'id': p_id,
                'unique_key': unique_key,
                'sample_idx_raw': i, 
                'prompt_text': prompt_text,
                'ground_truth': ground_truth # [核心修改] 将答案直接绑定在元数据里
            })
            
    print(f"Generating {len(prompts)} candidates ({len(problems)} problems x {CANDIDATE_POOL_SIZE})...")
    outputs = llm.generate(prompts, sampling_params)
    
    candidates = {} 
    
    for meta, output in zip(metadata, outputs):
        # 使用 unique_key 作为字典的键，确保完全隔离
        u_key = meta['unique_key']
        if u_key not in candidates: candidates[u_key] = []
        
        token_ids = output.outputs[0].token_ids
        text = output.outputs[0].text
        
        candidates[u_key].append({
            'id': meta['id'], # 保留原始 ID 用于展示
            'sample_idx_raw': meta['sample_idx_raw'],
            'token_ids': token_ids,
            'prefix_text': text,
            'prompt_text': meta['prompt_text'],
            'ground_truth': meta['ground_truth'], # [核心修改] 透传答案
            'gen_len': len(token_ids)
        })
        
    destroy_model_parallel()
    del llm
    clean_gpu()
    print("✅ Stage 1 Complete. vLLM memory released.")
    
    return candidates

# ================= Stage 2 & 3: 分析、评分与打标 =================

def stage_2_analyze_and_label(candidates_dict):
    print("\n🔬 [Stage 2] Transformers Latent Dynamics Analysis & Labeling...")
    
    tokenizer = AutoTokenizer.from_pretrained(MODEL_PATH, trust_remote_code=True)
    model = AutoModelForCausalLM.from_pretrained(
        MODEL_PATH, device_map="auto", torch_dtype=torch.bfloat16, trust_remote_code=True
    )
    model.eval()
    
    final_tasks = []
    
    # 遍历所有题目 (使用 unique_key)
    for u_key, cands in candidates_dict.items():
        # 显示 ID 用于日志
        display_id = cands[0]['id'] if cands else "unknown"
        print(f"Analyzing Problem ID: {display_id} (Key: {u_key})...")
        
        analyzed_cands = []
        
        for c in tqdm(cands, desc="Calculating Metrics"):
            if c['gen_len'] < 7800: continue 
            
            prompt_ids = tokenizer.encode(c['prompt_text'], add_special_tokens=False)
            full_ids = prompt_ids + c['token_ids']
            input_tensor = torch.tensor([full_ids], device=model.device)
            
            with torch.no_grad():
                outputs = model(input_tensor, output_hidden_states=True)
                
            cot_hidden_states = []
            for layer_out in outputs.hidden_states:
                cot_hidden_states.append(layer_out[:, len(prompt_ids):, :])
            
            metrics = calculate_dual_metrics(cot_hidden_states, c['gen_len'])
            c['metrics'] = metrics
            analyzed_cands.append(c)
            
        # === Stage 3: 动力学评分与标签分配 ===
        valid_cands = [c for c in analyzed_cands if c['metrics'].get(8000) is not None]
        
        if not valid_cands:
            print(f"Warning: No valid candidates for Problem {display_id}.")
            continue
            
        d1_2k = np.array([c['metrics'][2000]['D1'] for c in valid_cands])
        d1_4k = np.array([c['metrics'][4000]['D1'] for c in valid_cands])
        delta_d1 = d1_4k - d1_2k
        
        a1_8k = np.array([c['metrics'][8000]['A1'] for c in valid_cands])
        a2_8k = np.array([c['metrics'][8000]['A2'] for c in valid_cands])
        gap_8k = a2_8k - a1_8k
        
        a1_4k = np.array([c['metrics'][4000]['A1'] for c in valid_cands])
        delta_a1 = a1_8k - a1_4k
        
        def safe_z(arr): return zscore(arr) if np.std(arr) > 1e-6 else np.zeros_like(arr)
        
        # 综合评分 (越低越好)
        scores = W_DECEL * safe_z(delta_d1) + W_FRIC * safe_z(gap_8k) + W_CONV * safe_z(delta_a1)
        sorted_indices = np.argsort(scores)
        
        count = len(sorted_indices)
        
        for rank, idx in enumerate(sorted_indices):
            cand = valid_cands[idx]
            
            # 标签逻辑
            current_cut = max(1, count // 2)
            predict_label = True if rank < current_cut else False
            
            final_tasks.append({
                'id': cand['id'],
                'unique_key': u_key,
                'prompt_text': cand['prompt_text'],
                'prefix_text': cand['prefix_text'],
                'sample_index': cand['sample_idx_raw'],
                'ground_truth': cand['ground_truth'], # [核心修改] 继续透传答案
                'predict': predict_label,
                'score': float(scores[idx]),
                'rank': rank
            })
            
    del model
    del tokenizer
    clean_gpu()
    print("✅ Stage 2 & 3 Complete.")
    
    print(f"💾 Saving intermediate tasks to {INTERMEDIATE_FILE}...")
    with open(INTERMEDIATE_FILE, 'w', encoding='utf-8') as f:
        for task in final_tasks:
            f.write(json.dumps(task, ensure_ascii=False) + "\n")
            
    return final_tasks

# ================= Stage 4: vLLM 全量续写 =================

def stage_4_continue_generation(tasks):
    print(f"\n🚀 [Stage 4] Finalizing Answers for {len(tasks)} candidates...")
    
    # [核心修改] 删除了读取 INPUT_FILE 建立 gt_map 的部分
    # 因为现在 ground_truth 已经在 tasks 列表里了

    results = []
    tasks_to_gen = []
    
    # 1. 检查前缀
    for t in tasks:
        # 获取透传下来的 GT
        raw_gt = t.get('ground_truth', '')
        ground_truth = normalize_answer(raw_gt)

        matches = re.findall(r'\\boxed\{([^}]+)\}', t['prefix_text'])
        if matches:
            ans = matches[-1].strip()
            norm_ans = normalize_answer(ans)
            
            results.append({
                "id": t['id'],
                "sample_index": t['sample_index'],
                "ground_truth": ground_truth, # 使用透传的答案
                "model_answer": ans,
                "is_correct": (norm_ans == ground_truth),
                "token_count": PREFIX_LEN, 
                "predict": t['predict'], 
                "score": t['score'],      
                "rank": t['rank'],
                # "response": t['prefix_text'] # 根据您之前的要求，如果不想要 response 可以注释掉
                "response": t['prefix_text']
            })
        else:
            # 将 GT 放入 task 中以便后续使用
            t['normalized_gt'] = ground_truth
            tasks_to_gen.append(t)
            
    # 2. 续写
    if tasks_to_gen:
        print(f"🚀 vLLM Continuing Generation for {len(tasks_to_gen)} incomplete tasks...")
        llm = LLM(
            model=MODEL_PATH, 
            tensor_parallel_size=4, 
            trust_remote_code=True,
            gpu_memory_utilization=0.75,
            seed=GLOBAL_SEED 
        )
        sampling_params = SamplingParams(
            n=1, temperature=0.6, top_p=0.95,
            max_tokens=MAX_TOTAL_LEN - PREFIX_LEN, stop=["<|im_end|>", "<|endoftext|>"],
            seed=GLOBAL_SEED 
        )
        
        prompts = [t['prompt_text'] + t['prefix_text'] for t in tasks_to_gen]
        outputs = llm.generate(prompts, sampling_params)
        
        for task, output in zip(tasks_to_gen, outputs):
            continuation = output.outputs[0].text
            full_response = task['prefix_text'] + continuation
            
            matches = re.findall(r'\\boxed\{([^}]+)\}', full_response)
            model_ans = matches[-1].strip() if matches else ""
            norm_ans = normalize_answer(model_ans)
            
            # 使用之前透传并标准化的 GT
            ground_truth = task['normalized_gt']
            
            results.append({
                "id": task['id'],
                "sample_index": task['sample_index'],
                "ground_truth": ground_truth,
                "model_answer": model_ans,
                "is_correct": (norm_ans == ground_truth),
                "token_count": PREFIX_LEN + len(output.outputs[0].token_ids),
                "predict": task['predict'], 
                "score": task['score'],      
                "rank": task['rank'],
                "response": full_response
            })
            
    return results

# ================= 主程序 =================

def main():
    set_global_seed(GLOBAL_SEED)
    
    if not os.path.exists(OUTPUT_FILE):
        with open(OUTPUT_FILE, 'w') as f: pass

    # 加载 AIME 2025 的所有题目
    problems = []
    print(f"Loading problems from {INPUT_FILE}...")
    with open(INPUT_FILE, 'r') as f:
        # 使用 enumerate 确保每一行都有一个绝对唯一的索引
        for idx, line in enumerate(f):
            if not line.strip(): continue
            try:
                item = json.loads(line)
                
                # [核心修改] 生成一个绝对唯一的键，即使 json 里的 ID 重复也不怕
                # 格式: 行号_原始ID
                raw_id = str(item.get('ID', 'unknown'))
                item['unique_key'] = f"{idx}_{raw_id}"
                
                # 确保有 answer 字段，如果字段名叫 'solution' 或其他，在这里统一一下
                if 'answer' not in item and 'Target' in item:
                     item['answer'] = item['Target']
                
                problems.append(item)
            except json.JSONDecodeError:
                print(f"Skipping invalid JSON line: {idx}")
    
    print(f"Loaded {len(problems)} problems.")
    
    # 1. 强制生成
    candidates = stage_1_generate_prefixes(problems)
    
    # 2. 评分并打标
    labeled_tasks = stage_2_analyze_and_label(candidates)
    
    # 3. 全量提取结果
    if labeled_tasks:
        final_results = stage_4_continue_generation(labeled_tasks)
        print(f"Saving {len(final_results)} results to {OUTPUT_FILE}...")
        
        # 结果按 ID 排序，方便查看
        final_results.sort(key=lambda x: x['id'])
        
        with open(OUTPUT_FILE, 'w', encoding='utf-8') as f:
            for r in final_results:
                f.write(json.dumps(r, ensure_ascii=False) + "\n")
    else:
        print("CRITICAL: No candidates survived analysis!")
        
    print("All Done.")

if __name__ == "__main__":
    main()