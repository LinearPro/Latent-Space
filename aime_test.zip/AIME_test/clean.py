import json

def remove_response_column(input_file_path, output_file_path):
    """
    读取 JSONL 文件，删除每行的 'response' 字段，并保存到新文件。
    """
    print(f"正在处理文件: {input_file_path} ...")
    processed_count = 0
    
    try:
        with open(input_file_path, 'r', encoding='utf-8') as infile, \
             open(output_file_path, 'w', encoding='utf-8') as outfile:
            
            for line in infile:
                if not line.strip():
                    continue # 跳过空行
                
                try:
                    data = json.loads(line)
                    
                    # 核心步骤：如果存在 'response' 键，则删除它
                    if 'question' in data:
                        del data['question']

                    if 'response' in data:
                        del data['response']
                    
                    # 将修改后的字典写回文件
                    outfile.write(json.dumps(data, ensure_ascii=False) + '\n')
                    processed_count += 1
                    
                except json.JSONDecodeError as e:
                    print(f"跳过无法解析的行: {e}")

        print(f"处理完成！")
        print(f"已生成新文件: {output_file_path}")
        print(f"共处理行数: {processed_count}")

    except FileNotFoundError:
        print(f"错误: 找不到输入文件 '{input_file_path}'")
    except Exception as e:
        print(f"发生错误: {e}")

# ==========================================
# 配置部分
# ==========================================

# 输入文件名 (请修改为你实际的文件名)
input_filename = 'aime2025_cot_all_samples1_new.jsonl' 

# 输出文件名
output_filename = 'aime2025_analysis1.jsonl'

# 执行函数
if __name__ == "__main__":
    remove_response_column(input_filename, output_filename)