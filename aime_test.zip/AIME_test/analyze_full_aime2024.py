import os
import json
import torch
import numpy as np
import pickle
import re
import gc
from transformers import AutoModelForCausalLM, AutoTokenizer
import torch.nn.functional as F

# ================= 配置区域 =================
# 模型路径 (请确保路径正确)
MODEL_PATH = "/WORK/PUBLIC/dongyinp_work/lingp/GQ/GuidedQuant-main/models/Qwen3-4B-Thinking-2507/Qwen/Qwen3-4B-Thinking-2507"

# 输入文件
INPUT_PKL_FILE = "aime2024_cot_results.pkl"   # 推理结果文件 (应包含 150 条数据)
GT_DATA_FILE = "aime2024.jsonl"               # 原始题目文件 (应包含 30 题)

# 输出文件
OUTPUT_FILE = "aime2024_full_analysis_metrics.jsonl"

# 参数设置
MAX_NEW_TOKENS = 81920
GROUP_SIZE = 5          # 每题 5 条 CoT
CPU_LAYER_CACHE = {}    # 用于缓存层输出，防止显存溢出

# ================= 工具函数 =================

def normalize_answer(ans):
    """
    标准化答案：
    1. 尝试数值匹配：解决 080 vs 80, 80.0 vs 80 等问题
    2. 文本兜底匹配：去除 LaTeX 和特殊符号
    """
    if ans is None: return ""
    ans = str(ans).strip()
    
    # 1. 预处理：去除可能残留的 LaTeX 括号或 box
    ans = ans.replace(r"\boxed", "").replace("{", "").replace("}", "")
    
    # 2. 尝试数值转换 (解决 080 == 80 问题)
    try:
        val = float(ans)
        # 如果是整数 (如 80.0 或 080)，转为不带小数点和前导零的字符串 "80"
        if val.is_integer():
            return str(int(val))
        return str(val)
    except ValueError:
        pass 

    # 3. 文本标准化 (兜底)
    ans = ans.replace(" ", "")
    ans = re.sub(r"\\[a-zA-Z]+", "", ans) 
    ans = re.sub(r"[^0-9a-zA-Z\.]", "", ans).lower()
    return ans

def load_ground_truth_as_list():
    """加载题目和标准答案"""
    gt_list = []
    print(f"📖 Loading Ground Truth from {GT_DATA_FILE}...")
    if not os.path.exists(GT_DATA_FILE):
        print(f"⚠️ Warning: GT file not found.")
        return []

    with open(GT_DATA_FILE, 'r', encoding='utf-8') as f:
        for line in f:
            if line.strip():
                try:
                    item = json.loads(line)
                    ans = item.get("answer") or item.get("Answer")
                    pid = str(item.get("ID") or item.get("id"))
                    gt_list.append({"id": pid, "answer": str(ans) if ans else ""})
                except: continue
    print(f"✅ Loaded {len(gt_list)} ground truth records.")
    return gt_list

def load_inference_results():
    """加载推理结果 (兼容 List 和 Stream 模式)"""
    results = []
    print(f"📦 Loading inference results from {INPUT_PKL_FILE}...")
    if not os.path.exists(INPUT_PKL_FILE):
        print("❌ Error: Input file not found.")
        return results

    try:
        with open(INPUT_PKL_FILE, 'rb') as f:
            try:
                data = pickle.load(f)
                if isinstance(data, list): results = data
                else:
                    results.append(data)
                    while True:
                        try: results.append(pickle.load(f))
                        except EOFError: break
            except Exception:
                f.seek(0)
                while True:
                    try: results.append(pickle.load(f))
                    except EOFError: break
    except Exception as e:
        print(f"⚠️ Error reading pickle: {e}")
    
    print(f"✅ Loaded {len(results)} total inference chains.")
    return results

def calculate_metrics_cpu(layer_dict, attention_mask_cpu):
    """计算 Hidden States 的 Diff Norm 和 Cosine Angle"""
    sorted_keys = sorted(layer_dict.keys())
    if not sorted_keys: return []

    # Stack layers -> (Layers, Batch, Seq, Dim)
    stacked_layers = torch.stack([layer_dict[k] for k in sorted_keys], dim=0)
    
    # Mean over layers -> (Batch, Seq, Dim)
    avg_hidden_states = torch.mean(stacked_layers, dim=0)
    del stacked_layers
    
    if avg_hidden_states.dim() == 2:
        avg_hidden_states = avg_hidden_states.unsqueeze(0)
    
    curr = avg_hidden_states[:, 1:, :]
    prev = avg_hidden_states[:, :-1, :]
    
    # Metrics
    diff_norms = torch.norm(curr - prev, p=2, dim=-1)
    
    cos_sim = F.cosine_similarity(curr, prev, dim=-1, eps=1e-8)
    cos_sim = torch.clamp(cos_sim, -1.0 + 1e-7, 1.0 - 1e-7)
    angles = torch.rad2deg(torch.acos(cos_sim))
    
    if attention_mask_cpu.dim() == 1:
        attention_mask_cpu = attention_mask_cpu.unsqueeze(0)
    valid_mask = attention_mask_cpu[:, 1:] == 1
    
    d_flat = diff_norms.reshape(-1)
    a_flat = angles.reshape(-1)
    m_flat = valid_mask.reshape(-1)
    
    return [(d_flat[m_flat].tolist(), a_flat[m_flat].tolist())]

def get_layer_output_hook(layer_idx):
    def hook(module, input, output):
        # 立即转移到 CPU 以节省显存
        CPU_LAYER_CACHE[layer_idx] = output[0].detach().cpu().to(torch.float32)
    return hook

# ================= 主流程 =================

def main():
    # 1. 准备数据
    gt_list = load_ground_truth_as_list()
    inference_data = load_inference_results()
    
    if not inference_data:
        print("❌ No data found. Exiting.")
        return

    # 简单校验
    expected_count = len(gt_list) * GROUP_SIZE
    if len(inference_data) != expected_count:
        print(f"⚠️ Warning: Data count mismatch! Expected {expected_count} (30x5), got {len(inference_data)}.")
        print("   Analysis will proceed, but mapping might be misaligned if records are missing.")

    # 2. 加载模型
    print(f"🔧 Loading Model: {MODEL_PATH}")
    model = AutoModelForCausalLM.from_pretrained(
        MODEL_PATH,
        device_map="auto",
        torch_dtype=torch.bfloat16,
        trust_remote_code=True
    ).eval()
    
    tokenizer = AutoTokenizer.from_pretrained(MODEL_PATH, trust_remote_code=True)
    if tokenizer.pad_token is None: tokenizer.pad_token = tokenizer.eos_token
        
    layers = model.model.layers if hasattr(model, "model") else model.layers
    hooks = [layer.