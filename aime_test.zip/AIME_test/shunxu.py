import json
import os

# ================= 配置 =================
INPUT_FILE = "aime2025_cot_all_samples1.jsonl"
OUTPUT_FILE = "aime2025_cot_all_samples1_reordered.jsonl"

# 定义你想要的键顺序
DESIRED_ORDER = [
    "id",
    "sample_index",
    "ground_truth",
    "model_answer_raw",
    "token_count",
    "is_correct",
    "question",      # 移动到了 is_correct 之后
    "response"
]

def reorder_jsonl_keys():
    print(f"正在处理文件: {INPUT_FILE} ...")
    
    if not os.path.exists(INPUT_FILE):
        print(f"错误: 找不到文件 {INPUT_FILE}")
        return

    count = 0
    with open(INPUT_FILE, 'r', encoding='utf-8') as infile, \
         open(OUTPUT_FILE, 'w', encoding='utf-8') as outfile:
        
        for line in infile:
            if not line.strip():
                continue
            
            try:
                original_data = json.loads(line)
                
                # 创建一个新的有序字典
                new_data = {}
                
                # 1. 先按指定顺序添加存在的键
                for key in DESIRED_ORDER:
                    if key in original_data:
                        new_data[key] = original_data[key]
                
                # 2. (可选) 如果原数据里还有其他键没在列表里，也补在后面，防止数据丢失
                for key, value in original_data.items():
                    if key not in new_data:
                        new_data[key] = value
                
                # 写入新文件
                outfile.write(json.dumps(new_data, ensure_ascii=False) + '\n')
                count += 1
                
            except json.JSONDecodeError:
                print(f"跳过无效行: {line[:50]}...")

    print(f"完成！已处理 {count} 行数据。")
    print(f"新文件已保存为: {OUTPUT_FILE}")

if __name__ == "__main__":
    reorder_jsonl_keys()