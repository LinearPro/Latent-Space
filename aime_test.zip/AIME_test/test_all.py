import os
import json
import torch
import numpy as np
import pickle
import re
import gc
from transformers import AutoModelForCausalLM, AutoTokenizer
import torch.nn.functional as F

# ================= 配置区域 =================
# 模型路径
MODEL_PATH = "/WORK/PUBLIC/dongyinp_work/lingp/models/Qwen3-4B-Thinking-2507"
# 输入数据 (Pickle)
INPUT_PKL_FILE = "aime2024_cot_results_new_now.pkl"
# Ground Truth 文件
GT_DATA_FILE = "aime2024.jsonl"
# 输出结果文件
OUTPUT_FILE = "aime2024_full_dynamics_seq_metrics_filtered.jsonl"

# 【核心修改】指定要分析的 ID 列表
TARGET_IDS = {"5", "26", "29", "30"}

GROUP_SIZE = 5
CPU_LAYER_CACHE = {}

# ================= 工具函数 =================

def normalize_answer(ans):
    """标准化答案，用于比对正确性"""
    if ans is None: return ""
    ans = str(ans).strip()
    ans = ans.replace(r"\boxed", "").replace("{", "").replace("}", "")
    try:
        val = float(ans)
        if val.is_integer(): return str(int(val))
        return str(val)
    except ValueError:
        pass 
    ans = ans.replace(" ", "")
    ans = re.sub(r"\\[a-zA-Z]+", "", ans) 
    ans = re.sub(r"[^0-9a-zA-Z\.]", "", ans).lower()
    return ans

def clean_cot_content(text):
    """清洗模型输出中可能的复读机或格式错误内容"""
    if not text: return ""
    match = re.search(r'\\boxed\{', text)
    if not match: return text
    
    start_idx = match.start()
    content_start = start_idx + 7
    balance = 1
    end_idx = -1
    
    for i in range(content_start, len(text)):
        if text[i] == '{': balance += 1
        elif text[i] == '}': balance -= 1
        if balance == 0:
            end_idx = i + 1
            break
            
    if end_idx != -1:
        return text[:end_idx]
    return text

def load_ground_truth_as_list():
    """加载标准答案"""
    gt_list = []
    print(f"📖 Loading Ground Truth from {GT_DATA_FILE}...")
    if not os.path.exists(GT_DATA_FILE): return []
    with open(GT_DATA_FILE, 'r', encoding='utf-8') as f:
        for line in f:
            if line.strip():
                try:
                    item = json.loads(line)
                    ans = item.get("answer") or item.get("Answer")
                    pid = str(item.get("ID") or item.get("id"))
                    gt_list.append({"id": pid, "answer": str(ans) if ans else ""})
                except: continue
    print(f"✅ Loaded {len(gt_list)} ground truth records.")
    return gt_list

def load_inference_results():
    """加载推理结果 (Pickle)"""
    results = []
    print(f"📦 Loading inference results from {INPUT_PKL_FILE}...")
    if not os.path.exists(INPUT_PKL_FILE): return results
    try:
        with open(INPUT_PKL_FILE, 'rb') as f:
            try:
                data = pickle.load(f)
                if isinstance(data, list): results = data
                else:
                    results.append(data)
                    while True:
                        try: results.append(pickle.load(f))
                        except EOFError: break
            except Exception:
                f.seek(0)
                while True:
                    try: results.append(pickle.load(f))
                    except EOFError: break
    except Exception as e:
        print(f"⚠️ Error reading pickle: {e}")
    print(f"✅ Loaded {len(results)} total inference chains.")
    return results

def calculate_metrics_cpu_seq(layer_dict, attention_mask_cpu):
    """
    计算序列中每一个Token的指标。
    """
    sorted_keys = sorted(layer_dict.keys())
    if not sorted_keys: return None

    # Stack layers: [Num_Layers, Seq_Len, Hidden_Dim]
    stacked_layers = torch.stack([layer_dict[k] for k in sorted_keys], dim=0)
    
    # 准备 Mask
    if attention_mask_cpu.dim() == 1: attention_mask_cpu = attention_mask_cpu.unsqueeze(0)
    valid_mask = (attention_mask_cpu[:, 1:] == 1).reshape(-1)

    # ================= Method 1: Mean then Metric =================
    avg_hidden_states = torch.mean(stacked_layers, dim=0)
    if avg_hidden_states.dim() == 2: avg_hidden_states = avg_hidden_states.unsqueeze(0)
    
    curr_m1 = avg_hidden_states[:, 1:, :]
    prev_m1 = avg_hidden_states[:, :-1, :]
    
    diff_norms_1 = torch.norm(curr_m1 - prev_m1, p=2, dim=-1).reshape(-1)
    
    cos_sim_1 = F.cosine_similarity(curr_m1, prev_m1, dim=-1, eps=1e-8)
    cos_sim_1 = torch.clamp(cos_sim_1, -1.0 + 1e-7, 1.0 - 1e-7)
    angles_1 = torch.rad2deg(torch.acos(cos_sim_1)).reshape(-1)

    # ================= Method 2: Metric then Mean =================
    curr_layers = stacked_layers[:, 1:, :] 
    prev_layers = stacked_layers[:, :-1, :] 
    
    diff_layerwise = torch.norm(curr_layers - prev_layers, p=2, dim=-1)
    diff_norms_2 = torch.mean(diff_layerwise, dim=0).reshape(-1) 
    
    cos_layerwise = F.cosine_similarity(curr_layers, prev_layers, dim=-1, eps=1e-8)
    cos_layerwise = torch.clamp(cos_layerwise, -1.0 + 1e-7, 1.0 - 1e-7)
    ang_layerwise = torch.rad2deg(torch.acos(cos_layerwise))
    angles_2 = torch.mean(ang_layerwise, dim=0).reshape(-1)

    del stacked_layers, curr_layers, prev_layers, diff_layerwise, ang_layerwise, avg_hidden_states
    
    return (
        diff_norms_1[valid_mask].tolist(),
        angles_1[valid_mask].tolist(),
        diff_norms_2[valid_mask].tolist(),
        angles_2[valid_mask].tolist()
    )

def get_layer_output_hook(layer_idx):
    def hook(module, input, output):
        CPU_LAYER_CACHE[layer_idx] = output[0].detach().cpu().to(torch.float32)
    return hook

# ================= 主流程 =================

def main():
    gt_list = load_ground_truth_as_list()
    inference_data = load_inference_results()
    if not inference_data: return

    print(f"🔧 Loading Model: {MODEL_PATH}")
    model = AutoModelForCausalLM.from_pretrained(
        MODEL_PATH, 
        device_map="auto", 
        torch_dtype=torch.bfloat16, 
        trust_remote_code=True
    ).eval()
    
    tokenizer = AutoTokenizer.from_pretrained(MODEL_PATH, trust_remote_code=True)
    if tokenizer.pad_token is None: tokenizer.pad_token = tokenizer.eos_token
        
    layers = model.model.layers if hasattr(model, "model") else model.layers
    hooks = [layer.register_forward_hook(get_layer_output_hook(i)) for i, layer in enumerate(layers)]
    
    print(f"🚀 Starting Analysis for IDs: {TARGET_IDS} -> Output: {OUTPUT_FILE}")
    
    with open(OUTPUT_FILE, 'w', encoding='utf-8') as f: pass
    
    correct_count = 0
    processed_count = 0
    
    with open(OUTPUT_FILE, 'a', encoding='utf-8') as f_out:
        for i, item in enumerate(inference_data):
            problem_idx = i // GROUP_SIZE
            cot_idx = i % GROUP_SIZE
            
            # 获取 ID
            display_id = str(item.get('ID', 'Unknown'))
            
            # 【核心修改】过滤逻辑：只处理指定的 ID
            if display_id not in TARGET_IDS:
                continue
                
            processed_count += 1
            
            # 获取 Ground Truth
            if problem_idx < len(gt_list):
                gt_ans = gt_list[problem_idx]['answer']
            else:
                gt_ans = ""
            
            print("-" * 80)
            print(f"[{i+1}/{len(inference_data)}] Matched ID: {display_id} | CoT {cot_idx}")

            CPU_LAYER_CACHE.clear()
            torch.cuda.empty_cache()

            try:
                question = item['question']
                instruction = f"{question}\n\nPlease reason step by step and put your final answer within \\boxed{{}}."
                prompt_text = f"<|im_start|>user\n{instruction}<|im_end|>\n<|im_start|>assistant\n"
                
                raw_cot = item['cot_inference']
                cleaned_cot = clean_cot_content(raw_cot)
                
                prompt_ids = tokenizer.encode(prompt_text, add_special_tokens=False)
                cot_ids = tokenizer.encode(cleaned_cot, add_special_tokens=False)
                
                prompt_len = len(prompt_ids)
                cot_len = len(cot_ids)
                
                print(f"   [Length] Full CoT: {cot_len} tokens")

                full_input_ids = prompt_ids + cot_ids
                input_tensor = torch.tensor([full_input_ids], dtype=torch.long).to(model.device)
                attention_mask = torch.ones_like(input_tensor).to(model.device)
                
                model_ans = item.get('cot_answer', "")
                is_correct = False
                if gt_ans:
                    if normalize_answer(model_ans) == normalize_answer(gt_ans):
                        is_correct = True
                        correct_count += 1

                with torch.no_grad():
                    model(input_ids=input_tensor, attention_mask=attention_mask)
                
                metrics_result = calculate_metrics_cpu_seq(CPU_LAYER_CACHE, attention_mask.cpu())
                
                seq_d1, seq_a1 = [], []
                seq_d2, seq_a2 = [], []

                if metrics_result:
                    d_norms_1, angs_1, d_norms_2, angs_2 = metrics_result
                    
                    start_pos = max(0, prompt_len - 1)
                    
                    seq_d1 = d_norms_1[start_pos:]
                    seq_a1 = angs_1[start_pos:]
                    seq_d2 = d_norms_2[start_pos:]
                    seq_a2 = angs_2[start_pos:]
                    
                calc_len = len(seq_d1)
                
                print(f"   -> Result: Correct={is_correct}")
                print(f"      Calculated on {calc_len} steps")

                record = {
                    "unique_index": f"{problem_idx}_{cot_idx}",
                    "problem_index": problem_idx,
                    "ID": display_id,
                    "cot_index": cot_idx,
                    "is_correct": is_correct,
                    "model_answer": model_ans,
                    "ground_truth": gt_ans,
                    "diff_norm_1_seq": seq_d1,
                    "angle_1_seq": seq_a1,
                    "diff_norm_2_seq": seq_d2,
                    "angle_2_seq": seq_a2,
                    "seq_length": calc_len
                }
                f_out.write(json.dumps(record, ensure_ascii=False) + "\n")
                f_out.flush()

            except Exception as e:
                import traceback
                traceback.print_exc()
                print(f"❌ Error on index {i}: {e}")
                
    for h in hooks: h.remove()
    print("=" * 80)
    print(f"✅ Filtered Analysis Completed. Processed {processed_count} samples. Overall Accuracy in Subset: {correct_count}/{processed_count if processed_count > 0 else 1}")

if __name__ == "__main__":
    main()