import os
import json
import torch
import numpy as np
import pickle
import re
import gc
import sys
from vllm import LLM, SamplingParams
from transformers import AutoModelForCausalLM, AutoTokenizer
import torch.nn.functional as F

# ================= 配置区域 =================
MODEL_PATH = "/WORK/PUBLIC/dongyinp_work/lingp/GQ/GuidedQuant-main/models/Qwen3-4B-Thinking-2507/Qwen/Qwen3-4B-Thinking-2507"
DATA_FILE = "aime_2024_2025_combined.jsonl"

# === 输出文件配置 ===
# 最终分析结果文件（JSONL格式，只含指标均值）
OUTPUT_FILE = "aime_cot_vllm_metrics_avg_only_1.jsonl" 
# 中间生成缓存文件（必须含文本供分析使用，分析完可手动删除）
TEMP_GEN_FILE = "aime_cot_vllm_generation_cache_1.pkl" 

NUM_COTS_PER_PROBLEM = 5
MAX_NEW_TOKENS = 81920
TEMPERATURE = 0.6
VLLM_GPU_UTIL = 0.7
BATCH_SIZE = 1 

# ================= 工具函数 =================
def load_dataset(filepath):
    if not os.path.exists(filepath):
        print(f"Error: {filepath} not found.")
        return []
    
    data = []
    if filepath.endswith(".jsonl"):
        print(f"📖 Detected JSONL format for {filepath}...")
        with open(filepath, 'r', encoding='utf-8') as f:
            for line in f:
                if line.strip():
                    try:
                        data.append(json.loads(line))
                    except json.JSONDecodeError:
                        continue
    else:
        with open(filepath, 'r', encoding='utf-8') as f:
            raw_data = json.load(f)
        if isinstance(raw_data, dict) and 'fullContent' in raw_data:
            data = raw_data['fullContent']
        else:
            data = raw_data
            
    return data

def normalize_answer(ans):
    if not ans: return ""
    return re.sub(r"[^0-9a-zA-Z]", "", str(ans)).lower()

def extract_answer(text):
    pattern = r"\\boxed\s*\{([^}]+)\}"
    matches = re.findall(pattern, text)
    if matches:
        return matches[-1].strip()
    return "N/A"

# ================= 核心 Metric 计算逻辑 =================
def calculate_metrics_gpu(hidden_states, attention_mask):
    """
    计算每一层的 Diff Norm 和 Angle，并在层维度取平均。
    返回: List of (diff_norms, angles) per batch element.
    """
    # hidden_states: tuple (num_layers+1, batch, seq, dim) -> Stack -> (num_layers, batch, seq, dim)
    stacked_layers = torch.stack(hidden_states[1:], dim=0).float() 
    
    num_layers, batch_size, seq_len, dim = stacked_layers.shape
    
    if seq_len < 2:
        return [([], []) for _ in range(batch_size)]

    # === 1. 准备相邻 Token 的层数据 ===
    curr_layers = stacked_layers[:, :, 1:, :] 
    prev_layers = stacked_layers[:, :, :-1, :] 
    
    # === 2. 计算每一层的 Diff Norm ===
    diff_vectors = curr_layers - prev_layers
    layer_wise_diff_norms = torch.norm(diff_vectors, p=2, dim=-1) # (num_layers, batch, seq-1)
    
    # === 3. 计算每一层的 Angle (Cosine Similarity) ===
    layer_wise_cos_sim = F.cosine_similarity(curr_layers, prev_layers, dim=-1, eps=1e-8)
    layer_wise_cos_sim = torch.clamp(layer_wise_cos_sim, -1.0 + 1e-7, 1.0 - 1e-7)
    layer_wise_angles = torch.rad2deg(torch.acos(layer_wise_cos_sim))
    
    # === 4. 对层维度 (dim=0) 取平均 ===
    avg_diff_norms = torch.mean(layer_wise_diff_norms, dim=0) # (batch, seq-1)
    avg_angles = torch.mean(layer_wise_angles, dim=0)         # (batch, seq-1)
    
    # === 5. 处理 Mask 并导出结果 ===
    valid_mask = attention_mask[:, 1:] == 1
    
    results = []
    diff_norms_cpu = avg_diff_norms.detach().cpu()
    angles_cpu = avg_angles.detach().cpu()
    valid_mask_cpu = valid_mask.detach().cpu()
    
    for i in range(batch_size):
        valid_len = valid_mask_cpu[i].sum().item()
        if valid_len == 0:
            results.append(([], []))
        else:
            # 只取有效的 token 位置
            d_norms = diff_norms_cpu[i][valid_mask_cpu[i]].tolist()
            angs = angles_cpu[i][valid_mask_cpu[i]].tolist()
            results.append((d_norms, angs))
            
    return results

# ================= 阶段 1: 增量生成 (vLLM) =================
def run_generation_phase(problems):
    print("\n🚀 [Phase 1] Starting Generation with vLLM...")
    
    generated_data = []
    processed_ids = set()
    
    if os.path.exists(TEMP_GEN_FILE):
        print(f"⚠️ Found intermediate cache: {TEMP_GEN_FILE}")
        try:
            with open(TEMP_GEN_FILE, 'rb') as f:
                generated_data = pickle.load(f)
                for item in generated_data:
                    processed_ids.add(f"{item['problem_id']}_{item['cot_index']}")
            print(f"⏩ Resuming... Already generated {len(generated_data)} samples.")
        except Exception as e:
            print(f"⚠️ Cache file corrupted, starting fresh. Error: {e}")
            generated_data = []

    prompts_to_run = []
    metadata_to_run = []
    
    for prob in problems:
        p_id = prob.get("ID", prob.get("id", "Unknown"))
        q = prob.get("Question", prob.get("question", ""))
        ans = prob.get("Answer", prob.get("answer", ""))
        
        prompt_text = f"Problem: {q}\nAnswer this step by step and put the final answer in \\boxed{{}}."
        
        for i in range(NUM_COTS_PER_PROBLEM):
            unique_key = f"{p_id}_{i}"
            if unique_key in processed_ids:
                continue 
                
            prompts_to_run.append(prompt_text)
            metadata_to_run.append({
                "problem_id": p_id,
                "cot_index": i,
                "ground_truth": ans,
                "prompt": prompt_text 
            })
    
    if not prompts_to_run:
        print("✅ All prompts already generated. Skipping vLLM.")
        return generated_data

    print(f"🔥 Initializing vLLM (Mem Util: {VLLM_GPU_UTIL})...")
    num_gpus = torch.cuda.device_count()
    llm = LLM(
        model=MODEL_PATH,
        tensor_parallel_size=num_gpus,
        trust_remote_code=True,
        gpu_memory_utilization=VLLM_GPU_UTIL,
        enforce_eager=True,
        max_model_len=MAX_NEW_TOKENS
    )
    
    sampling_params = SamplingParams(
        temperature=TEMPERATURE,
        top_p=0.95,
        max_tokens=MAX_NEW_TOKENS
    )
    
    print(f"⚡ Generating {len(prompts_to_run)} missing responses...")
    outputs = llm.generate(prompts_to_run, sampling_params)
    
    for output, meta in zip(outputs, metadata_to_run):
        generated_text = output.outputs[0].text
        full_text = meta["prompt"] + generated_text 
        
        extracted_ans = extract_answer(generated_text)
        is_correct = normalize_answer(extracted_ans) == normalize_answer(meta["ground_truth"])
        
        item = {
            "problem_id": meta["problem_id"],
            "cot_index": meta["cot_index"],
            "is_correct": is_correct,
            "full_text": full_text, 
            "prompt_text": meta["prompt"], 
            "extracted_answer": extracted_ans 
        }
        generated_data.append(item)

    print(f"💾 Updating cache {TEMP_GEN_FILE}...")
    with open(TEMP_GEN_FILE, 'wb') as f:
        pickle.dump(generated_data, f)
        
    print("🧹 Cleaning up vLLM resources...")
    from vllm.distributed.parallel_state import destroy_model_parallel
    destroy_model_parallel()
    del llm
    gc.collect()
    torch.cuda.empty_cache()
    
    return generated_data

# ================= 阶段 2: 增量分析 (Transformers) =================
def run_analysis_phase(generated_data):
    print("\n🔬 [Phase 2] Starting Incremental Analysis (Saving AVG metrics to JSONL)...")
    
    # 扫描已处理的 ID
    processed_keys = set()
    if os.path.exists(OUTPUT_FILE):
        print(f"📂 Scanning existing output file: {OUTPUT_FILE}...")
        try:
            with open(OUTPUT_FILE, 'r', encoding='utf-8') as f:
                for line in f:
                    if line.strip():
                        try:
                            record = json.loads(line)
                            processed_keys.add(f"{record['problem_id']}_{record['cot_index']}")
                        except:
                            continue
            print(f"⏩ Found {len(processed_keys)} processed records. Resuming...")
        except Exception as e:
            print(f"⚠️ Error reading output file: {e}. Starting fresh.")
            processed_keys = set()
    
    items_to_process = [
        item for item in generated_data 
        if f"{item['problem_id']}_{item['cot_index']}" not in processed_keys
    ]
    
    if not items_to_process:
        print("✅ All items already analyzed.")
        return

    print(f"🔧 Loading HF Model for analysis of {len(items_to_process)} items...")
    
    model = AutoModelForCausalLM.from_pretrained(
        MODEL_PATH,
        device_map="auto", 
        torch_dtype=torch.bfloat16, 
        trust_remote_code=True,
        output_hidden_states=True
    ).eval()
    
    tokenizer = AutoTokenizer.from_pretrained(MODEL_PATH, trust_remote_code=True)
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token
    
    total = len(items_to_process)
    
    # 遍历处理
    for idx, item in enumerate(items_to_process):
        print(f"   [{idx+1}/{total}] Processing Prob {item['problem_id']} (CoT {item['cot_index']})...")
        
        try:
            # 1. 获取完整的 Full Text
            full_text = item["full_text"]
            # 2. 获取 Prompt Text (用于计算偏移量)
            prompt_text = item.get("prompt_text", "")
            
            # 兼容旧 Cache：如果没有 prompt_text，做简单容错
            if not prompt_text and "Problem:" in full_text:
                prompt_text = full_text.split("Answer this step by step")[0] + "Answer this step by step and put the final answer in \\boxed{}."

            inputs = tokenizer(
                [full_text], 
                return_tensors="pt", 
                padding=True, 
                truncation=True, 
                max_length=MAX_NEW_TOKENS
            ).to(model.device)

            # 计算 Prompt 的 token 长度
            prompt_ids = tokenizer([prompt_text], add_special_tokens=True)["input_ids"][0]
            prompt_len = len(prompt_ids)
            
            with torch.no_grad():
                outputs = model(**inputs)
            
            # 计算全序列 Metrics
            metrics = calculate_metrics_gpu(outputs.hidden_states, inputs.attention_mask)
            d_norms, angs = metrics[0] 
            
            # 剔除 Prompt 部分
            slice_start_idx = max(0, prompt_len - 1)
            cot_d_norms = d_norms[slice_start_idx:]
            cot_angles = angs[slice_start_idx:]
            
            # 计算平均值
            avg_diff_norm = float(np.mean(cot_d_norms)) if cot_d_norms else 0.0
            avg_angle = float(np.mean(cot_angles)) if cot_angles else 0.0
            
            # === 构造输出字典 ===
            result_record = {
                "problem_id": item["problem_id"],
                "cot_index": item["cot_index"],
                "is_correct": item["is_correct"],
                "avg_diff_norm": avg_diff_norm,
                "avg_angle": avg_angle
            }
            
            # === [修改点] 立即写入文件（每次打开-写入-关闭）===
            with open(OUTPUT_FILE, 'a', encoding='utf-8') as f_out:
                f_out.write(json.dumps(result_record) + "\n")
            
        except RuntimeError as e:
            print(f"❌ OOM or Error on item {item['problem_id']}: {e}")
            torch.cuda.empty_cache()
            
            error_record = {
                "problem_id": item["problem_id"],
                "cot_index": item["cot_index"],
                "is_correct": item["is_correct"],
                "avg_diff_norm": -1.0,
                "avg_angle": -1.0,
                "error": str(e)
            }
            # 错误记录也立即写入
            with open(OUTPUT_FILE, 'a', encoding='utf-8') as f_out:
                f_out.write(json.dumps(error_record) + "\n")

    print(f"✅ Analysis phase complete. Metrics (Avg Only) saved to {OUTPUT_FILE}.")

def main():
    all_problems = load_dataset(DATA_FILE)
    if not all_problems: 
        return
    
    print(f"📦 Total problems loaded: {len(all_problems)}")
    
    generated_data = run_generation_phase(all_problems)
    run_analysis_phase(generated_data)
    
    print("\n🎉 All tasks finished successfully.")

if __name__ == "__main__":
    main()