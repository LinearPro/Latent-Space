import pandas as pd
import json
import re

def process_aime_parquet(input_file, output_file):
    # Load the parquet file
    # Requires pyarrow or fastparquet to be installed
    df = pd.read_parquet(input_file)

    # List to store the processed records
    records = []

    for index, row in df.iterrows():
        # Extract relevant fields
        question = row.get('problem', '')
        answer = row.get('answer', '')
        year_val = row.get('year', 2024) # Default to 2024 if missing, or take from column
        url = row.get('url', '')

        # Extract ID (Problem Number) from URL
        # URL format example: https://artofproblemsolving.com/wiki/index.php/2024_AIME_I_Problems/Problem_1
        # We look for the number after "Problem_"
        id_match = re.search(r'Problem_(\d+)', url)
        if id_match:
            problem_id = id_match.group(1)
        else:
            # Fallback: use the index + 1 or a default if URL pattern doesn't match
            problem_id = str(index + 1)

        # Construct the dictionary with the requested keys
        record = {
            "question": question,
            "answer": answer,
            "2024": year_val,  # Using "2024" as the key for the year value
            "ID": problem_id   # "ID" represents the question number (第几题)
        }
        records.append(record)

    # Write to a JSONL file
    with open(output_file, 'w', encoding='utf-8') as f:
        for record in records:
            # ensure_ascii=False ensures characters like Chinese or Math symbols are preserved
            f.write(json.dumps(record, ensure_ascii=False) + '\n')

    print(f"Successfully processed {len(records)} problems to {output_file}")

# Execute the function
if __name__ == "__main__":
    input_filename = 'train-00000-of-00001.parquet'
    output_filename = 'aime2024.jsonl'
    
    # Run the processing
    try:
        process_aime_parquet(input_filename, output_filename)
    except ImportError as e:
        print("Error: Missing libraries. Please install pyarrow: pip install pyarrow")
    except Exception as e:
        print(f"An error occurred: {e}")