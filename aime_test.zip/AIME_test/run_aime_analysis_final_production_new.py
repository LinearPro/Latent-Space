import os
import json
import torch
import numpy as np
import pickle
import re
import gc
import sys
import psutil
from transformers import AutoModelForCausalLM, AutoTokenizer
import torch.nn.functional as F

# ================= 配置区域 =================
MODEL_PATH = "/WORK/PUBLIC/dongyinp_work/lingp/GQ/GuidedQuant-main/models/Qwen3-4B-Thinking-2507/Qwen/Qwen3-4B-Thinking-2507"
TEMP_GEN_FILE = "aime_cot_vllm_generation_cache.pkl"   # 读取 vLLM 生成的缓存
DATA_FILE = "aime_2024_2025_combined.jsonl"             # 原始数据 (用于修正 Ground Truth)
OUTPUT_FILE = "aime_cot_metrics_layer_mean_150.jsonl"       # 【修改】文件名带上 _150

MAX_NEW_TOKENS = 81920
CPU_LAYER_CACHE = {}

# ================= 工具函数 =================
def normalize_answer(ans):
    """标准化答案：转小写，去除非字母数字符号"""
    if not ans: return ""
    return re.sub(r"[^0-9a-zA-Z]", "", str(ans)).lower()

def extract_answer_from_text(text):
    """提取最后一个 \\boxed{...}"""
    if not text: return "N/A"
    pattern = r"\\boxed\s*\{([^}]+)\}"
    matches = re.findall(pattern, text)
    if matches:
        return matches[-1].strip()
    return "N/A"

def load_ground_truth_maps():
    """
    加载原始数据，构建两个映射表：
    1. ID -> Answer (标准匹配)
    2. Question -> Answer (兜底匹配，防止 ID 为 Unknown)
    """
    id_map = {}
    q_map = {}
    
    if not os.path.exists(DATA_FILE):
        print(f"⚠️ Warning: Data file {DATA_FILE} not found. Correctness might be inaccurate.")
        return id_map, q_map
        
    print(f"📖 Loading Ground Truth from {DATA_FILE}...")
    with open(DATA_FILE, 'r', encoding='utf-8') as f:
        for line in f:
            if line.strip():
                try:
                    item = json.loads(line)
                    pid = str(item.get("ID") or item.get("id") or item.get("problem_id"))
                    
                    # 提取 GT 中的纯净答案
                    raw_ans = item.get("Answer") or item.get("answer")
                    clean_ans = extract_answer_from_text(raw_ans) 
                    
                    question = item.get("Question") or item.get("question") or item.get("problem")
                    
                    if clean_ans and clean_ans != "N/A":
                        if pid and pid != "None":
                            id_map[pid] = clean_ans
                        
                        # 存入 Question 映射 (取前100个字符作为指纹)
                        if question:
                            q_key = question.strip()[:100] 
                            q_map[q_key] = clean_ans
                except:
                    continue
    print(f"   ✅ Loaded {len(id_map)} IDs and {len(q_map)} Questions for GT matching.")
    return id_map, q_map

def clean_repetition(full_text, prompt_text):
    """防复读清洗逻辑"""
    if prompt_text and full_text.startswith(prompt_text):
        gen_part = full_text[len(prompt_text):]
    elif "Answer this step by step" in full_text:
        parts = full_text.split("Answer this step by step and put the final answer in \\boxed{}.")
        if len(parts) > 1:
            gen_part = parts[-1]
            prompt_text = full_text[:len(full_text)-len(gen_part)]
        else:
            return full_text
    else:
        return full_text

    # 查找所有 boxed
    boxed_iter = re.finditer(r"\\boxed\s*\{[^}]+\}", gen_part, re.DOTALL)
    boxed_matches = list(boxed_iter)
    
    if boxed_matches:
        first_match = boxed_matches[0]
        end_pos = first_match.end()
        buffer_len = 200 # 保留缓冲
        real_cutoff = min(len(gen_part), end_pos + buffer_len)
        
        # 如果后面还有大量内容，视为复读进行截断
        if len(gen_part) > real_cutoff + 100:
            print(f"      ✂️ [Cleaner] Truncating repetition: {len(gen_part)} -> {real_cutoff} chars.")
            gen_part_clean = gen_part[:real_cutoff]
            return prompt_text + gen_part_clean
            
    return full_text

# ================= 核心 Metric 计算 (逻辑已修改) =================
def calculate_metrics_cpu(layer_dict, attention_mask_cpu):
    """
    修改后的逻辑：
    1. 堆叠所有层 -> (Layers, Batch, Seq, Dim)
    2. 对每一层分别计算相邻 Token 的 Diff Norm 和 Angle -> (Layers, Batch, Seq-1)
    3. 对层维度 (Layers) 取平均 -> (Batch, Seq-1)
    """
    sorted_keys = sorted(layer_dict.keys())
    if not sorted_keys: return []

    # 1. Stack: (Layers, Batch, Seq, Dim)
    stacked_layers = torch.stack([layer_dict[k] for k in sorted_keys], dim=0)
    
    # 维度修正
    if stacked_layers.dim() == 3:
        stacked_layers = stacked_layers.unsqueeze(1)
    
    # 2. 准备相邻 Token (保留 Layers 维度)
    curr = stacked_layers[:, :, 1:, :]
    prev = stacked_layers[:, :, :-1, :]
    
    # 3. 计算每一层的 Diff Norm
    diff_vectors = curr - prev
    layer_diff_norms = torch.norm(diff_vectors, p=2, dim=-1)
    
    del diff_vectors

    # 4. 计算每一层的 Angle
    layer_cos_sim = F.cosine_similarity(curr, prev, dim=-1, eps=1e-8)
    
    del stacked_layers, curr, prev

    layer_cos_sim = torch.clamp(layer_cos_sim, -1.0 + 1e-7, 1.0 - 1e-7)
    layer_angles = torch.rad2deg(torch.acos(layer_cos_sim))
    
    # 5. 【关键修改】对层维度 (dim=0) 取平均
    avg_diff_norms = torch.mean(layer_diff_norms, dim=0)
    avg_angles = torch.mean(layer_angles, dim=0)
    
    # 6. 处理 Mask
    if attention_mask_cpu.dim() == 1:
        attention_mask_cpu = attention_mask_cpu.unsqueeze(0)
    valid_mask = attention_mask_cpu[:, 1:] == 1
    
    # 7. Flatten 提取有效值
    d_flat = avg_diff_norms.reshape(-1)
    a_flat = avg_angles.reshape(-1)
    m_flat = valid_mask.reshape(-1)
    
    final_diffs = d_flat[m_flat].tolist()
    final_angles = a_flat[m_flat].tolist()
    
    return [(final_diffs, final_angles)]

def get_layer_output_hook(layer_idx):
    def hook(module, input, output):
        # 立即转移到 CPU float32
        CPU_LAYER_CACHE[layer_idx] = output[0].detach().cpu().to(torch.float32)
    return hook

# ================= 主流程 =================
def run_full_analysis():
    print(f"\n🚀 Starting Full Analysis (Metric: Mean of Layer Diffs)")
    
    if not os.path.exists(TEMP_GEN_FILE):
        print(f"❌ Cache file {TEMP_GEN_FILE} not found.")
        return

    # 1. 加载 Ground Truth
    id_map, q_map = load_ground_truth_maps()

    # 2. 读取 vLLM 生成数据
    with open(TEMP_GEN_FILE, 'rb') as f:
        all_data = pickle.load(f)
    print(f"📦 Loaded {len(all_data)} items from cache.")

    # === 修改点：只取前 150 条 ===
    all_data = all_data[:150]
    print(f"✂️ Sliced to first {len(all_data)} items for analysis.")
    # ============================

    # 3. 扫描已处理 (断点续传)
    processed_keys = set()
    if os.path.exists(OUTPUT_FILE):
        print(f"📂 Scanning output: {OUTPUT_FILE}...")
        try:
            with open(OUTPUT_FILE, 'r', encoding='utf-8') as f:
                for line in f:
                    if line.strip():
                        try:
                            rec = json.loads(line)
                            processed_keys.add(f"{rec['problem_id']}_{rec['cot_index']}")
                        except: pass
            print(f"⏩ Found {len(processed_keys)} processed items. Resuming...")
        except: pass

    items_to_process = [d for d in all_data if f"{d['problem_id']}_{d['cot_index']}" not in processed_keys]
    if not items_to_process:
        print("✅ All items already processed.")
        return

    # 4. 加载模型
    print(f"🔧 Loading Model (Weights on GPU)...")
    model = AutoModelForCausalLM.from_pretrained(
        MODEL_PATH,
        device_map="auto",
        torch_dtype=torch.bfloat16,
        trust_remote_code=True,
        output_hidden_states=False 
    ).eval()
    
    tokenizer = AutoTokenizer.from_pretrained(MODEL_PATH, trust_remote_code=True)
    if tokenizer.pad_token is None: tokenizer.pad_token = tokenizer.eos_token
        
    layers = model.model.layers if hasattr(model, "model") else model.layers
    hooks = [layer.register_forward_hook(get_layer_output_hook(i)) for i, layer in enumerate(layers)]
    print(f"⚓ Hooks registered on {len(layers)} layers.")

    # 5. 循环处理
    total = len(items_to_process)
    for idx, item in enumerate(items_to_process):
        print(f"   [{idx+1}/{total}] Processing {item['problem_id']} (CoT {item['cot_index']})...")
        CPU_LAYER_CACHE.clear() 
        
        try:
            # === A. 准备 Prompt 用于清洗和匹配 ===
            raw_text = item["full_text"]
            prompt_text = item.get("prompt_text", "")
            if not prompt_text:
                if "Problem:" in raw_text:
                    prompt_text = raw_text.split("Answer this step by step")[0].strip()
                else:
                    prompt_text = "Problem:"

            # === B. 修正 Ground Truth 和 Correctness ===
            pid = str(item['problem_id'])
            gt_ans = "N/A"
            
            # 1. 找 GT
            if pid in id_map:
                gt_ans = id_map[pid]
            else:
                # 模糊匹配
                clean_q = prompt_text.replace("Problem:", "").strip()[:100]
                if clean_q in q_map:
                    gt_ans = q_map[clean_q]
            
            # 2. 提取 Extract Answer
            extracted_ans = item.get('extracted_answer')
            if not extracted_ans or extracted_ans == "N/A":
                extracted_ans = extract_answer_from_text(raw_text)

            # 3. 判定
            is_correct_final = False
            if gt_ans != "N/A":
                is_correct_final = normalize_answer(extracted_ans) == normalize_answer(gt_ans)
            else:
                is_correct_final = item['is_correct']

            # === C. 清洗复读 ===
            full_prompt_for_clean = prompt_text + "Answer this step by step and put the final answer in \\boxed{}."
            if "Answer this" not in prompt_text: full_prompt_for_clean = prompt_text 
            
            clean_text = clean_repetition(raw_text, full_prompt_for_clean)

            # === D. Tokenize & Forward ===
            inputs = tokenizer([clean_text], return_tensors="pt", padding=True, truncation=True, max_length=MAX_NEW_TOKENS).to(model.device)
            prompt_ids = tokenizer([prompt_text], add_special_tokens=True)["input_ids"][0]
            prompt_len = len(prompt_ids)
            
            with torch.no_grad():
                model(**inputs)
            
            # === E. CPU Metrics (Using New Logic) ===
            metrics = calculate_metrics_cpu(CPU_LAYER_CACHE, inputs.attention_mask.cpu())
            d_norms, angs = metrics[0] 
            
            start = max(0, prompt_len - 1)
            cot_d = d_norms[start:]
            cot_a = angs[start:]
            
            avg_d = float(np.mean(cot_d)) if cot_d else 0.0
            avg_a = float(np.mean(cot_a)) if cot_a else 0.0
            
            # === F. 写入 ===
            res = {
                "problem_id": item["problem_id"],
                "cot_index": item["cot_index"],
                "is_correct": is_correct_final, 
                "extracted_answer": extracted_ans,
                "avg_diff_norm": avg_d,
                "avg_angle": avg_a,
            }
            
            with open(OUTPUT_FILE, 'a') as f:
                f.write(json.dumps(res) + "\n")
                
        except Exception as e:
            print(f"❌ Error on {item['problem_id']}: {e}")
            torch.cuda.empty_cache()
            
            err_res = {
                "problem_id": item["problem_id"],
                "cot_index": item["cot_index"],
                "is_correct": item.get('is_correct', False),
                "avg_diff_norm": -1.0,
                "avg_angle": -1.0,
                "error": str(e)
            }
            with open(OUTPUT_FILE, 'a') as f:
                f.write(json.dumps(err_res) + "\n")

    for h in hooks: h.remove()
    print(f"\n✅ All tasks finished. Results saved to {OUTPUT_FILE}")

if __name__ == "__main__":
    run_full_analysis()