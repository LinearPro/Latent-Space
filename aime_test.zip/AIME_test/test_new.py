import json
import os

input_file = 'aime2024_full_analysis_metrics_1.jsonl'
output_file = 'aime2024_analysis_filtered_4000.jsonl'

if os.path.exists(input_file):
    count_kept = 0
    count_removed = 0
    
    with open(input_file, 'r', encoding='utf-8') as fin, \
         open(output_file, 'w', encoding='utf-8') as fout:
        
        for line in fin:
            if not line.strip():
                continue
            
            try:
                item = json.loads(line)
                
                # 过滤条件：如果 calc_token_count 为 8000 则跳过
                if item.get('calc_token_count') == 8000:
                    count_removed += 1
                    continue
                
                # 写入保留的记录
                fout.write(json.dumps(item, ensure_ascii=False) + "\n")
                count_kept += 1
                
            except json.JSONDecodeError:
                continue

    print(f"处理完成。")
    print(f"已移除 (count=8000): {count_removed} 条")
    print(f"已保留: {count_kept} 条")
    print(f"结果已保存至: {output_file}")
else:
    print(f"错误: 未找到文件 {input_file}")