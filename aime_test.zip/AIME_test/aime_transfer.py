import json

# 输入和输出文件名
input_file = "aime2025.jsonl"
output_file = "aime2025_ready.jsonl"

# 定义提示词模板 (激发 CoT 能力)
# 注意：对于 Thinking 模型，明确要求输出格式 (\boxed{}) 非常重要
PROMPT_TEMPLATE = (
    "Problem: {question}\n\n"
    "Please reason step by step, and put your final answer within \\boxed{{}}."
)

valid_count = 0

with open(input_file, 'r', encoding='utf-8') as fin, \
     open(output_file, 'w', encoding='utf-8') as fout:
    
    for line in fin:
        try:
            item = json.loads(line)
            
            # 1. 过滤脏数据
            # AIME 题目通常有 'ID' 且答案通常是纯数字（或字符串形式的数字）
            # 过滤掉最后那两个 ID="1" 且答案是非数字字符的条目
            ans = str(item.get("answer", ""))
            if not ans.isdigit():
                print(f"Skipping non-integer answer ID {item.get('ID')}: {ans[:20]}...")
                continue
                
            # 2. 构造符合 EvalScope 标准的格式
            new_item = {
                # 将 query 修改为包含 Prompt 的完整输入
                "query": PROMPT_TEMPLATE.format(question=item["question"]),
                # 保留原始答案
                "response": ans,
                # 保留 ID 方便后续追踪
                "id": item.get("ID")
            }
            
            fout.write(json.dumps(new_item, ensure_ascii=False) + "\n")
            valid_count += 1
            
        except Exception as e:
            print(f"Error parsing line: {e}")

print(f"\n成功处理 {valid_count} 条有效 AIME 题目，已保存至 {output_file}")