# 激活环境
conda activate eval_env

# 启动 vLLM Server
# --port 8000: 服务端口
# --max-model-len 16384: 限制长度防止炸显存
# --gpu-memory-utilization 0.9: 显存利用率
python -m vllm.entrypoints.openai.api_server \
    --model "/WORK/PUBLIC/dongyinp_work/lingp/models/Qwen3-4B-Thinking-2507" \
    --served-model-name "Qwen3-Thinking" \
    --tensor-parallel-size 1 \
    --trust-remote-code \
    --max-model-len 16384 \
    --port 8000