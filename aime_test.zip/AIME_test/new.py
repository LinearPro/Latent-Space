import os
import json
import torch
import numpy as np
import random
import re
import gc
from tqdm import tqdm
from scipy.stats import zscore
from vllm import LLM, SamplingParams
from transformers import AutoModelForCausalLM, AutoTokenizer
from vllm.distributed.parallel_state import destroy_model_parallel

# ================= 配置区域 =================

MODEL_PATH = "/WORK/PUBLIC/dongyinp_work/lingp/models/Qwen3-4B-Thinking-2507"
INPUT_FILE = "aime2024.jsonl"
OUTPUT_FILE = "aime2024_cot_labeled_40samples.jsonl"
INTERMEDIATE_FILE = "aime2024_cot_intermediate_labeled.jsonl"

TARGET_IDS = ["5", "26", "29", "30"]

CANDIDATE_POOL_SIZE = 40   # 修改：生成 40 条
PREFIX_LEN = 8000          
MAX_TOTAL_LEN = 81920      # 修改：允许超长生成

# 动力学评分权重
W_DECEL = 1.5  
W_FRIC  = 1.2  
W_CONV  = 1.0  

# 全局随机种子
GLOBAL_SEED = 42

# ================= 工具函数 =================

def set_global_seed(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed(seed)
        torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False
    print(f"🔒 Global seed set to {seed}")

def clean_gpu():
    gc.collect()
    torch.cuda.empty_cache()
    try:
        import torch.distributed as dist
        if dist.is_initialized():
            dist.destroy_process_group()
    except:
        pass

def normalize_answer(ans):
    if ans is None: return ""
    ans_str = str(ans).strip()
    ans_str = re.sub(r'\\text\{([^}]+)\}', r'\1', ans_str)
    if ans_str.endswith('.0'): ans_str = ans_str[:-2]
    return ans_str

def calculate_dual_metrics(hidden_states, seq_len):
    """ 计算 Macro/Micro 指标 """
    num_layers = len(hidden_states)
    checkpoints = [2000, 4000, 8000]
    window = 100
    results = {}
    
    for cp in checkpoints:
        if cp > seq_len:
            results[cp] = None
            continue
            
        start = max(0, cp - window)
        end = min(seq_len, cp + window)
        
        layer_tensors = [hidden_states[l][0, start:end, :].float() for l in range(num_layers)]
        stack = torch.stack(layer_tensors, dim=0) 
        
        # --- Micro Metrics ---
        stack_micro = stack.permute(1, 0, 2) 
        diffs_micro = stack_micro[1:] - stack_micro[:-1]
        
        d2 = torch.norm(diffs_micro, p=2, dim=-1).mean().item()
        
        if diffs_micro.shape[0] < 2:
            a2 = 0.0
        else:
            v_curr = diffs_micro[1:]
            v_prev = diffs_micro[:-1]
            dot = (v_curr * v_prev).sum(dim=-1)
            n_c = torch.norm(v_curr, p=2, dim=-1)
            n_p = torch.norm(v_prev, p=2, dim=-1)
            cos = torch.clamp(dot / (n_c * n_p + 1e-8), -1.0, 1.0)
            a2 = (torch.acos(cos) * (180/np.pi)).mean().item()

        # --- Macro Metrics ---
        avg_hidden = stack.mean(dim=0) 
        diffs_macro = avg_hidden[1:] - avg_hidden[:-1]
        d1 = torch.norm(diffs_macro, p=2, dim=-1).mean().item()
        
        if diffs_macro.shape[0] < 2:
            a1 = 0.0
        else:
            v_curr = diffs_macro[1:]
            v_prev = diffs_macro[:-1]
            dot = (v_curr * v_prev).sum(dim=-1)
            n_c = torch.norm(v_curr, p=2, dim=-1)
            n_p = torch.norm(v_prev, p=2, dim=-1)
            cos = torch.clamp(dot / (n_c * n_p + 1e-8), -1.0, 1.0)
            a1 = (torch.acos(cos) * (180/np.pi)).mean().item()
            
        results[cp] = {'D1': d1, 'A1': a1, 'D2': d2, 'A2': a2}
        
    return results

# ================= Stage 1: vLLM 强制生成前缀 =================

def stage_1_generate_prefixes(problems):
    print("\n🚀 [Stage 1] vLLM Generating Prefixes (FORCE 8000 tokens)...")
    
    clean_gpu()
    llm = LLM(
        model=MODEL_PATH, 
        tensor_parallel_size=4, 
        trust_remote_code=True,
        gpu_memory_utilization=0.7,
        seed=GLOBAL_SEED,
        enforce_eager=True 
    )
    
    sampling_params = SamplingParams(
        n=1,
        temperature=0.6,
        top_p=0.95,
        max_tokens=PREFIX_LEN, 
        min_tokens=PREFIX_LEN, 
        ignore_eos=True,        
        repetition_penalty=1.05,
        seed=GLOBAL_SEED 
    )
    
    prompts = []
    metadata = []
    
    for p in problems:
        p_id = str(p['ID'])
        prompt_text = f"<|im_start|>user\n{p['question']}\n\nPlease reason step by step and put your final answer within \\boxed{{}}.\n<|im_start|>assistant\n"
        
        for i in range(CANDIDATE_POOL_SIZE):
            prompts.append(prompt_text)
            metadata.append({'id': p_id, 'sample_idx_raw': i, 'prompt_text': prompt_text})
            
    print(f"Generating {len(prompts)} candidates...")
    outputs = llm.generate(prompts, sampling_params)
    
    candidates = {} 
    
    for meta, output in zip(metadata, outputs):
        p_id = meta['id']
        if p_id not in candidates: candidates[p_id] = []
        
        token_ids = output.outputs[0].token_ids
        text = output.outputs[0].text
        
        candidates[p_id].append({
            'sample_idx_raw': meta['sample_idx_raw'],
            'token_ids': token_ids,
            'prefix_text': text,
            'prompt_text': meta['prompt_text'],
            'gen_len': len(token_ids)
        })
        
    destroy_model_parallel()
    del llm
    clean_gpu()
    print("✅ Stage 1 Complete. vLLM memory released.")
    
    return candidates

# ================= Stage 2 & 3: 分析、评分与打标 =================

def stage_2_analyze_and_label(candidates_dict):
    print("\n🔬 [Stage 2] Transformers Latent Dynamics Analysis & Labeling...")
    
    tokenizer = AutoTokenizer.from_pretrained(MODEL_PATH, trust_remote_code=True)
    model = AutoModelForCausalLM.from_pretrained(
        MODEL_PATH, device_map="auto", torch_dtype=torch.bfloat16, trust_remote_code=True
    )
    model.eval()
    
    final_tasks = []
    
    for p_id, cands in candidates_dict.items():
        print(f"Analyzing Problem {p_id} ({len(cands)} candidates)...")
        analyzed_cands = []
        
        for c in tqdm(cands, desc="Calculating Metrics"):
            if c['gen_len'] < 7800: continue 
            
            prompt_ids = tokenizer.encode(c['prompt_text'], add_special_tokens=False)
            full_ids = prompt_ids + c['token_ids']
            input_tensor = torch.tensor([full_ids], device=model.device)
            
            with torch.no_grad():
                outputs = model(input_tensor, output_hidden_states=True)
                
            cot_hidden_states = []
            for layer_out in outputs.hidden_states:
                cot_hidden_states.append(layer_out[:, len(prompt_ids):, :])
            
            metrics = calculate_dual_metrics(cot_hidden_states, c['gen_len'])
            c['metrics'] = metrics
            analyzed_cands.append(c)
            
        # === Stage 3: 动力学评分与标签分配 ===
        valid_cands = [c for c in analyzed_cands if c['metrics'].get(8000) is not None]
        
        if not valid_cands:
            print(f"Warning: No candidates reached 8000 tokens for Problem {p_id}.")
            continue
            
        d1_2k = np.array([c['metrics'][2000]['D1'] for c in valid_cands])
        d1_4k = np.array([c['metrics'][4000]['D1'] for c in valid_cands])
        delta_d1 = d1_4k - d1_2k
        
        a1_8k = np.array([c['metrics'][8000]['A1'] for c in valid_cands])
        a2_8k = np.array([c['metrics'][8000]['A2'] for c in valid_cands])
        gap_8k = a2_8k - a1_8k
        
        a1_4k = np.array([c['metrics'][4000]['A1'] for c in valid_cands])
        delta_a1 = a1_8k - a1_4k
        
        def safe_z(arr): return zscore(arr) if np.std(arr) > 1e-6 else np.zeros_like(arr)
        
        # 综合评分 (越低越好)
        scores = 1.5 * safe_z(delta_d1) + 1.2 * safe_z(gap_8k) + 1.0 * safe_z(delta_a1)
        
        # 排序: 从小到大 (Best -> Worst)
        sorted_indices = np.argsort(scores)
        
        # 划分前20和后20
        # 注意: 即使 valid_cands 不足 40 个，我们依然把排名前 20 的标记为 True，剩下的标记为 False
        # 如果 valid_cands > 40 (一般不会)，则只取前 40
        
        count = len(sorted_indices)
        top_cut = 20
        
        print(f"Problem {p_id}: Total Valid {count}. Best Score {scores[sorted_indices[0]]:.2f}, Worst {scores[sorted_indices[-1]]:.2f}")
        
        for rank, idx in enumerate(sorted_indices):
            if rank >= 40: break # 只处理前40个（如果有多的）
            
            cand = valid_cands[idx]
            
            # 标签逻辑: 排名 < 20 (即第1-20名) -> True; 排名 >= 20 (即第21-40名) -> False
            predict_label = True if rank < top_cut else False
            
            final_tasks.append({
                'id': p_id,
                'prompt_text': cand['prompt_text'],
                'prefix_text': cand['prefix_text'],
                'sample_index': cand['sample_idx_raw'],
                'predict': predict_label, # 打标
                'score': float(scores[idx]), # 记录分数方便后续分析
                'rank': rank
            })
            
    del model
    del tokenizer
    clean_gpu()
    print("✅ Stage 2 & 3 Complete. All 40 candidates labeled.")
    
    print(f"💾 Saving intermediate tasks to {INTERMEDIATE_FILE}...")
    with open(INTERMEDIATE_FILE, 'w', encoding='utf-8') as f:
        for task in final_tasks:
            f.write(json.dumps(task, ensure_ascii=False) + "\n")
            
    return final_tasks

# ================= Stage 4: vLLM 全量续写 =================

def stage_4_continue_generation(tasks):
    print("\n🚀 [Stage 4] Finalizing Answers for ALL candidates...")
    
    gt_map = {}
    with open(INPUT_FILE, 'r') as f:
        for line in f:
            if not line.strip(): continue
            item = json.loads(line)
            gt_map[str(item['ID'])] = normalize_answer(item.get('answer'))

    results = []
    tasks_to_gen = []
    
    # 1. 检查前缀
    for t in tasks:
        matches = re.findall(r'\\boxed\{([^}]+)\}', t['prefix_text'])
        if matches:
            ans = matches[-1].strip()
            norm_ans = normalize_answer(ans)
            ground_truth = gt_map.get(t['id'], "")
            
            results.append({
                "id": t['id'],
                "sample_index": t['sample_index'],
                "ground_truth": ground_truth,
                "model_answer": ans,
                "is_correct": (norm_ans == ground_truth),
                "token_count": PREFIX_LEN, 
                "predict": t['predict'], # 保留标签
                "score": t['score'],     # 保留分数
                "response": t['prefix_text']
            })
        else:
            tasks_to_gen.append(t)
            
    # 2. 续写
    if tasks_to_gen:
        print(f"🚀 vLLM Continuing Generation for {len(tasks_to_gen)} incomplete tasks...")
        llm = LLM(
            model=MODEL_PATH, 
            tensor_parallel_size=4, 
            trust_remote_code=True,
            gpu_memory_utilization=0.75,
            seed=GLOBAL_SEED 
        )
        sampling_params = SamplingParams(
            n=1, temperature=0.6, top_p=0.95,
            max_tokens=MAX_TOTAL_LEN - PREFIX_LEN, stop=["<|im_end|>", "<|endoftext|>"],
            seed=GLOBAL_SEED 
        )
        
        prompts = [t['prompt_text'] + t['prefix_text'] for t in tasks_to_gen]
        outputs = llm.generate(prompts, sampling_params)
        
        for task, output in zip(tasks_to_gen, outputs):
            continuation = output.outputs[0].text
            full_response = task['prefix_text'] + continuation
            
            matches = re.findall(r'\\boxed\{([^}]+)\}', full_response)
            model_ans = matches[-1].strip() if matches else ""
            norm_ans = normalize_answer(model_ans)
            ground_truth = gt_map.get(task['id'], "")
            
            results.append({
                "id": task['id'],
                "sample_index": task['sample_index'],
                "ground_truth": ground_truth,
                "model_answer": model_ans,
                "is_correct": (norm_ans == ground_truth),
                "token_count": PREFIX_LEN + len(output.outputs[0].token_ids),
                "predict": task['predict'], # 保留标签
                "score": task['score'],     # 保留分数
                "response": full_response
            })
            
    return results

# ================= 主程序 =================

def main():
    set_global_seed(GLOBAL_SEED)
    
    if not os.path.exists(OUTPUT_FILE):
        with open(OUTPUT_FILE, 'w') as f: pass

    problems = []
    with open(INPUT_FILE, 'r') as f:
        for line in f:
            if not line.strip(): continue
            item = json.loads(line)
            if str(item['ID']) in TARGET_IDS:
                problems.append(item)
    
    # 1. 强制生成 40 条
    candidates = stage_1_generate_prefixes(problems)
    
    # 2. 评分并打标 (Predict True/False)
    labeled_tasks = stage_2_analyze_and_label(candidates)
    
    # 3. 全量提取结果
    if labeled_tasks:
        final_results = stage_4_continue_generation(labeled_tasks)
        print(f"Saving {len(final_results)} results to {OUTPUT_FILE}...")
        with open(OUTPUT_FILE, 'w', encoding='utf-8') as f:
            for r in final_results:
                f.write(json.dumps(r, ensure_ascii=False) + "\n")
    else:
        print("CRITICAL: No candidates survived analysis!")
        
    print("All Done.")

if __name__ == "__main__":
    main()