import json
import os
import asyncio
from openai import AsyncOpenAI
from tqdm.asyncio import tqdm
import re

# ================= 配置区域 =================
# 更新为 gpt-oss 的本地路径
MODEL_NAME = "/WORK/PUBLIC/dongyinp_work/lingp/models/gpt-oss" 
INPUT_FILE = "processed_train_repeated_32_times.jsonl"
OUTPUT_FILE = "outputs/aime2026_gpt_oss_new.jsonl" 
PORT = 8022

MAX_TOKENS = 81960  
TEMPERATURE = 0.6
TOP_P = 0.95

# 设定思考深度 (low, medium, high)
REASONING_LEVEL = "high"

# 并发数量控制
CONCURRENCY_LIMIT = 15 
# ===========================================

def extract_cot_and_answer(raw_text):
    """
    从模型输出中提取思维链 (CoT) 和最终答案。
    优先匹配 LaTeX 的 \boxed{} 格式（支持处理嵌套括号），
    兼容后备的 harmony (assistantfinal) 格式。
    """
    if not raw_text:
        return "", ""
        
    cot = raw_text.strip()
    final_answer = raw_text.strip()
    
    # 策略 1：提取 \boxed{} 中的内容（数学题的标准输出）
    # 使用 rfind 从后往前找，确保提取的是最终答案
    boxed_idx = raw_text.rfind(r'\boxed{')
    if boxed_idx != -1:
        start_idx = boxed_idx + 7  # 跳过 '\boxed{'
        stack = 1
        for i in range(start_idx, len(raw_text)):
            if raw_text[i] == '{':
                stack += 1
            elif raw_text[i] == '}':
                stack -= 1
                if stack == 0:
                    final_answer = raw_text[start_idx:i].strip()
                    # 将 \boxed{} 之前的所有内容作为思维链 (CoT)
                    cot = raw_text[:boxed_idx].strip()
                    return cot, final_answer

    # 策略 2：如果模型没生成 \boxed{}，尝试查找 assistantfinal 标记
    if "assistantfinal" in raw_text:
        parts = raw_text.split("assistantfinal")
        final_answer = parts[-1].strip()
        cot = parts[0].replace("analysis", "", 1).strip()
        return cot, final_answer
        
    # 如果都没有匹配到，原样返回
    return cot, final_answer

# 异步处理单个任务的函数
async def process_task(item, client, semaphore, f_out, pbar):
    # 使用信号量限制最大并发数
    async with semaphore:
        query = item['query']
        try:
            response = await client.chat.completions.create(
                model=MODEL_NAME,
                messages=[
                    {"role": "system", "content": f"Reasoning: {REASONING_LEVEL}"},
                    {"role": "user", "content": query}
                ],
                max_tokens=MAX_TOKENS,
                temperature=TEMPERATURE,
                top_p=TOP_P,
                stream=False 
            )
            
            raw_generated_text = response.choices[0].message.content
            finish_reason = response.choices[0].finish_reason
            
            # 提取思维链和最终答案
            cot, final_answer = extract_cot_and_answer(raw_generated_text)
            
            # 将 CoT 和答案整合为一个格式化的字符串
            combined_pred = f"【思考过程】\n{cot}\n\n【最终答案】\n{final_answer}"
            
            # 保存结果
            result = {
                "id": item['id'],
                "query": query,
                "response": item.get('response', ''),
                "raw_pred": raw_generated_text, # 保留最原始的输出
                "cot": cot,                     # 单独保存思考过程
                "pure_answer": final_answer,    # 单独保存纯净的答案(如"277")，方便算Accuracy
                "pred": combined_pred,          # 整合后的字段
                "finish_reason": finish_reason if finish_reason else "stop"
            }
            
            # 写入文件并刷新进度条
            f_out.write(json.dumps(result, ensure_ascii=False) + "\n")
            f_out.flush() 
            
            pbar.update(1)
            
        except Exception as e:
            print(f"\n⚠️ ID {item['id']} 出错: {e}")
            pbar.update(1)

async def async_main():
    print(f"🔧 配置: 单节点全量处理 -> Port {PORT}")
    print(f"🧠 模型: {MODEL_NAME} | 推理等级: {REASONING_LEVEL}")
    
    API_URL = f"http://localhost:{PORT}/v1"
    API_KEY = "EMPTY"

    client = AsyncOpenAI(base_url=API_URL, api_key=API_KEY, timeout=3600.0)
    print(f"🚀 连接服务: {API_URL}")

    if not os.path.exists(INPUT_FILE):
        print(f"❌ 错误: 找不到文件 {INPUT_FILE}")
        return
    
    tasks = []
    with open(INPUT_FILE, 'r', encoding='utf-8') as f:
        for line in f:
            if line.strip():
                tasks.append(json.loads(line))
    
    os.makedirs(os.path.dirname(OUTPUT_FILE), exist_ok=True)
    finished_ids = set()
    if os.path.exists(OUTPUT_FILE):
        with open(OUTPUT_FILE, 'r', encoding='utf-8') as f:
            for line in f:
                try:
                    data = json.loads(line)
                    if 'id' in data: finished_ids.add(data['id'])
                except: pass
    
    tasks_to_run = [t for t in tasks if t['id'] not in finished_ids]
    print(f"⏭️  已完成跳过: {len(finished_ids)} 条, 剩余待处理: {len(tasks_to_run)} 条")

    if not tasks_to_run:
        print("✅ 所有任务已处理完毕！")
        return

    semaphore = asyncio.Semaphore(CONCURRENCY_LIMIT)
    
    with open(OUTPUT_FILE, 'a', encoding='utf-8') as f_out:
        with tqdm(total=len(tasks_to_run), desc="总体进度") as pbar:
            coroutines = [process_task(item, client, semaphore, f_out, pbar) for item in tasks_to_run]
            await asyncio.gather(*coroutines)

    print(f"\n✅ 全部完成！文件保存在: {OUTPUT_FILE}")

def main():
    asyncio.run(async_main())

if __name__ == "__main__":
    main()