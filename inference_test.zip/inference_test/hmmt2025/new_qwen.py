from transformers import AutoConfig
config = AutoConfig.from_pretrained("/WORK/PUBLIC/dongyinp_work/lingp/models/qwen3.5-9B", trust_remote_code=True)
print(config.model_type)