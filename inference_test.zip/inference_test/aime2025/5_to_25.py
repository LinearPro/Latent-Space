import json
from collections import defaultdict

def expand_jsonl(input_file, output_file, target_samples=7):
    # 用于按基础题号存储数据
    problems = defaultdict(list)
    
    # 1. 读取原始数据并按题号分组
    with open(input_file, 'r', encoding='utf-8') as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            
            data = json.loads(line)
            
            # 假设 id 的格式是 "1_sample_0"，提取基础题号 "1"
            base_id = data['id'].split('_sample_')[0]
            problems[base_id].append(data)
            
    print(f"共读取到 {len(problems)} 个独立问题。")

    # 2. 扩充到 25 行并写入新文件
    with open(output_file, 'w', encoding='utf-8') as f:
        for base_id, variations in problems.items():
            num_variations = len(variations)
            
            for i in range(target_samples):
                # 循环利用原有的 5 行数据（例如 i=5 时，取第0个变体）
                orig_data = variations[i % num_variations]
                
                # 复制数据并更新 id
                new_data = orig_data.copy()
                new_data['id'] = f"{base_id}_sample_{i}"
                
                # 写入新的 JSONL 行
                f.write(json.dumps(new_data, ensure_ascii=False) + '\n')

    print(f"处理完成！已将每个问题扩充为 {target_samples} 行，并保存至 {output_file}")

if __name__ == "__main__":
    # 输入和输出文件名
    INPUT_FILE = "aime2025_augmented.jsonl"
    OUTPUT_FILE = "aime2025_augmented_7.jsonl"
    
    expand_jsonl(INPUT_FILE, OUTPUT_FILE, target_samples=7)