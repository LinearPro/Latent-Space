import json
import os
import argparse
from openai import OpenAI
from tqdm import tqdm

# ================= 配置区域 =================
# vLLM 启动时未指定 --served-model-name，默认模型名即为路径
MODEL_NAME = "/WORK/PUBLIC/dongyinp_work/lingp/models/Qwen3-8B" 

# 输入文件路径
INPUT_FILE = "aime2025_augmented.jsonl"

# 推理参数
MAX_TOKENS = 36000  
TEMPERATURE = 0.6
TOP_P = 0.95
# ===========================================

def get_output_filename(part_num):
    """根据部分编号生成输出文件名"""
    return f"outputs/predictions_manual1_aime2025_part{part_num}.jsonl"

def main():
    parser = argparse.ArgumentParser(description="分片运行 vLLM 推理脚本 (带流式输出)")
    parser.add_argument("--part", type=int, choices=[1, 2], required=True, 
                        help="选择运行的部分: 1 (GPU0/8011) 或 2 (GPU1/8022)")
    args = parser.parse_args()

    # --- 1. 自动端口选择逻辑 ---
    if args.part == 1:
        port = 8011
        print("🔧 配置: 使用 Part 1 -> Port 8011 (GPU 0)")
    else:
        port = 8022
        print("🔧 配置: 使用 Part 2 -> Port 8022 (GPU 1)")
    
    API_URL = f"http://localhost:{port}/v1"
    API_KEY = "EMPTY"

    OUTPUT_FILE = get_output_filename(args.part)

    # --- 2. 初始化客户端 ---
    # 设置较长的 timeout (1小时)，防止 DeepSeek/Qwen3 长思考导致超时
    client = OpenAI(base_url=API_URL, api_key=API_KEY, timeout=3600.0)
    print(f"🚀 连接服务: {API_URL}")
    print(f"🤖 模型名称: {MODEL_NAME}")

    # --- 3. 读取数据并切分 ---
    if not os.path.exists(INPUT_FILE):
        print(f"❌ 错误: 找不到文件 {INPUT_FILE}")
        return
    
    all_tasks = []
    with open(INPUT_FILE, 'r', encoding='utf-8') as f:
        for line in f:
            if line.strip():
                all_tasks.append(json.loads(line))
    
    total_count = len(all_tasks)
    mid_point = total_count // 2
    
    if args.part == 1:
        tasks = all_tasks[:mid_point]
        print(f"📂 任务范围: 0 ~ {mid_point-1} (共 {len(tasks)} 条)")
    else:
        tasks = all_tasks[mid_point:]
        print(f"📂 任务范围: {mid_point} ~ {total_count-1} (共 {len(tasks)} 条)")
    
    # --- 4. 准备输出文件与断点续传 ---
    os.makedirs(os.path.dirname(OUTPUT_FILE), exist_ok=True)
    
    finished_ids = set()
    if os.path.exists(OUTPUT_FILE):
        with open(OUTPUT_FILE, 'r', encoding='utf-8') as f:
            for line in f:
                try:
                    data = json.loads(line)
                    if 'id' in data:
                        finished_ids.add(data['id'])
                except:
                    pass
    print(f"⏭️  已完成跳过: {len(finished_ids)} 条")

    # --- 5. 开始推理循环 ---
    # mode='a' 追加模式，保证断点续传
    with open(OUTPUT_FILE, 'a', encoding='utf-8') as f_out:
        # 使用 tqdm 显示进度条
        for item in tqdm(tasks, desc=f"Part {args.part} 进度"):
            if item['id'] in finished_ids:
                continue

            query = item['query']
            
            try:
                # 发起流式请求
                response = client.chat.completions.create(
                    model=MODEL_NAME,
                    messages=[{"role": "user", "content": query}],
                    max_tokens=MAX_TOKENS,
                    temperature=TEMPERATURE,
                    top_p=TOP_P,
                    stream=True
                )
                
                generated_text = ""
                finish_reason = None
                
                # --- [视觉优化] ---
                # 在进度条下方打印 ID，并准备开始流式输出
                print(f"\n\n📝 [ID: {item['id']}] 正在生成:", end="\n", flush=True)
                print("-" * 50)
                
                for chunk in response:
                    # 获取增量内容
                    delta = chunk.choices[0].delta
                    
                    if delta.content:
                        content = delta.content
                        generated_text += content
                        
                        # --- [核心] 实时打印 ---
                        # end="" 防止自动换行
                        # flush=True 强制立即显示，不经过缓存
                        print(content, end="", flush=True)
                    
                    if chunk.choices[0].finish_reason:
                        finish_reason = chunk.choices[0].finish_reason
                
                # --- [结束] ---
                print("\n" + "-" * 50) # 打印分割线，标志该条结束

                # 保存结果
                result = {
                    "id": item['id'],
                    "query": query,
                    "response": item.get('response', ''),
                    "pred": generated_text, # 包含 <think> 和 正文
                    "finish_reason": finish_reason if finish_reason else "stop"
                }
                
                f_out.write(json.dumps(result, ensure_ascii=False) + "\n")
                f_out.flush() # 确保写入磁盘
                
            except KeyboardInterrupt:
                print("\n🛑 用户手动停止")
                break
            except Exception as e:
                print(f"\n⚠️ ID {item['id']} 出错: {e}")
                # 出错时不中断整个循环，继续下一条

    print(f"\n✅ Part {args.part} 全部完成！文件保存在: {OUTPUT_FILE}")

if __name__ == "__main__":
    main()