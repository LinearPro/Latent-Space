import json
import os
import time
from openai import OpenAI
from tqdm import tqdm

# ================= 配置区域 =================
# vLLM 服务地址
API_URL = "http://localhost:8022/v1"
API_KEY = "EMPTY"
MODEL_NAME = "Qwen3-Thinking"  # 必须与 vLLM 启动参数 --served-model-name 一致

# 数据集路径
INPUT_FILE = "aime2024_augmented.jsonl"
OUTPUT_FILE = "outputs/predictions_manual1_aime2024.jsonl"

# 生成参数
MAX_TOKENS = 50000  # 足够的长度给思考过程
TEMPERATURE = 0.6
TOP_P = 0.95

REPETITION_PENALTY = 1.05
# ===========================================

def main():
    # 1. 初始化客户端
    client = OpenAI(base_url=API_URL, api_key=API_KEY, timeout=3600.0)
    print(f"🚀 连接 vLLM 服务: {API_URL}")

    # 2. 读取数据
    if not os.path.exists(INPUT_FILE):
        print(f"❌ 错误: 找不到文件 {INPUT_FILE}")
        return
    
    tasks = []
    with open(INPUT_FILE, 'r', encoding='utf-8') as f:
        for line in f:
            if line.strip():
                tasks.append(json.loads(line))
    
    print(f"📂 加载任务: {len(tasks)} 条")
    
    # 3. 准备输出文件
    os.makedirs(os.path.dirname(OUTPUT_FILE), exist_ok=True)
    # 检查已跑过的 ID (断点续传)
    finished_ids = set()
    if os.path.exists(OUTPUT_FILE):
        with open(OUTPUT_FILE, 'r', encoding='utf-8') as f:
            for line in f:
                try:
                    finished_ids.add(json.loads(line)['id'])
                except:
                    pass
    print(f"⏭️  跳过已完成: {len(finished_ids)} 条")

    # 4. 开始推理循环
    with open(OUTPUT_FILE, 'a', encoding='utf-8') as f_out:
        for item in tqdm(tasks, desc="推理中"):
            if item['id'] in finished_ids:
                continue

            query = item['query']  # 已经是清洗过的 "Problem: ... \nPlease reason..."
            
            try:
                response = client.chat.completions.create(
                    model=MODEL_NAME,
                    messages=[{"role": "user", "content": query}],
                    max_tokens=MAX_TOKENS,
                    temperature=TEMPERATURE,
                    top_p=TOP_P,
                    stream=False,

                  # 【核心修改】通过 extra_body 传递 vLLM 专属参数
                    extra_body={
                        "repetition_penalty": REPETITION_PENALTY
                    }
                )
                
                # 提取内容
                generated_text = response.choices[0].message.content
                
                # 构造结果对象
                result = {
                    "id": item['id'],
                    "query": query,
                    "response": item['response'], # 标准答案
                    "pred": generated_text        # 模型生成的 CoT + 答案
                }
                
                # 实时写入
                f_out.write(json.dumps(result, ensure_ascii=False) + "\n")
                f_out.flush()
                
            except Exception as e:
                print(f"\n⚠️ ID {item['id']} 失败: {e}")

    print(f"\n✅ 评测完成！结果已保存至: {OUTPUT_FILE}")
    print("💡 现在可以使用 score_voting.py 进行评分了。")

if __name__ == "__main__":
    main()