#!/bin/bash

# 模型路径
MODEL_PATH="/WORK/PUBLIC/dongyinp_work/lingp/models/DeepSeek-R1-Distill-Llama-8B"

# ================= 配置说明 (vLLM 0.7.0+ / 0.15.0) =================
# 1. --enable-reasoning: 开启推理模式，API 将返回 reasoning_content 字段。
# 2. --reasoning-parser deepseek_r1: 指定用于解析 <think> 标签的解析器。
#    (Qwen3-Thinking/QwQ 类模型通常兼容此解析器格式)
# 3. --max-model-len 32768: 思考模式极耗显存，为了防止 OOM，建议先设为 32k。
#    (如果你确定 A800 80G 显存充足，可以尝试改回 40000)
# 4. --gpu-memory-utilization 0.95: 尽可能利用显存存放 KV Cache。
# ===================================================================

# 启动第一个实例：显卡0，端口8011
echo "🔵 正在启动 GPU 0 实例 (Port 8011)..."
CUDA_VISIBLE_DEVICES=0 python -m vllm.entrypoints.openai.api_server \
    --model $MODEL_PATH \
    --served-model-name "Qwen3-Thinking" \
    --tensor-parallel-size 1 \
    --trust-remote-code \
    --max-model-len 50000\
    --enable-reasoning \
    --reasoning-parser deepseek_r1 \
    --gpu-memory-utilization 0.95 \
    --port 8011 > vllm_8011.log 2>&1 &

# 启动第二个实例：显卡1，端口8022
echo "🔵 正在启动 GPU 1 实例 (Port 8022)..."
CUDA_VISIBLE_DEVICES=1 python -m vllm.entrypoints.openai.api_server \
    --model $MODEL_PATH \
    --served-model-name "Qwen3-Thinking" \
    --tensor-parallel-size 1 \
    --trust-remote-code \
    --max-model-len 50000 \
    --enable-reasoning \
    --reasoning-parser deepseek_r1 \
    --gpu-memory-utilization 0.95 \
    --port 8022 > vllm_8022.log 2>&1 &

echo "✅ 双路 vLLM 启动命令已发送！"
echo "   - GPU 0 (Part 1): http://localhost:8011"
echo "   - GPU 1 (Part 2): http://localhost:8022"
echo "🔍 正在监视 GPU 0 日志 (按 Ctrl+C 退出监视，服务会在后台继续运行):"
sleep 2
tail -f vllm_8011.log