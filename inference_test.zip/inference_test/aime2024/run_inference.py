import json
import os
import argparse
from openai import OpenAI
from tqdm import tqdm

# ================= 配置区域 =================
# vLLM 服务地址
API_URL = "http://localhost:8022/v1"
API_KEY = "EMPTY"
MODEL_NAME = "Qwen3-Thinking"  # 必须与 vLLM 启动参数 --served-model-name 一致

# 输入文件路径
INPUT_FILE = "aime2024_augmented.jsonl"
# ===========================================

def get_output_filename(part_num):
    """根据部分编号生成输出文件名"""
    return f"outputs/predictions_manual1_aime2024_part{part_num}.jsonl"

def main():
    parser = argparse.ArgumentParser(description="分片运行 vLLM 推理脚本")
    parser.add_argument("--part", type=int, choices=[1, 2], required=True, 
                        help="选择运行的部分: 1 (前半部分) 或 2 (后半部分)")
    args = parser.parse_args()

    OUTPUT_FILE = get_output_filename(args.part)
    
    # --- 这里移除了 REPETITION_PENALTY ---
    MAX_TOKENS = 50000
    TEMPERATURE = 0.6
    TOP_P = 0.95

    # 1. 初始化客户端
    client = OpenAI(base_url=API_URL, api_key=API_KEY, timeout=3600.0)
    print(f"🚀 连接 vLLM 服务: {API_URL}")
    print(f"🧩 正在运行: 第 {args.part} 部分")

    # 2. 读取数据并切分
    if not os.path.exists(INPUT_FILE):
        print(f"❌ 错误: 找不到文件 {INPUT_FILE}")
        return
    
    all_tasks = []
    with open(INPUT_FILE, 'r', encoding='utf-8') as f:
        for line in f:
            if line.strip():
                all_tasks.append(json.loads(line))
    
    total_count = len(all_tasks)
    mid_point = total_count // 2
    
    if args.part == 1:
        tasks = all_tasks[:mid_point]
        print(f"📂 加载前半部分任务: 0 ~ {mid_point-1} (共 {len(tasks)} 条)")
    else:
        tasks = all_tasks[mid_point:]
        print(f"📂 加载后半部分任务: {mid_point} ~ {total_count-1} (共 {len(tasks)} 条)")
    
    # 3. 准备输出文件
    os.makedirs(os.path.dirname(OUTPUT_FILE), exist_ok=True)
    
    # 检查已跑过的 ID (断点续传)
    finished_ids = set()
    if os.path.exists(OUTPUT_FILE):
        with open(OUTPUT_FILE, 'r', encoding='utf-8') as f:
            for line in f:
                try:
                    finished_ids.add(json.loads(line)['id'])
                except:
                    pass
    print(f"⏭️  跳过已完成: {len(finished_ids)} 条")

    # 4. 开始推理循环
    with open(OUTPUT_FILE, 'a', encoding='utf-8') as f_out:
        for item in tqdm(tasks, desc=f"Part {args.part} 推理中"):
            if item['id'] in finished_ids:
                continue

            query = item['query']
            print(f"\n\n--- [Part {args.part}] 正在处理 ID: {item['id']} ---")
            
            try:
                # 调用时去掉了 extra_body 参数
                response = client.chat.completions.create(
                    model=MODEL_NAME,
                    messages=[{"role": "user", "content": query}],
                    max_tokens=MAX_TOKENS,
                    temperature=TEMPERATURE,
                    top_p=TOP_P,
                    stream=True
                )
                
                generated_text = ""
                finish_reason = None
                
                print("生成预览: ", end="", flush=True)
                
                for chunk in response:
                    if chunk.choices[0].delta.content:
                        content = chunk.choices[0].delta.content
                        generated_text += content
                        print(content, end="", flush=True)
                    
                    if chunk.choices[0].finish_reason:
                        finish_reason = chunk.choices[0].finish_reason
                
                print("\n")

                result = {
                    "id": item['id'],
                    "query": query,
                    "response": item['response'],
                    "pred": generated_text,
                    "finish_reason": finish_reason if finish_reason else "stop"
                }
                
                f_out.write(json.dumps(result, ensure_ascii=False) + "\n")
                f_out.flush()
                
            except Exception as e:
                print(f"\n⚠️ ID {item['id']} 失败: {e}")

    print(f"\n✅ Part {args.part} 完成！结果已保存至: {OUTPUT_FILE}")

if __name__ == "__main__":
    main()