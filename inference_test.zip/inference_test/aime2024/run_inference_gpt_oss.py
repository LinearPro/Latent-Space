import json
import os
import asyncio
from openai import AsyncOpenAI
from tqdm.asyncio import tqdm
import re

# ================= 配置区域 =================
# 更新为 gpt-oss 的本地路径
MODEL_NAME = "/WORK/PUBLIC/dongyinp_work/lingp/models/gpt-oss" 
INPUT_FILE = "aime2024_augmented_32.jsonl"
# 更新输出文件名称，以区分不同模型
OUTPUT_FILE = "outputs/aime2024_gpt_oss.jsonl" 
PORT = 8011 # 设定您要使用的端口

MAX_TOKENS = 81960  
TEMPERATURE = 0.6
TOP_P = 0.95

# 设定思考深度 (low, medium, high)
REASONING_LEVEL = "high"

# 并发数量控制
CONCURRENCY_LIMIT = 15 
# ===========================================

# 提取 harmony 格式输出的辅助函数
def parse_harmony_response(raw_text):
    """
    解析 gpt-oss 返回的 harmony 格式字符串，分离思考过程和最终回答。
    """
    if not raw_text:
        return "", ""
        
    thought_process = ""
    final_answer = raw_text
    
    # gpt-oss 通常使用 assistantfinal 标记最终回复，analysis 标记思考过程
    if "assistantfinal" in raw_text:
        parts = raw_text.split("assistantfinal")
        final_answer = parts[-1].strip()
        thought_process = parts[0].replace("analysis", "", 1).strip()
        
    return thought_process, final_answer

# 异步处理单个任务的函数
async def process_task(item, client, semaphore, f_out, pbar):
    # 使用信号量限制最大并发数
    async with semaphore:
        query = item['query']
        try:
            # 发起非流式异步请求 (stream=False)
            response = await client.chat.completions.create(
                model=MODEL_NAME,
                messages=[
                    # 加入 system prompt 控制 reasoning level
                    {"role": "system", "content": f"Reasoning: {REASONING_LEVEL}"},
                    {"role": "user", "content": query}
                ],
                max_tokens=MAX_TOKENS,
                temperature=TEMPERATURE,
                top_p=TOP_P,
                stream=False # 关闭流式输出以提高吞吐量和保持控制台整洁
            )
            
            # gpt-oss 返回的是包含 analysis 和 assistantfinal 的原始字符串
            raw_generated_text = response.choices[0].message.content
            finish_reason = response.choices[0].finish_reason
            
            # 解析出思维链和最终答案
            thought, final_pred = parse_harmony_response(raw_generated_text)
            
            # 保存结果，增加 thought 字段
            result = {
                "id": item['id'],
                "query": query,
                "response": item.get('response', ''),
                "raw_pred": raw_generated_text, # 保留原始输出以备查
                "thought": thought,             # 模型内部的思考过程
                "pred": final_pred,             # 模型最终给用户的答案
                "finish_reason": finish_reason if finish_reason else "stop"
            }
            
            # 写入文件并刷新进度条
            f_out.write(json.dumps(result, ensure_ascii=False) + "\n")
            f_out.flush() 
            
            pbar.update(1) # 更新进度条
            
        except Exception as e:
            print(f"\n⚠️ ID {item['id']} 出错: {e}")
            pbar.update(1)

async def async_main():
    print(f"🔧 配置: 单节点全量处理 -> Port {PORT}")
    print(f"🧠 模型: {MODEL_NAME} | 推理等级: {REASONING_LEVEL}")
    
    API_URL = f"http://localhost:{PORT}/v1"
    API_KEY = "EMPTY"

    # 1. 初始化异步客户端
    client = AsyncOpenAI(base_url=API_URL, api_key=API_KEY, timeout=3600.0)
    print(f"🚀 连接服务: {API_URL}")

    # 2. 读取数据
    if not os.path.exists(INPUT_FILE):
        print(f"❌ 错误: 找不到文件 {INPUT_FILE}")
        return
    
    tasks = []
    with open(INPUT_FILE, 'r', encoding='utf-8') as f:
        for line in f:
            if line.strip():
                tasks.append(json.loads(line))
    
    # 3. 断点续传逻辑
    os.makedirs(os.path.dirname(OUTPUT_FILE), exist_ok=True)
    finished_ids = set()
    if os.path.exists(OUTPUT_FILE):
        with open(OUTPUT_FILE, 'r', encoding='utf-8') as f:
            for line in f:
                try:
                    data = json.loads(line)
                    if 'id' in data: finished_ids.add(data['id'])
                except: pass
    
    tasks_to_run = [t for t in tasks if t['id'] not in finished_ids]
    print(f"⏭️  已完成跳过: {len(finished_ids)} 条, 剩余待处理: {len(tasks_to_run)} 条")

    # 如果没有任务需要跑，直接退出
    if not tasks_to_run:
        print("✅ 所有任务已处理完毕！")
        return

    # 4. 执行异步并发推理
    semaphore = asyncio.Semaphore(CONCURRENCY_LIMIT)
    
    with open(OUTPUT_FILE, 'a', encoding='utf-8') as f_out:
        with tqdm(total=len(tasks_to_run), desc="总体进度") as pbar:
            # 创建所有任务
            coroutines = [process_task(item, client, semaphore, f_out, pbar) for item in tasks_to_run]
            # 并发执行
            await asyncio.gather(*coroutines)

    print(f"\n✅ 全部完成！文件保存在: {OUTPUT_FILE}")

def main():
    asyncio.run(async_main())

if __name__ == "__main__":
    main()