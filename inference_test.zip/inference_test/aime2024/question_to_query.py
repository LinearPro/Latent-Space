import json
import os

def process_jsonl(input_filename, output_filename):
    # 定义要追加到 query 后面的字符串
    suffix = "\n\nPlease reason step by step, and put your final answer within \\boxed{}."
    
    try:
        with open(input_filename, 'r', encoding='utf-8') as infile, \
             open(output_filename, 'w', encoding='utf-8') as outfile:
            
            print(f"正在处理文件: {input_filename} ...")
            count = 0
            
            for line in infile:
                line = line.strip()
                if not line:
                    continue
                
                try:
                    # 解析每一行的 JSON 数据
                    data = json.loads(line)
                    
                    # 创建新的字典来存储转换后的数据
                    new_data = {}
                    
                    # 处理 "question" -> "query"
                    if "question" in data:
                        new_data["query"] = data["question"] + suffix
                    else:
                        # 如果没有 question 字段，保留原样或根据需求处理，这里假设保留原键
                        new_data["query"] = data.get("query", "") + suffix

                    # 处理 "answer" -> "response"
                    if "answer" in data:
                        new_data["response"] = data["answer"]
                    else:
                        new_data["response"] = data.get("response", "")
                    
                    # 写入新文件
                    outfile.write(json.dumps(new_data, ensure_ascii=False) + '\n')
                    count += 1
                    
                except json.JSONDecodeError as e:
                    print(f"无法解析 JSON 行: {line[:50]}... 错误: {e}")
            
            print(f"处理完成！成功转换 {count} 条数据。")
            print(f"输出文件已保存为: {output_filename}")

    except FileNotFoundError:
        print(f"错误: 找不到文件 '{input_filename}'。请确保文件在当前目录下。")
    except Exception as e:
        print(f"发生错误: {e}")

if __name__ == "__main__":
    input_file = 'aime2024_clean.jsonl'
    output_file = 'aime2024_formatted.jsonl'
    
    # 检查输入文件是否存在，如果不存在则创建一个示例文件（为了演示目的）
    if not os.path.exists(input_file):
        print(f"{input_file} 不存在，正在创建示例文件用于演示...")
        sample_data = [
            {"question": "Find the sum of all integer bases $b>9$ for which $17_{b}$ is a divisor of $97_{b}$.", "answer": "70"},
            {"question": "Find the number of ordered pairs $(x,y)$, where both $x$ and $y$ are integers between $-100$ and $100$, inclusive, such that $12x^{2}-xy-6y^{2}=0$.", "answer": "117"}
        ]
        with open(input_file, 'w', encoding='utf-8') as f:
            for item in sample_data:
                f.write(json.dumps(item) + '\n')
    
    process_jsonl(input_file, output_file)