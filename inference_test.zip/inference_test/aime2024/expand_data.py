import json

def expand_dataset(input_path, output_path, new_copies=32):
    unique_items = {}
    
    # 1. 读取原文件并提取所有不重复的题目
    with open(input_path, 'r', encoding='utf-8') as f:
        for line in f:
            if not line.strip():
                continue
            item = json.loads(line)
            # 从 id 中提取原始题目编号 (例如将 "1_sample_0" 提取出 "1")
            base_id = item['id'].split('_sample_')[0]
            
            # 只保留该题目的第一次出现的数据
            if base_id not in unique_items:
                unique_items[base_id] = item
                
    print(f"✅ 成功从原文件中提取了 {len(unique_items)} 道独立题目。")

    # 2. 将每道题目扩增指定的次数（32次）并写入新文件
    total_written = 0
    with open(output_path, 'w', encoding='utf-8') as f:
        for base_id, item in unique_items.items():
            for i in range(new_copies):
                # 浅拷贝原有字典，并生成新的 sample id
                new_item = item.copy()
                new_item['id'] = f"{base_id}_sample_{i}"
                
                # 写入到新文件
                f.write(json.dumps(new_item, ensure_ascii=False) + "\n")
                total_written += 1
                
    print(f"🚀 已完成扩增！共生成 {total_written} 条数据（每题 {new_copies} 次）。")
    print(f"📁 新文件已保存为: {output_path}")

if __name__ == "__main__":
    # 原文件路径
    INPUT_FILE = "aime2024_augmented.jsonl"
    # 生成的新文件路径
    OUTPUT_FILE = "aime2024_augmented_32.jsonl"
    
    expand_dataset(INPUT_FILE, OUTPUT_FILE, new_copies=32)