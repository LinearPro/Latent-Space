import json
import os

def augment_jsonl(input_filename, output_filename, copies_per_problem=7):
    try:
        print(f"正在读取文件: {input_filename} ...")
        
        with open(input_filename, 'r', encoding='utf-8') as infile, \
             open(output_filename, 'w', encoding='utf-8') as outfile:
            
            # 使用 enumerate 追踪题目序号 (start=1 表示从第一题开始)
            for question_idx, line in enumerate(infile, start=1):
                line = line.strip()
                if not line:
                    continue
                
                try:
                    data = json.loads(line)
                    
                    # 为当前题目生成 5 个副本
                    for sample_idx in range(copies_per_problem):
                        # 创建新的字典，确保 id 是第一个字段 (Python 3.7+ 字典有序)
                        new_entry = {
                            "id": f"{question_idx}_sample_{sample_idx}"
                        }
                        # 将原始数据合并进去 (query 和 response)
                        new_entry.update(data)
                        
                        # 写入一行
                        outfile.write(json.dumps(new_entry, ensure_ascii=False) + '\n')
                        
                except json.JSONDecodeError as e:
                    print(f"解析第 {question_idx} 行时出错: {e}")
        
        print(f"处理完成！")
        print(f"每个题目已扩充为 {copies_per_problem} 份。")
        print(f"结果已保存至: {output_filename}")

    except FileNotFoundError:
        print(f"错误: 找不到文件 '{input_filename}'。请确保上一步生成的文件存在。")
    except Exception as e:
        print(f"发生错误: {e}")

if __name__ == "__main__":
    # 输入文件（上一步生成的）
    input_file = 'aime2024_formatted.jsonl'
    # 输出文件
    output_file = 'aime2024_augmented_7.jsonl'
    
    augment_jsonl(input_file, output_file)