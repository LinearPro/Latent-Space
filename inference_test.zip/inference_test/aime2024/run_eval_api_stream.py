import json
import os
import time
from openai import OpenAI
from tqdm import tqdm

# ================= 配置区域 =================
# vLLM 服务地址
API_URL = "http://localhost:8066/v1"
API_KEY = "EMPTY"
MODEL_NAME = "Qwen3-Thinking"  # 必须与 vLLM 启动参数 --served-model-name 一致

# 数据集路径
INPUT_FILE = "aime2024_augmented.jsonl"
OUTPUT_FILE = "outputs/predictions_manual1_aime2024.jsonl"

# 生成参数
MAX_TOKENS = 50000  # 足够的长度给思考过程
TEMPERATURE = 0.6
TOP_P = 0.95

# 重复惩罚参数
REPETITION_PENALTY = 1.05
# ===========================================

def main():
    # 1. 初始化客户端
    # 设置较长的 timeout (例如 1 小时)，防止长推理中断
    client = OpenAI(base_url=API_URL, api_key=API_KEY, timeout=3600.0)
    print(f"🚀 连接 vLLM 服务: {API_URL}")

    # 2. 读取数据
    if not os.path.exists(INPUT_FILE):
        print(f"❌ 错误: 找不到文件 {INPUT_FILE}")
        return
    
    tasks = []
    with open(INPUT_FILE, 'r', encoding='utf-8') as f:
        for line in f:
            if line.strip():
                tasks.append(json.loads(line))
    
    print(f"📂 加载任务: {len(tasks)} 条")
    
    # 3. 准备输出文件
    os.makedirs(os.path.dirname(OUTPUT_FILE), exist_ok=True)
    # 检查已跑过的 ID (断点续传)
    finished_ids = set()
    if os.path.exists(OUTPUT_FILE):
        with open(OUTPUT_FILE, 'r', encoding='utf-8') as f:
            for line in f:
                try:
                    finished_ids.add(json.loads(line)['id'])
                except:
                    pass
    print(f"⏭️  跳过已完成: {len(finished_ids)} 条")

    # 4. 开始推理循环
    with open(OUTPUT_FILE, 'a', encoding='utf-8') as f_out:
        # 注意：流式输出时，tqdm 的进度条可能会被打印内容打断，这是正常的
        for item in tqdm(tasks, desc="推理中"):
            if item['id'] in finished_ids:
                continue

            query = item['query']
            
            # 打印当前正在处理的 ID，方便调试
            print(f"\n\n--- 正在处理 ID: {item['id']} ---")
            
            try:
                # -------------------------------------------------
                # 核心修正：开启 stream=True 并使用循环接收
                # -------------------------------------------------
                response = client.chat.completions.create(
                    model=MODEL_NAME,
                    messages=[{"role": "user", "content": query}],
                    max_tokens=MAX_TOKENS,
                    temperature=TEMPERATURE,
                    top_p=TOP_P,
                    stream=True, # <--- 关键点：开启流式
                    extra_body={
                        "repetition_penalty": REPETITION_PENALTY
                    }
                )
                
                generated_text = ""
                finish_reason = None
                
                print("生成预览: ", end="", flush=True)
                
                # <--- 关键点：流式对象必须通过迭代器处理，不能直接访问 choices
                for chunk in response:
                    # 获取增量内容 (delta.content)
                    if chunk.choices[0].delta.content:
                        content = chunk.choices[0].delta.content
                        generated_text += content
                        # 实时打印到控制台，让你看到进度
                        print(content, end="", flush=True)
                    
                    # 获取结束原因 (通常在最后一块)
                    if chunk.choices[0].finish_reason:
                        finish_reason = chunk.choices[0].finish_reason
                
                print("\n") # 生成结束后换行
                
                # 构造结果对象
                result = {
                    "id": item['id'],
                    "query": query,
                    "response": item['response'],
                    "pred": generated_text,
                    "finish_reason": finish_reason if finish_reason else "stop"
                }
                
                # 实时写入
                f_out.write(json.dumps(result, ensure_ascii=False) + "\n")
                f_out.flush()
                
            except Exception as e:
                # 打印错误详情
                print(f"\n⚠️ ID {item['id']} 失败: {e}")

    print(f"\n✅ 评测完成！结果已保存至: {OUTPUT_FILE}")
    print("💡 现在可以使用 score_voting.py 进行评分了。")

if __name__ == "__main__":
    main()