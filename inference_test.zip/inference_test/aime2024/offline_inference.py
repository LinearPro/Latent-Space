import json
import os
import argparse
from tqdm import tqdm
from vllm import LLM, SamplingParams

# ================= 配置区域 =================
# 模型路径
MODEL_PATH = "/WORK/PUBLIC/dongyinp_work/lingp/models/Qwen3-8B"

# 输入文件路径
INPUT_FILE = "aime2024_augmented.jsonl"
# ===========================================

def get_output_filename(part_num):
    return f"outputs/predictions_offline_aime2024_part{part_num}.jsonl"

def main():
    parser = argparse.ArgumentParser(description="双卡离线 vLLM 推理脚本")
    parser.add_argument("--part", type=int, choices=[1, 2], required=True, 
                        help="选择运行的部分: 1 (GPU0) 或 2 (GPU1)")
    args = parser.parse_args()

    OUTPUT_FILE = get_output_filename(args.part)
    
    # 1. 读取数据并切分
    if not os.path.exists(INPUT_FILE):
        print(f"❌ 错误: 找不到文件 {INPUT_FILE}")
        return
    
    all_tasks = []
    with open(INPUT_FILE, 'r', encoding='utf-8') as f:
        for line in f:
            if line.strip():
                all_tasks.append(json.loads(line))
    
    total_count = len(all_tasks)
    mid_point = total_count // 2
    
    if args.part == 1:
        tasks = all_tasks[:mid_point]
        print(f"📂 [Part 1] 加载任务范围: 0 ~ {mid_point-1} (共 {len(tasks)} 条)")
    else:
        tasks = all_tasks[mid_point:]
        print(f"📂 [Part 2] 加载任务范围: {mid_point} ~ {total_count-1} (共 {len(tasks)} 条)")

    # 2. 检查断点续传
    finished_ids = set()
    if os.path.exists(OUTPUT_FILE):
        with open(OUTPUT_FILE, 'r', encoding='utf-8') as f:
            for line in f:
                try:
                    finished_ids.add(json.loads(line)['id'])
                except:
                    pass
    print(f"⏭️  跳过已完成: {len(finished_ids)} 条")
    
    # 过滤待处理任务
    tasks_to_run = [t for t in tasks if t['id'] not in finished_ids]
    if not tasks_to_run:
        print("✅ 所有任务已完成。")
        return

    # 3. 初始化 vLLM 引擎 (Offline Mode)
    print(f"🚀 [Part {args.part}] 正在加载模型: {MODEL_PATH} ...")
    
    # tensor_parallel_size=1 表示每个进程只用 1 张卡
    # 具体的卡号由外部 bash 脚本的 CUDA_VISIBLE_DEVICES 控制
    llm = LLM(
        model=MODEL_PATH,
        trust_remote_code=True,
        tensor_parallel_size=1, 
        max_model_len=40000, # 确保不爆显存
        dtype="bfloat16",
        gpu_memory_utilization=0.95,
        enforce_eager=True # 加上这个防止之前的缓存冲突报错
    )

    # 4. 设置采样参数
    sampling_params = SamplingParams(
        temperature=0.6,
        top_p=0.95,
        max_tokens=38000, # 输出最大长度
        stop=["\n\n\n", "Question:", "Problem:", "<|endoftext|>"]
    )

    # 5. 准备 Prompt 列表
    # 如果是 Base 模型，直接用 query；如果是 Chat 模型，这里可能需要 apply_chat_template
    # 假设按照你之前的逻辑，直接输入 query
    prompts = [item['query'] for item in tasks_to_run]
    
    print(f"🧩 开始批量推理 {len(prompts)} 条数据...")

    # 6. 执行批量推理 (vLLM 的离线推理非常快)
    # use_tqdm=True 会自动显示进度条
    outputs = llm.generate(prompts, sampling_params)

    # 7. 处理结果并写入文件
    os.makedirs(os.path.dirname(OUTPUT_FILE), exist_ok=True)
    
    with open(OUTPUT_FILE, 'a', encoding='utf-8') as f_out:
        # outputs 的顺序与 prompts 一致，所以我们可以直接 zip
        for task_item, output_item in zip(tasks_to_run, outputs):
            
            generated_text = output_item.outputs[0].text
            finish_reason = output_item.outputs[0].finish_reason

            # --- 后处理：手动截断 \boxed{} ---
            # 离线推理没法流式打断，但可以在生成后裁切
            if "\\boxed{" in generated_text:
                last_box_pos = generated_text.rfind("\\boxed{")
                after_box = generated_text[last_box_pos:]
                
                # 简单的平衡检查
                open_count = after_box.count("{")
                close_count = after_box.count("}")
                
                if close_count >= open_count and close_count > 0:
                    # 找到该段文本中闭合的位置（简化处理：保留到最后）
                    # 或者你保留原样，只标记一下 finish_reason
                    finish_reason = "stop_manual_simulated"

            result = {
                "id": task_item['id'],
                "query": task_item['query'],
                "response": task_item['response'],
                "pred": generated_text,
                "finish_reason": finish_reason
            }
            
            f_out.write(json.dumps(result, ensure_ascii=False) + "\n")
    
    print(f"✅ Part {args.part} 全部完成！")

if __name__ == "__main__":
    main()