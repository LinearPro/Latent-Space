import json
import os
import argparse
import asyncio
from openai import AsyncOpenAI
from tqdm.asyncio import tqdm

# ================= 配置区域 =================
MODEL_NAME = "/WORK/PUBLIC/dongyinp_work/lingp/models/Qwen3-4B-Thinking-2507" 
INPUT_FILE = "aime2024_augmented_32.jsonl"

MAX_TOKENS = 40960  
TEMPERATURE = 0.6
TOP_P = 0.95

# 【新增】并发数量控制
# 您的日志显示最大并发是 24 左右，这里设置为 15-20 是比较安全且高效的值
CONCURRENCY_LIMIT = 20 
# ===========================================

def get_output_filename(part_num):
    return f"outputs/predictions_manual1_aime2024_part{part_num}.jsonl"

# 【新增】异步处理单个任务的函数
async def process_task(item, client, semaphore, f_out, pbar):
    # 使用信号量限制最大并发数
    async with semaphore:
        query = item['query']
        try:
            # 发起非流式异步请求 (stream=False)
            response = await client.chat.completions.create(
                model=MODEL_NAME,
                messages=[{"role": "user", "content": query}],
                max_tokens=MAX_TOKENS,
                temperature=TEMPERATURE,
                top_p=TOP_P,
                stream=False # 关闭流式输出以提高吞吐量和保持控制台整洁
            )
            
            generated_text = response.choices[0].message.content
            finish_reason = response.choices[0].finish_reason
            
            # 保存结果
            result = {
                "id": item['id'],
                "query": query,
                "response": item.get('response', ''),
                "pred": generated_text,
                "finish_reason": finish_reason if finish_reason else "stop"
            }
            
            # 写入文件并刷新进度条
            f_out.write(json.dumps(result, ensure_ascii=False) + "\n")
            f_out.flush() 
            
            pbar.update(1) # 更新进度条
            
        except Exception as e:
            print(f"\n⚠️ ID {item['id']} 出错: {e}")
            pbar.update(1)

async def async_main():
    parser = argparse.ArgumentParser(description="分片运行 vLLM 推理脚本 (异步高并发版)")
    parser.add_argument("--part", type=int, choices=[1, 2], required=True)
    args = parser.parse_args()

    port = 8011 if args.part == 1 else 8022
    print(f"🔧 配置: 使用 Part {args.part} -> Port {port}")
    
    API_URL = f"http://localhost:{port}/v1"
    API_KEY = "EMPTY"
    OUTPUT_FILE = get_output_filename(args.part)

    # 1. 初始化异步客户端
    client = AsyncOpenAI(base_url=API_URL, api_key=API_KEY, timeout=3600.0)
    print(f"🚀 连接服务: {API_URL}")

    # 2. 读取数据
    if not os.path.exists(INPUT_FILE):
        print(f"❌ 错误: 找不到文件 {INPUT_FILE}")
        return
    
    all_tasks = []
    with open(INPUT_FILE, 'r', encoding='utf-8') as f:
        for line in f:
            if line.strip():
                all_tasks.append(json.loads(line))
    
    mid_point = len(all_tasks) // 2
    tasks = all_tasks[:mid_point] if args.part == 1 else all_tasks[mid_point:]
    
    # 3. 断点续传逻辑
    os.makedirs(os.path.dirname(OUTPUT_FILE), exist_ok=True)
    finished_ids = set()
    if os.path.exists(OUTPUT_FILE):
        with open(OUTPUT_FILE, 'r', encoding='utf-8') as f:
            for line in f:
                try:
                    data = json.loads(line)
                    if 'id' in data: finished_ids.add(data['id'])
                except: pass
    
    tasks_to_run = [t for t in tasks if t['id'] not in finished_ids]
    print(f"⏭️  已完成跳过: {len(finished_ids)} 条, 剩余待处理: {len(tasks_to_run)} 条")

    # 4. 执行异步并发推理
    semaphore = asyncio.Semaphore(CONCURRENCY_LIMIT)
    
    with open(OUTPUT_FILE, 'a', encoding='utf-8') as f_out:
        with tqdm(total=len(tasks_to_run), desc=f"Part {args.part} 进度") as pbar:
            # 创建所有任务
            coroutines = [process_task(item, client, semaphore, f_out, pbar) for item in tasks_to_run]
            # 并发执行
            await asyncio.gather(*coroutines)

    print(f"\n✅ Part {args.part} 全部完成！文件保存在: {OUTPUT_FILE}")

def main():
    asyncio.run(async_main())

if __name__ == "__main__":
    main()