#!/bin/bash

echo "=========================================="
echo "🚀 开始双卡离线并行推理 (Offline Inference)"
echo "   - Part 1 -> GPU 0"
echo "   - Part 2 -> GPU 1"
echo "=========================================="


# 启动 Part 1：绑定到显卡 0
# 这里的 & 符号让它在后台运行
CUDA_VISIBLE_DEVICES=0 python offline_inference.py --part 1 > log_part1_offline.txt 2>&1 &
PID1=$!
echo "✅ Part 1 已启动 (GPU 0), PID: $PID1, 日志: log_part1_offline.txt"

# 启动 Part 2：绑定到显卡 1
CUDA_VISIBLE_DEVICES=1 python offline_inference.py --part 2 > log_part2_offline.txt 2>&1 &
PID2=$!
echo "✅ Part 2 已启动 (GPU 1), PID: $PID2, 日志: log_part2_offline.txt"

echo "=========================================="
echo "⏳ 正在运行... 请使用以下命令查看进度："
echo "   tail -f log_part1_offline.txt"
echo "=========================================="

# 等待两个进程都结束
wait $PID1
wait $PID2

echo "🎉 所有推理任务已完成！"