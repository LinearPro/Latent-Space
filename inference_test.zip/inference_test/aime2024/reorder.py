import json
import os
import argparse

def sort_and_save(input_path, output_path):
    """读取 JSONL 文件，按 id 排序后保存到新路径"""
    if not os.path.exists(input_path):
        print(f"❌ 跳过: 找不到文件 {input_path}")
        return
    
    # 1. 读取所有数据
    with open(input_path, 'r', encoding='utf-8') as f:
        data = [json.loads(line) for line in f if line.strip()]
        
    # 2. 定义排序规则：解析类似 "1_sample_0" 的 id，保证按数字大小正确排序
    def sort_key(item):
        id_str = str(item.get('id', ''))
        try:
            # 尝试按 "_" 拆分，提取基础题号和样本号
            # 例如 "30_sample_23" -> base_id=30, sample_id=23
            parts = id_str.split('_')
            base_id = int(parts[0])
            sample_id = int(parts[-1])
            return (base_id, sample_id)
        except:
            # 如果解析失败，则退回到普通的字符串字典序
            return (id_str, 0)
            
    # 3. 执行排序
    data.sort(key=sort_key)
    
    # 4. 写入新文件
    with open(output_path, 'w', encoding='utf-8') as f:
        for item in data:
            f.write(json.dumps(item, ensure_ascii=False) + '\n')
            
    print(f"✅ 排序成功！处理了 {len(data)} 条数据。")
    print(f"   📂 输入: {input_path}")
    print(f"   💾 输出: {output_path}\n")

def main():
    parser = argparse.ArgumentParser(description="对分片推理生成的 JSONL 文件按 ID 严格排序")
    parser.add_argument("--suffix", type=str, required=True, 
                        help="输出文件附加的后缀，例如输入 '1' 会生成 ..._part1_1.jsonl")
    
    args = parser.parse_args()
    
    # 假设您的文件保存在 outputs/ 目录下（根据您之前的脚本推断）
    # 如果就在当前目录，可以将 base_dir 改为 ""
    base_dir = "outputs"
    
    # 循环处理 part1 和 part2
    for part in [1, 2]:
        input_filename = f"predictions_manual1_aime2024_part{part}.jsonl"
        output_filename = f"predictions_manual1_aime2024_part{part}_{args.suffix}.jsonl"
        
        input_path = os.path.join(base_dir, input_filename)
        output_path = os.path.join(base_dir, output_filename)
        
        sort_and_save(input_path, output_path)

if __name__ == "__main__":
    main()