import json

input_file = 'aime2026.jsonl'
output_file = 'aime2026_formatted.jsonl'

# 用于存储解析出的所有 JSON 对象
json_objects = []
current_json = ""

# 逐行读取，处理可能因换行被截断的 JSON 字符串
with open(input_file, 'r', encoding='utf-8') as f:
    for line in f:
        current_json += line.strip()
        try:
            # 尝试解析 JSON
            obj = json.loads(current_json)
            json_objects.append(obj)
            current_json = "" # 解析成功则清空缓冲区
        except json.JSONDecodeError:
            pass # 解析失败说明 JSON 可能在多行，继续拼接

# 写入新文件
with open(output_file, 'w', encoding='utf-8') as out_f:
    for data in json_objects:
        orig_id = data.get('id')
        query = data.get('problem')
        response = data.get('answer')
        
        # 每道题循环复制32遍
        for i in range(32):
            # 按照要求的顺序和名称构建新的字典
            new_item = {
                "id": f"{orig_id}_sample_{i}",
                "query": query,
                "response": response
            }
            # json.dumps 会按照字典在 Python 3.7+ 中的插入顺序进行序列化
            out_f.write(json.dumps(new_item, ensure_ascii=False) + '\n')

print(f"处理完成！原文件包含 {len(json_objects)} 题，新文件共生成 {len(json_objects) * 32} 条数据。")