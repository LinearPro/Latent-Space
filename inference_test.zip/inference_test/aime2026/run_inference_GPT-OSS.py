import json
import os
import asyncio
from openai import AsyncOpenAI
from tqdm.asyncio import tqdm
import re

# ================= 配置区域 =================
# 更新为 gpt-oss 的本地路径
MODEL_NAME = "/WORK/PUBLIC/dongyinp_work/lingp/models/gpt-oss" 
INPUT_FILE = "aime2026_formatted.jsonl"
# 更新输出文件名称，以区分不同模型
OUTPUT_FILE = "outputs/aime2026_gpt_oss.jsonl" 
PORT = 8044 # 设定您要使用的端口

# 【修改点】基于 test.py，强烈建议调大，修正为 81920
MAX_TOKENS = 81920  
TEMPERATURE = 0.6
TOP_P = 0.95

# 设定思考深度 (low, medium, high)
REASONING_LEVEL = "high"

# 并发数量控制
CONCURRENCY_LIMIT = 15 

# ⚠️⚠️⚠️【关键提示：服务端启动要求】⚠️⚠️⚠️
# 基于 test.py 中必须允许执行自定义代码的要求，
# 请务必确保您在启动本地 vLLM OpenAI Server 时，加上了 --trust-remote-code 参数。
# 例如：python -m vllm.entrypoints.openai.api_server --model /WORK/PUBLIC/dongyinp_work/lingp/models/gpt-oss --port 8011 --trust-remote-code
# ===========================================

# 提取 harmony 格式输出的辅助函数
def parse_harmony_response(raw_text):
    """
    解析 gpt-oss 返回的 harmony 格式字符串，分离思考过程和最终回答。
    """
    if not raw_text:
        return "", ""
        
    thought_process = ""
    final_answer = raw_text
    
    # gpt-oss 通常使用 assistantfinal 标记最终回复，analysis 标记思考过程
    if "assistantfinal" in raw_text:
        parts = raw_text.split("assistantfinal")
        final_answer = parts[-1].strip()
        thought_process = parts[0].replace("analysis", "", 1).strip()
        
    return thought_process, final_answer

# 异步处理单个任务的函数
async def process_task(item, client, semaphore, f_out, pbar):
    # 使用信号量限制最大并发数
    async with semaphore:
        query = item['query']
        max_attempts = 2  # 设定最大尝试次数：1次正常请求 + 1次异常重试
        
        for attempt in range(max_attempts):
            try:
                # 发起非流式异步请求 (stream=False)
                response = await client.chat.completions.create(
                    model=MODEL_NAME,
                    messages=[
                        # 加入 system prompt 控制 reasoning level，与 test.py 保持一致
                        {"role": "system", "content": f"Reasoning: {REASONING_LEVEL}"},
                        {"role": "user", "content": query}
                    ],
                    max_tokens=MAX_TOKENS,
                    # temperature=0.6 配合 vLLM 默认会开启 do_sample=True，使设置生效
                    temperature=TEMPERATURE,
                    top_p=TOP_P,
                    stream=False # 关闭流式输出以提高吞吐量和保持控制台整洁
                )
                
                # gpt-oss 返回的是包含 analysis 和 assistantfinal 的原始字符串
                raw_generated_text = response.choices[0].message.content
                finish_reason = response.choices[0].finish_reason
                
                if hasattr(response, 'usage') and response.usage:
                    completion_tokens = response.usage.completion_tokens
                else:
                    completion_tokens = len(raw_generated_text) // 4
                
                # 【核心修改点】：放弃使用 completion_tokens 判断，直接判断真实文本字符数
                visible_char_count = len(raw_generated_text.strip())
                
                # 检查是否短路输出 (字符数不足 400，约等于 100 tokens)，且还有重试机会
                if visible_char_count < 400 and attempt < max_attempts - 1:
                    print(f"\n⚠️ ID {item['id']} 检测到异常短输出 (仅 {visible_char_count} 字符，Token统计可能虚高为 {completion_tokens})，正在拦截并重新请求模型...")
                    continue  # 跳过后续保存步骤，直接进入下一次循环重试
                
                # 解析出思维链和最终答案
                thought, final_pred = parse_harmony_response(raw_generated_text)
                
                # 保存结果，增加 thought 字段，顺便记录生成的 token 数量方便后续分析
                result = {
                    "id": item['id'],
                    "query": query,
                    "response": item.get('response', ''),
                    "raw_pred": raw_generated_text, # 保留原始输出以备查
                    "thought": thought,             # 模型内部的思考过程
                    "pred": final_pred,             # 模型最终给用户的答案
                    "finish_reason": finish_reason if finish_reason else "stop",
                    "completion_tokens": completion_tokens # 记录生成的 token 数
                }
                
                # 写入文件并刷新进度条
                f_out.write(json.dumps(result, ensure_ascii=False) + "\n")
                f_out.flush() 
                
                pbar.update(1) # 更新进度条
                break  # 成功处理并写入，跳出循环结束该任务
                
            except Exception as e:
                # 捕获网络、超时等异常，如果有机会则重试
                if attempt < max_attempts - 1:
                    print(f"\n⚠️ ID {item['id']} API请求异常: {e}，准备重新请求...")
                else:
                    print(f"\n❌ ID {item['id']} 最终请求失败: {e}")
                    pbar.update(1)

async def async_main():
    print(f"🔧 配置: 单节点全量处理 -> Port {PORT}")
    print(f"🧠 模型: {MODEL_NAME} | 推理等级: {REASONING_LEVEL}")
    
    API_URL = f"http://localhost:{PORT}/v1"
    API_KEY = "EMPTY"

    # 1. 初始化异步客户端
    client = AsyncOpenAI(base_url=API_URL, api_key=API_KEY, timeout=3600.0)
    print(f"🚀 连接服务: {API_URL}")

    # 2. 读取数据
    if not os.path.exists(INPUT_FILE):
        print(f"❌ 错误: 找不到文件 {INPUT_FILE}")
        return
    
    tasks = []
    with open(INPUT_FILE, 'r', encoding='utf-8') as f:
        for line in f:
            if line.strip():
                tasks.append(json.loads(line))
    
    # 3. 断点续传逻辑
    os.makedirs(os.path.dirname(OUTPUT_FILE), exist_ok=True)
    finished_ids = set()
    if os.path.exists(OUTPUT_FILE):
        with open(OUTPUT_FILE, 'r', encoding='utf-8') as f:
            for line in f:
                try:
                    data = json.loads(line)
                    if 'id' in data: finished_ids.add(data['id'])
                except: pass
    
    tasks_to_run = [t for t in tasks if t['id'] not in finished_ids]
    print(f"⏭️  已完成跳过: {len(finished_ids)} 条, 剩余待处理: {len(tasks_to_run)} 条")

    # 如果没有任务需要跑，直接退出
    if not tasks_to_run:
        print("✅ 所有任务已处理完毕！")
        return

    # 4. 执行异步并发推理
    semaphore = asyncio.Semaphore(CONCURRENCY_LIMIT)
    
    with open(OUTPUT_FILE, 'a', encoding='utf-8') as f_out:
        with tqdm(total=len(tasks_to_run), desc="总体进度") as pbar:
            # 创建所有任务
            coroutines = [process_task(item, client, semaphore, f_out, pbar) for item in tasks_to_run]
            # 并发执行
            await asyncio.gather(*coroutines)

    print(f"\n✅ 全部完成！文件保存在: {OUTPUT_FILE}")

def main():
    asyncio.run(async_main())

if __name__ == "__main__":
    main()