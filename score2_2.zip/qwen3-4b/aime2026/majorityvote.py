import json
from collections import Counter

def calculate_majority_vote(file_path):
    correct_count = 0
    total_count = 0
    
    with open(file_path, 'r', encoding='utf-8') as f:
        lines = [line.strip() for line in f if line.strip()]
        
    # 忽略 id，严格按照每 32 行划分为一道题
    chunk_size = 32
    for i in range(0, len(lines), chunk_size):
        chunk = lines[i : i + chunk_size]
        
        # 如果最后剩下的行数不足，可以选择跳过或继续处理（这里选择继续处理剩余的行）
        if not chunk:
            break
            
        model_answers = []
        standard_answer = None
        
        for line in chunk:
            data = json.loads(line)
            # 提取模型答案（包含为 null 的情况）
            model_answer = data.get("model_answer")
            # 转为字符串格式方便统一统计，如果是 None 则转为 "None"
            model_answers.append(str(model_answer))
            
            # 标准答案取这32行里的第一个即可（同一道题的标准答案一致）
            if standard_answer is None:
                standard_answer = str(data.get("standard_answer"))
                
        # 计算 Majority Vote
        # Counter 会统计每种答案的出现次数，most_common(1) 返回出现次数最多的元素
        vote_counts = Counter(model_answers)
        majority_answer, count = vote_counts.most_common(1)[0]
        
        # 判断 Majority Vote 是否与标准答案一致
        is_correct = (majority_answer == standard_answer)
        
        if is_correct:
            correct_count += 1
        total_count += 1
        
        # 调试用：打印每道题的统计结果
        # print(f"第 {total_count} 题 | Majority Vote = {majority_answer} (票数:{count}) | 标准答案 = {standard_answer} | 正确 = {is_correct}")

    # 计算最终准确率
    accuracy = correct_count / total_count if total_count > 0 else 0
    
    print("\n========= 评估结果 =========")
    print(f"总题目数 (Chunks): {total_count}")
    print(f"Majority Vote 预测正确数: {correct_count}")
    print(f"Majority Vote 准确率: {accuracy:.2%}")
    print("============================")

if __name__ == "__main__":
    # 请确保 evaluation.jsonl 和此脚本在同一目录下
    calculate_majority_vote('evaluation.jsonl')