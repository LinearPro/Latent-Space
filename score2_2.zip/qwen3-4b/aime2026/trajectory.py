import os
import pandas as pd
import json
import matplotlib.pyplot as plt

# 1. 读取 jsonl 数据
data = []
with open('metrics.jsonl', 'r') as f:
    for line in f:
        data.append(json.loads(line))
df = pd.DataFrame(data)

# 确保图片保存文件夹存在
os.makedirs('figure', exist_ok=True)

# 定义列名
x_cols = ['incoh_first_10pct', 'incoh_first_20pct', 'incoh_first_40pct', 'incoh_first_80pct', 'incoh_first_100pct']
y_cols = ['fric_first_10pct', 'fric_first_20pct', 'fric_first_40pct', 'fric_first_80pct', 'fric_first_100pct']

# ==========================================
# 核心优化 1：基线归零 (Baseline Subtraction)
# ==========================================
df_delta = df.copy()
for col in x_cols:
    df_delta[col] = df[col] - df['incoh_first_10pct']
for col in y_cols:
    df_delta[col] = df[col] - df['fric_first_10pct']

# ==========================================
# 核心优化 2：计算平均值和标准误 (SEM)
# ==========================================
mean_stats = df_delta.groupby('is_correct')[x_cols + y_cols].mean()
sem_stats = df_delta.groupby('is_correct')[x_cols + y_cols].sem()

# 3. 开始绘图
plt.figure(figsize=(10, 8))

# 透明度设置 (误差带稍微透明一点，显得高级)
band_alpha = 0.15 

# ==========================================
# 绘制错误(False)轨迹与误差带
# ==========================================
if False in mean_stats.index:
    x_mean_f = mean_stats.loc[False, x_cols].values
    y_mean_f = mean_stats.loc[False, y_cols].values
    x_sem_f = sem_stats.loc[False, x_cols].values
    y_sem_f = sem_stats.loc[False, y_cols].values
    
    # 画主轨迹线
    plt.plot(x_mean_f, y_mean_f, '-o', color='red', label='Incorrect CoT', 
             linewidth=2.5, markersize=6)
    
    # 填充 Y 方向误差带 (上下带)
    plt.fill_between(x_mean_f, y_mean_f - y_sem_f, y_mean_f + y_sem_f, 
                     color='red', alpha=band_alpha, edgecolor='none')
    
    # 填充 X 方向误差带 (左右带)
    plt.fill_betweenx(y_mean_f, x_mean_f - x_sem_f, x_mean_f + x_sem_f, 
                      color='red', alpha=band_alpha, edgecolor='none')

# ==========================================
# 绘制正确(True)轨迹与误差带
# ==========================================
if True in mean_stats.index:
    x_mean_t = mean_stats.loc[True, x_cols].values
    y_mean_t = mean_stats.loc[True, y_cols].values
    x_sem_t = sem_stats.loc[True, x_cols].values
    y_sem_t = sem_stats.loc[True, y_cols].values
    
    # 画主轨迹线
    plt.plot(x_mean_t, y_mean_t, '-o', color='blue', label='Correct CoT', 
             linewidth=2.5, markersize=6)
    
    # 填充 Y 方向误差带 (上下带)
    plt.fill_between(x_mean_t, y_mean_t - y_sem_t, y_mean_t + y_sem_t, 
                     color='blue', alpha=band_alpha, edgecolor='none')
    
    # 填充 X 方向误差带 (左右带)
    plt.fill_betweenx(y_mean_t, x_mean_t - x_sem_t, x_mean_t + x_sem_t, 
                      color='blue', alpha=band_alpha, edgecolor='none')

# ==========================================
# 细节美化
# ==========================================
# 添加文本标签
labels = ['10% (Start)', '20%', '40%', '80%', '100%']
for val, color, offset_y in [(True, 'blue', 15), (False, 'red', -20)]:
    if val in mean_stats.index:
        for i in range(5):
            # 防止起点两个文本重叠
            if i == 0 and val == False: 
                continue 
            plt.annotate(labels[i],
                         (mean_stats.loc[val, x_cols[i]], mean_stats.loc[val, y_cols[i]]),
                         textcoords="offset points", 
                         xytext=(0, offset_y), 
                         ha='center', 
                         color=color, 
                         fontweight='bold')

plt.xlabel('Change in Incoherence from 10% ($\Delta$ incoh)', fontsize=12)
plt.ylabel('Change in Friction from 10% ($\Delta$ fric)', fontsize=12)
plt.title('Relative Average Trajectory with Continuous SEM Ribbon', fontsize=14)

# 强调 (0,0) 原点十字线
plt.axhline(0, color='black', linewidth=1, linestyle='--', alpha=0.5)
plt.axvline(0, color='black', linewidth=1, linestyle='--', alpha=0.5)

plt.grid(True, linestyle=':', alpha=0.7)
plt.legend(loc='upper left', frameon=True, shadow=True)

# 保存图片
plt.savefig('figure/trajectory_delta_with_sem_ribbon.png', dpi=300)
plt.close()

print("连续误差带轨迹图已保存至 figure/trajectory_delta_with_sem_ribbon.png")