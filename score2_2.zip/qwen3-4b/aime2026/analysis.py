import os
# 优化显存分配策略，减少碎片
os.environ["PYTORCH_CUDA_ALLOC_CONF"] = "expandable_segments:True"

import json
import torch
import numpy as np
import argparse
import traceback
import gc
from tqdm import tqdm
from transformers import AutoModelForCausalLM, AutoTokenizer
import torch.nn.functional as F
import torch.multiprocessing as mp

# ==================== 辅助结构 ====================

def get_empty_metrics():
    """生成空的结果字典结构，确保报错或异常时数据字段对齐"""
    keys = []
    # 1. 前 10%, 20%, 40%, 80%, 100%
    for p in [10, 20, 40, 80, 100]:
        keys.extend([f"fric_first_{p}pct", f"incoh_first_{p}pct"])
    # 2. 后 5%, 10%, 20%
    for p in [5, 10, 20]:
        keys.extend([f"fric_last_{p}pct", f"incoh_last_{p}pct"])
    # 3. 前 2000, 4000, 6000, 8000 tokens
    for n in [2000, 4000, 6000, 8000]:
        keys.extend([f"fric_first_{n}", f"incoh_first_{n}"])
    return {k: None for k in keys}

# ==================== 核心计算逻辑 ====================

def calculate_scalar_metrics(hidden_states):
    """
    计算指标的函数。
    它会自动根据传入 tensor 的 device 决定是在 CPU 还是 GPU 上计算。
    """
    num_layers = len(hidden_states) - 1
    if num_layers < 1: 
        return None

    # 获取维度信息
    first_layer = hidden_states[1][0] # [Seq, Hidden]
    seq_len = first_layer.shape[0]
    device = first_layer.device
    
    if seq_len < 2: 
        return None

    # 初始化累加器 (float32 以保证精度)
    micro_sum_diffs = torch.zeros(seq_len - 1, dtype=torch.float32, device=device)
    micro_sum_angles = torch.zeros(seq_len - 1, dtype=torch.float32, device=device)
    macro_sum_states = torch.zeros((seq_len, first_layer.shape[-1]), dtype=torch.float32, device=device)

    # 逐层计算
    for i in range(1, len(hidden_states)):
        # 确保转为 float32 进行计算
        curr = hidden_states[i][0].float()
        macro_sum_states += curr
        
        diffs = curr[1:] - curr[:-1]
        micro_sum_diffs += torch.norm(diffs, p=2, dim=-1)
        
        h_curr, h_prev = curr[1:], curr[:-1]
        cos = F.cosine_similarity(h_curr, h_prev, dim=-1, eps=1e-8).clamp(-1, 1)
        micro_sum_angles += torch.acos(cos) * (180.0 / np.pi)
        
        # 显式删除中间变量，节省内存
        del curr, diffs, cos

    # 1. Macro Indicators
    macro_states = macro_sum_states / num_layers
    macro_diffs = macro_states[1:] - macro_states[:-1]
    n1 = torch.norm(macro_diffs, p=2, dim=-1)
    
    h_curr_m, h_prev_m = macro_states[1:], macro_states[:-1]
    cos_m = F.cosine_similarity(h_curr_m, h_prev_m, dim=-1, eps=1e-8).clamp(-1, 1)
    a1 = torch.acos(cos_m) * (180.0 / np.pi)

    # 2. Micro Indicators
    n2 = micro_sum_diffs / num_layers
    a2 = micro_sum_angles / num_layers
    
    # 3. Scalars (序列长度的差异)
    fric_seq = n2 - n1
    incoh_seq = a2 - a1
    
    L = len(fric_seq) # L = seq_len - 1
    
    def get_mean(seq, start, end):
        # 限制越界
        start = max(0, min(start, L))
        end = max(0, min(end, L))
        if start >= end: return None
        val = seq[start:end].mean()
        if torch.isnan(val): return None
        return val.item()

    metrics = {}
    
    # ---------------- 需求 1: 前 10%, 20%, 40%, 80%, 100% ----------------
    for p in [10, 20, 40, 80, 100]:
        end_idx = max(1, int(L * (p / 100.0)))
        metrics[f"fric_first_{p}pct"] = get_mean(fric_seq, 0, end_idx)
        metrics[f"incoh_first_{p}pct"] = get_mean(incoh_seq, 0, end_idx)
        
    # ---------------- 需求 2: 后 5%, 10%, 20% ----------------
    for p in [5, 10, 20]:
        start_idx = L - max(1, int(L * (p / 100.0)))
        metrics[f"fric_last_{p}pct"] = get_mean(fric_seq, start_idx, L)
        metrics[f"incoh_last_{p}pct"] = get_mean(incoh_seq, start_idx, L)
        
    # ---------------- 需求 3: 前 2000, 4000, 6000, 8000 tokens ----------------
    for n in [2000, 4000, 6000, 8000]:
        end_idx = n - 1
        metrics[f"fric_first_{n}"] = get_mean(fric_seq, 0, end_idx)
        metrics[f"incoh_first_{n}"] = get_mean(incoh_seq, 0, end_idx)
    
    del micro_sum_diffs, micro_sum_angles, macro_sum_states, macro_states, fric_seq, incoh_seq
    return metrics

def worker_process(rank, gpu_ids, lines_chunk, model_path, return_dict):
    gpu_id = gpu_ids[rank]
    device_str = f"cuda:{gpu_id}"
    device = torch.device(device_str)
    print(f"[Worker {rank}] GPU {gpu_id} 开始处理 {len(lines_chunk)} 条数据")

    empty_metrics = get_empty_metrics()

    try:
        tokenizer = AutoTokenizer.from_pretrained(model_path, trust_remote_code=True)
        # 默认加载到 GPU
        model = AutoModelForCausalLM.from_pretrained(
            model_path, device_map={"": gpu_id}, dtype=torch.bfloat16, 
            trust_remote_code=True, attn_implementation="sdpa"
        )
        model.eval()
    except Exception as e:
        print(f"[Worker {rank}] 模型加载失败: {e}")
        return_dict[rank] = [{
            "is_correct": None, "error": f"Model load error: {str(e)}", **empty_metrics
        } for _ in lines_chunk]
        return

    local_results = []
    
    for idx, line in tqdm(enumerate(lines_chunk), desc=f"GPU {gpu_id}", position=rank, total=len(lines_chunk)):
        # 初始化状态
        metrics_dict, error_msg = None, None
        
        try:
            item = json.loads(line)
        except json.JSONDecodeError:
            local_results.append({"is_correct": None, "error": "JSON error", **empty_metrics})
            continue
            
        pred_text = item.get("response", "") or item.get("pred", "")
        if not pred_text:
            local_results.append({"is_correct": item.get("is_correct"), "error": "Empty text", **empty_metrics})
            continue

        # ==============================================================================
        # 三级级联策略 (Cascade Strategy)
        # ==============================================================================
        
        # ---------------- Level 1: Pure GPU (全GPU计算，最快) ----------------
        try:
            # 1. 输入上 GPU
            inputs = tokenizer(pred_text, return_tensors="pt", add_special_tokens=False).to(device)
            
            with torch.no_grad():
                # 2. 推理 (GPU)
                outputs = model(**inputs, output_hidden_states=True)
                # 3. 计算 (GPU) - 这里不进行 detach/cpu 移动，直接算
                metrics_dict = calculate_scalar_metrics(outputs.hidden_states)
            
            # 清理
            del inputs, outputs
            torch.cuda.empty_cache()

        except RuntimeError as e1:
            # 捕获 Level 1 的 OOM
            if "out of memory" in str(e1):
                # ---------------- Level 2: Data Offloading (GPU推理 -> CPU计算) ----------------
                # 策略：如果GPU算指标爆了，就把结果搬到CPU算
                tqdm.write(f"\n[Worker {rank}] Level 1 OOM (Pure GPU) at item {idx}. Trying Level 2 (Data Offload)...")
                
                # 紧急清理 Level 1 的残留
                if 'inputs' in locals(): del inputs
                if 'outputs' in locals(): del outputs
                gc.collect()
                torch.cuda.empty_cache()
                
                try:
                    inputs = tokenizer(pred_text, return_tensors="pt", add_special_tokens=False).to(device)
                    with torch.no_grad():
                        outputs = model(**inputs, output_hidden_states=True)
                        # 关键：立即 Detach 并移动到 CPU
                        hidden_states_cpu = tuple(h.detach().to("cpu") for h in outputs.hidden_states)
                    
                    # 立即释放 GPU 显存，腾出空间
                    del inputs, outputs
                    torch.cuda.empty_cache()
                    
                    # 在 CPU 上计算指标
                    metrics_dict = calculate_scalar_metrics(hidden_states_cpu)
                    del hidden_states_cpu
                    gc.collect()
                    
                except RuntimeError as e2:
                    # 捕获 Level 2 的 OOM (说明连Forward都做不了)
                    if "out of memory" in str(e2):
                        # ---------------- Level 3: Model Offloading (全CPU计算) ----------------
                        # 策略：模型搬到CPU -> CPU推理 -> CPU计算 -> 模型搬回GPU
                        tqdm.write(f"\n[Worker {rank}] Level 2 OOM (Data Offload) at item {idx}. Trying Level 3 (Model Offload)...")
                        
                        # 紧急清理 Level 2 的残留
                        if 'inputs' in locals(): del inputs
                        if 'outputs' in locals(): del outputs
                        if 'hidden_states_cpu' in locals(): del hidden_states_cpu
                        gc.collect()
                        torch.cuda.empty_cache()
                        
                        try:
                            # 1. 模型搬家 (GPU -> CPU)
                            model.to("cpu")
                            
                            # 2. 准备 CPU 输入
                            inputs_cpu = tokenizer(pred_text, return_tensors="pt", add_special_tokens=False).to("cpu")
                            
                            # 3. CPU 推理 + 计算
                            with torch.no_grad():
                                outputs_cpu = model(**inputs_cpu, output_hidden_states=True)
                                metrics_dict = calculate_scalar_metrics(outputs_cpu.hidden_states)
                            
                            del inputs_cpu, outputs_cpu
                            gc.collect()
                            
                            # 4. 模型回家 (CPU -> GPU)
                            model.to(device)
                            tqdm.write(f"[Worker {rank}] Item {idx} finished on CPU. Model restored to GPU.")
                            
                        except Exception as e3:
                            # Level 3 也失败 (CPU 内存不足等)
                            error_msg = f"Level 3 Failed: {str(e3)}"
                            tqdm.write(f"\n[Worker {rank}] FATAL: {error_msg}")
                            # 尝试恢复模型位置
                            try: model.to(device)
                            except: pass
                    else:
                        error_msg = f"Level 2 Runtime Error: {str(e2)}"
            else:
                error_msg = f"Level 1 Runtime Error: {str(e1)}"
                
        except Exception as e_unknown:
            error_msg = f"Unknown Error: {str(e_unknown)}"

        # ---------------- 保存结果 ----------------
        res = {"is_correct": item.get("is_correct")}
        if metrics_dict is not None:
            res["error"] = None
            res.update(metrics_dict)
        else:
            res["error"] = error_msg or "Processing Failed or Sequence too short"
            res.update(empty_metrics)
        local_results.append(res)
            
        # 每一轮结束后的常规清理
        torch.cuda.empty_cache()

    return_dict[rank] = local_results
    del model, tokenizer
    gc.collect()
    torch.cuda.empty_cache()

# ==================== 主程序 ====================

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input_file", type=str, required=True)
    parser.add_argument("--output_file", type=str, required=True)
    parser.add_argument("--model_path", type=str, default="/WORK/PUBLIC/dongyinp_work/lingp/models/Qwen3-4B-Thinking-2507")
    parser.add_argument("--num_gpus", type=int, default=4)
    args = parser.parse_args()

    print(f"Reading input file: {args.input_file}")
    with open(args.input_file, 'r') as f:
        lines = [l.strip() for l in f if l.strip()]
    
    total_input_lines = len(lines)
    print(f"Total lines to process: {total_input_lines}")

    num_gpus = min(args.num_gpus, torch.cuda.device_count())
    chunk_size = (len(lines) + num_gpus - 1) // num_gpus
    chunks = [lines[i:i + chunk_size] for i in range(0, len(lines), chunk_size)]
    
    mp.set_start_method('spawn', force=True)
    manager = mp.Manager()
    return_dict = manager.dict()
    processes = []
    
    for rank in range(num_gpus):
        if rank < len(chunks):
            chunk_data = chunks[rank]
        else:
            chunk_data = []
        p = mp.Process(target=worker_process, args=(rank, list(range(num_gpus)), chunk_data, args.model_path, return_dict))
        p.start()
        processes.append(p)
    
    for p in processes: p.join()

    print(f"Saving to {args.output_file}...")
    total_output_lines = 0
    with open(args.output_file, 'w') as f:
        for rank in range(num_gpus):
            if rank in return_dict:
                results = return_dict[rank]
                total_output_lines += len(results)
                for item in results:
                    f.write(json.dumps(item) + "\n")
    
    print(f"Done. Processed {total_output_lines}/{total_input_lines} lines.")

if __name__ == "__main__":
    main()