import json
import re
import os

def parse_id(id_str):
    """
    解析 id，例如将 "1_sample_0" 解析为数字元组 (1, 0)
    以便后续进行严格的数值排序，防止 "10_sample_0" 排在 "2_sample_0" 前面
    """
    match = re.match(r'^(\d+)_sample_(\d+)$', str(id_str))
    if match:
        return int(match.group(1)), int(match.group(2))
    # 如果有不符合规则的 id，放到最后面
    return float('inf'), float('inf')

def sort_jsonl_by_id():
    # ==========================================
    # 在这里直接修改内部参数
    # ==========================================
    num_questions = 30
    answers_per_question = 32
    input_file = 'aime2026_qwen3_4b_thinking.jsonl'
    output_file = 'pred_32.jsonl'
    # ==========================================

    if not os.path.exists(input_file):
        print(f"⚠️ 错误：找不到文件 {input_file}")
        return

    data = []
    # 1. 读取所有有效数据
    with open(input_file, 'r', encoding='utf-8') as f:
        for line in f:
            if line.strip():
                data.append(json.loads(line))
                
    # 2. 校验数据行数是否与参数预期一致
    expected_lines = num_questions * answers_per_question
    if len(data) != expected_lines:
        print(f"⚠️ 警告: 预期 {expected_lines} 行数据 ({num_questions} 题 x {answers_per_question} 回答)，"
              f"但实际读取到 {len(data)} 行。程序将继续对实际读取的数据进行排序。")

    # 3. 基于解析出的数字元组 (题号, sample号) 进行严格排序
    data.sort(key=lambda x: parse_id(x.get('id', '')))

    # 4. 写入排序后的数据
    with open(output_file, 'w', encoding='utf-8') as fout:
        for item in data:
            fout.write(json.dumps(item, ensure_ascii=False) + '\n')
            
    print(f"✅ 处理完成！成功对 {len(data)} 行数据进行了按 ID 的严格重新排序。")
    print(f"排序后的文件已保存为: {output_file}")


if __name__ == '__main__':
    sort_jsonl_by_id()