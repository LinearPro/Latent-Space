import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import os

# 1. 读取数据
df = pd.read_json('metrics.jsonl', lines=True)

# 2. 超参数设置
T_values = np.arange(0, 4.1, 0.1)
num_questions = len(df) // 32
num_samples = 20        # 每次随机采样的行数
num_iterations = 10     # 随机采样的次数
top_k = 10              # 排序后截取的前N名

# 为了确保每次运行生成的随机结果可复现，这里设置随机种子
np.random.seed(42)

# 3. 创建输出目录以保存图片
output_dir = 'question_plots_sampled'
os.makedirs(output_dir, exist_ok=True)

# 4. 遍历所有问题
for q_idx in range(num_questions):
    # 提取当前问题的 32 行数据
    q_df = df.iloc[q_idx*32 : (q_idx+1)*32].copy()
    
    # 初始化一个二维数组来保存10次采样、每个T下的正确率
    # shape: (10, 41) 
    all_acc = np.zeros((num_iterations, len(T_values)))
    
    for i in range(num_iterations):
        # 从32个回答中随机不放回地抽取20个
        sampled_df = q_df.sample(n=num_samples, replace=False)
        
        for t_idx, T in enumerate(T_values):
            # 使用新公式：fric_first_40pct - T * incoh_last_10pct
            scores = sampled_df['fric_first_40pct'] - T * sampled_df['incoh_last_10pct']
            
            # 对采样出的20个结果赋值分数，使用nlargest取分数最高的10名
            top_10 = sampled_df.assign(score=scores).nlargest(top_k, 'score')
            
            # 计算这10个中的正确率
            acc = top_10['is_correct'].sum() / float(top_k)
            all_acc[i, t_idx] = acc
            
    # 计算10次采样的平均值 (沿列求均值)
    avg_acc = np.mean(all_acc, axis=0)
    
    # 5. 生成对应的图片
    plt.figure(figsize=(8, 5))
    # 绘制 T 值与平均正确率的折线
    plt.plot(T_values, avg_acc, color='#2ca02c', marker='o', markersize=4, linewidth=2)
    
    plt.title(f'Question {q_idx + 1} - Average Accuracy vs T')
    plt.xlabel('T (Temperature hyperparameter)')
    plt.ylabel('Average Accuracy (10 Iterations)')
    plt.xticks(np.arange(0, 4.5, 0.5))
    plt.ylim(-0.05, 1.05)
    plt.grid(True, linestyle='--', alpha=0.7)
    
    # 保存该问题的折线图
    save_path = os.path.join(output_dir, f'question_{q_idx + 1}_avg_accuracy.png')
    plt.savefig(save_path, dpi=300, bbox_inches='tight')
    plt.close()

print(f"执行完毕！已为 {num_questions} 道题目独立完成了采样评估，并分别将图片保存在 '{output_dir}' 目录下。")