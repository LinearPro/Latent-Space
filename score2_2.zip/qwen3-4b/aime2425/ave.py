import os
import pandas as pd
import json
import matplotlib.pyplot as plt
import numpy as np

# 1. 读取 jsonl 数据
data = []
with open('metrics.jsonl', 'r') as f:
    for line in f:
        data.append(json.loads(line))
df = pd.DataFrame(data)

# 确保图片保存文件夹存在
os.makedirs('figure', exist_ok=True)

# 定义列名
x_cols = ['incoh_first_10pct', 'incoh_first_20pct', 'incoh_first_40pct', 'incoh_first_80pct', 'incoh_first_100pct']
y_cols = ['fric_first_10pct', 'fric_first_20pct', 'fric_first_40pct', 'fric_first_80pct', 'fric_first_100pct']
stages = ['10%', '20%', '40%', '80%', '100%']
x_indices = np.arange(len(stages)) # 用 0, 1, 2, 3, 4 作为 X 轴，表示生成阶段

# 2. 按正确与错误分组，计算每个阶段的均值和标准差
stats = {}
for is_correct in [True, False]:
    group = df[df['is_correct'] == is_correct]
    if not group.empty:
        stats[is_correct] = {
            'incoh_mean': group[x_cols].mean().values,
            'incoh_std': group[x_cols].std().values,
            'fric_mean': group[y_cols].mean().values,
            'fric_std': group[y_cols].std().values
        }

# 3. 开始绘图 (1行2列的子图)
fig, axes = plt.subplots(1, 2, figsize=(16, 6))
colors = {True: ('blue', 'lightblue'), False: ('red', 'lightcoral')}
labels = {True: 'Correct CoT', False: 'Incorrect CoT'}

# --- 图 1：Incoherence (不连贯性) 随阶段的演变 ---
for is_correct, color_pair in colors.items():
    if is_correct in stats:
        mean_vals = stats[is_correct]['incoh_mean']
        std_vals = stats[is_correct]['incoh_std']
        
        # 画阴影区（置信区间/标准差范围）
        axes[0].fill_between(x_indices, mean_vals - std_vals, mean_vals + std_vals, 
                             color=color_pair[1], alpha=0.3)
        # 画平均轨迹线
        axes[0].plot(x_indices, mean_vals, marker='o', color=color_pair[0], 
                     linewidth=2, label=labels[is_correct])

axes[0].set_xticks(x_indices)
axes[0].set_xticklabels(stages)
axes[0].set_title('Evolution of Incoherence over Generation Stages', fontsize=13)
axes[0].set_xlabel('Generation Stage', fontsize=11)
axes[0].set_ylabel('Incoherence (Mean ± Std)', fontsize=11)
axes[0].grid(True, linestyle='--', alpha=0.6)
axes[0].legend()

# --- 图 2：Friction (摩擦力) 随阶段的演变 ---
for is_correct, color_pair in colors.items():
    if is_correct in stats:
        mean_vals = stats[is_correct]['fric_mean']
        std_vals = stats[is_correct]['fric_std']
        
        # 画阴影区（置信区间/标准差范围）
        axes[1].fill_between(x_indices, mean_vals - std_vals, mean_vals + std_vals, 
                             color=color_pair[1], alpha=0.3)
        # 画平均轨迹线
        axes[1].plot(x_indices, mean_vals, marker='o', color=color_pair[0], 
                     linewidth=2, label=labels[is_correct])

axes[1].set_xticks(x_indices)
axes[1].set_xticklabels(stages)
axes[1].set_title('Evolution of Friction over Generation Stages', fontsize=13)
axes[1].set_xlabel('Generation Stage', fontsize=11)
axes[1].set_ylabel('Friction (Mean ± Std)', fontsize=11)
axes[1].grid(True, linestyle='--', alpha=0.6)
axes[1].legend()

# 4. 调整布局并保存
plt.tight_layout()
plt.savefig('figure/trajectory_evolution_with_variance.png', dpi=300)
plt.close()

print("带置信区间的演变轨迹图已保存至 figure/trajectory_evolution_with_variance.png")