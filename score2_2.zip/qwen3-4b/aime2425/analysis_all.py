import json
from collections import Counter
import numpy as np

def main():
    # 1. 读取数据文件
    with open('metrics.jsonl', 'r', encoding='utf-8') as f:
        metrics = [json.loads(line) for line in f]
        
    with open('evaluation.jsonl', 'r', encoding='utf-8') as f:
        evals = [json.loads(line) for line in f]

    # 2. 按每 32 行一题进行分组
    chunk_size = 32
    # 确保 metrics 和 evals 长度一致，向下取整计算总题数
    num_questions = min(len(metrics), len(evals)) // chunk_size

    pass1_scores = []
    pass32_scores = []
    majority_scores = []
    selected_scores = []

    for i in range(num_questions):
        # 提取当前题目的 32 条数据
        start_idx = i * chunk_size
        end_idx = start_idx + chunk_size
        
        q_evals = evals[start_idx:end_idx]
        q_metrics = metrics[start_idx:end_idx]
        
        # 获取当前题目所有32条CoT的正确性列表
        is_correct_list = [e['is_correct'] for e in q_evals]
        
        # ==========================
        # 计算 Pass@1 与 Pass@32
        # ==========================
        # Pass@1 相当于随机抽1条时的期望正确率，即当前题目所有样本 correct 的平均比例
        pass1_scores.append(np.mean(is_correct_list))
        # Pass@32 为只要32条中出现任意1个 correct 即算对
        pass32_scores.append(1 if any(is_correct_list) else 0)
        
        # ==========================
        # 计算 Majority Vote (多数投票)
        # ==========================
        # 提取模型答案（去除空白符避免格式干扰），选出出现次数最多的答案
        model_answers = [str(e.get('model_answer', '')).strip() for e in q_evals]
        counter = Counter(model_answers)
        best_answer = counter.most_common(1)[0][0]
        
        # 寻找该最高票答案的正确性
        is_majority_correct = False
        for e in q_evals:
            if str(e.get('model_answer', '')).strip() == best_answer:
                is_majority_correct = e['is_correct']
                break
        majority_scores.append(1 if is_majority_correct else 0)
        
        # ==========================
        # 根据特定摩擦力指标选择 CoT
        # ==========================
        scores = []
        for m in q_metrics:
            # 安全地读取指标，防止某些行可能出现的 null
            fric_100 = m.get('fric_first_100pct')
            fric_last_10 = m.get('fric_last_10pct')
            fric_100 = fric_100 if fric_100 is not None else 0
            fric_last_10 = fric_last_10 if fric_last_10 is not None else 0
            
            # 记录当前 CoT 的得分：fric_first_100pct - fric_last_10pct
            scores.append(fric_100 - fric_last_10)
            
        # 选出得分最大的那个 CoT
        best_idx = int(np.argmax(scores))
        selected_scores.append(1 if q_evals[best_idx]['is_correct'] else 0)

    # 3. 统计平均值并打印在终端
    print(f"总测试题数:      {num_questions}")
    print(f"Pass@1:         {np.mean(pass1_scores)*100:.2f}%")
    print(f"Pass@32:        {np.mean(pass32_scores)*100:.2f}%")
    print(f"Majority Vote:  {np.mean(majority_scores)*100:.2f}%")
    print(f"Selected CoT:   {np.mean(selected_scores)*100:.2f}%")

if __name__ == '__main__':
    main()