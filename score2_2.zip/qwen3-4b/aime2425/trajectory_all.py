import os
import pandas as pd
import json
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.lines import Line2D

# 1. 读取 jsonl 数据
data = []
with open('metrics.jsonl', 'r') as f:
    for line in f:
        data.append(json.loads(line))
df = pd.DataFrame(data)

# 确保图片保存文件夹存在
os.makedirs('figure', exist_ok=True)

# 定义需要提取的 x 轴和 y 轴列名
x_cols = ['incoh_first_10pct', 'incoh_first_20pct', 'incoh_first_40pct', 'incoh_first_80pct', 'incoh_first_100pct']
y_cols = ['fric_first_10pct', 'fric_first_20pct', 'fric_first_40pct', 'fric_first_80pct', 'fric_first_100pct']

# 2. 按题（每32行）进行归一化处理
# 创建一个标识题目的列 (0, 0, ..., 0, 1, 1, ..., 1, ...)
df['problem_id'] = df.index // 32

# 遍历每一道题，对题内数据进行归一化
for pid, group in df.groupby('problem_id'):
    
    # 遍历所有的 X 列和 Y 列，对每一列单独进行独立归一化
    for col in x_cols + y_cols:
        col_min = group[col].min()
        col_max = group[col].max()
        
        # 防止分母为0的情况（如果当前列的 32 个值全都一样）
        if col_max > col_min:
            df.loc[group.index, col] = (group[col] - col_min) / (col_max - col_min)
        else:
            df.loc[group.index, col] = 0.5 # 如果全都一样，默认放中间

# 3. 开始绘图
plt.figure(figsize=(12, 10))

# 定义颜色系和阶段颜色（从 colormap 选取特定范围，表示 10% -> 100%）
correct_colors = [plt.cm.Blues(i) for i in [0.4, 0.6, 0.8, 0.95]]
incorrect_colors = [plt.cm.Reds(i) for i in [0.4, 0.6, 0.8, 0.95]]

# 定义绘图参数
alpha = 0.15 # 保持较低透明度以展示密度
linewidth = 1.0

# 遍历并绘制每一条轨迹
for index, row in df.iterrows():
    is_correct = row['is_correct']
    
    # 获取归一化后的 5 个点坐标
    x_vals = row[x_cols].values
    y_vals = row[y_cols].values
    
    # 根据正误选择颜色
    segment_colors = correct_colors if is_correct else incorrect_colors
    
    # 逐段绘制，体现颜色由浅到深
    for i in range(4):
        plt.plot(x_vals[i:i+2], y_vals[i:i+2], 
                 color=segment_colors[i], 
                 alpha=alpha, 
                 linewidth=linewidth)

# 创建代理艺术家用于自定义图例
legend_elements = [
    Line2D([0], [0], color=correct_colors[3], lw=2, label='Correct Trajectories'),
    Line2D([0], [0], color=incorrect_colors[3], lw=2, label='Incorrect Trajectories')
]

# 设置图表格式
plt.xlabel('Normalized Incoherence (incoh)', fontsize=12)
plt.ylabel('Normalized Friction (fric)', fontsize=12)
plt.title('All Trajectories (Column-wise Normalized per Problem): Correct vs Incorrect', fontsize=14)
# 因为已经归一化，坐标轴范围固定在略微超出 [0, 1] 的区间会更好看
plt.xlim(-0.05, 1.05)
plt.ylim(-0.05, 1.05)
plt.grid(True, linestyle='--', alpha=0.5)
plt.legend(handles=legend_elements, loc='best')

# 保存图片
plt.savefig('figure/all_trajectories_normalized_independent.png', dpi=300)
plt.close()

print("按列独立归一化后的轨迹对比图已保存至 figure/all_trajectories_normalized_independent.png")