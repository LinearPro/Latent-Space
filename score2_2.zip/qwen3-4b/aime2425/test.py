import os
import pandas as pd
import json
import matplotlib.pyplot as plt
import seaborn as sns

# 1. 读取 jsonl 数据
data = []
with open('metrics.jsonl', 'r') as f:
    for line in f:
        data.append(json.loads(line))
df = pd.DataFrame(data)

# 确保图片保存文件夹存在
os.makedirs('figure', exist_ok=True)

# 2. 计算总体变化量 (100% - 10%)
df['delta_incoh_total'] = df['incoh_first_100pct'] - df['incoh_first_10pct']
df['delta_fric_total'] = df['fric_first_100pct'] - df['fric_first_10pct']

# 3. 计算各个阶段的局部变化量 (斜率/爬升量)
# Incoherence (不连贯性) 变化
df['d_incoh_10_20'] = df['incoh_first_20pct'] - df['incoh_first_10pct']
df['d_incoh_20_40'] = df['incoh_first_40pct'] - df['incoh_first_20pct']
df['d_incoh_40_80'] = df['incoh_first_80pct'] - df['incoh_first_40pct']
df['d_incoh_80_100'] = df['incoh_first_100pct'] - df['incoh_first_80pct']

# Friction (摩擦力) 变化
df['d_fric_10_20'] = df['fric_first_20pct'] - df['fric_first_10pct']
df['d_fric_20_40'] = df['fric_first_40pct'] - df['fric_first_20pct']
df['d_fric_40_80'] = df['fric_first_80pct'] - df['fric_first_40pct']
df['d_fric_80_100'] = df['fric_first_100pct'] - df['fric_first_80pct']

# ==========================================
# 绘图 1: 总体首尾变化量散点图 (Delta Scatter)
# ==========================================
plt.figure(figsize=(10, 8))
sns.scatterplot(
    data=df, 
    x='delta_incoh_total', 
    y='delta_fric_total', 
    hue='is_correct', 
    palette={True: 'blue', False: 'red'}, 
    alpha=0.5, # 设置透明度看清重叠点
    s=30       # 点的大小
)
plt.title('Overall Trajectory Shift: $\Delta$Incoh vs $\Delta$Fric (100% - 10%)', fontsize=14)
plt.xlabel('Total Change in Incoherence ($\Delta$ incoh)', fontsize=12)
plt.ylabel('Total Change in Friction ($\Delta$ fric)', fontsize=12)
# 添加 x=0 和 y=0 的参考基准线，方便看数据是增加还是减少
plt.axhline(0, color='black', linewidth=1, linestyle='--', alpha=0.5)
plt.axvline(0, color='black', linewidth=1, linestyle='--', alpha=0.5)
plt.grid(True, linestyle=':', alpha=0.7)

plt.savefig('figure/delta_scatter_total.png', dpi=300)
plt.close()
print("总体变化量散点图已保存至 figure/delta_scatter_total.png")

# ==========================================
# 绘图 2: 各阶段变化率的箱线图 (Stage Boxplots)
# ==========================================
# 为了用 Seaborn 画多组对比的箱线图，我们需要把宽表转成长表 (Melt)
melted_incoh = pd.melt(
    df, 
    id_vars=['is_correct'], 
    value_vars=['d_incoh_10_20', 'd_incoh_20_40', 'd_incoh_40_80', 'd_incoh_80_100'],
    var_name='Stage', 
    value_name='Delta_Value'
)
# 重命名阶段，让图表坐标轴更易读
stage_map_incoh = {
    'd_incoh_10_20': '10% -> 20%', 'd_incoh_20_40': '20% -> 40%', 
    'd_incoh_40_80': '40% -> 80%', 'd_incoh_80_100': '80% -> 100%'
}
melted_incoh['Stage'] = melted_incoh['Stage'].map(stage_map_incoh)

melted_fric = pd.melt(
    df, 
    id_vars=['is_correct'], 
    value_vars=['d_fric_10_20', 'd_fric_20_40', 'd_fric_40_80', 'd_fric_80_100'],
    var_name='Stage', 
    value_name='Delta_Value'
)
stage_map_fric = {
    'd_fric_10_20': '10% -> 20%', 'd_fric_20_40': '20% -> 40%', 
    'd_fric_40_80': '40% -> 80%', 'd_fric_80_100': '80% -> 100%'
}
melted_fric['Stage'] = melted_fric['Stage'].map(stage_map_fric)

# 创建一个 2行1列 的大图表
fig, axes = plt.subplots(2, 1, figsize=(12, 10))

# 画 Incoherence 阶段变化箱线图
sns.boxplot(
    data=melted_incoh, x='Stage', y='Delta_Value', hue='is_correct', 
    palette={True: 'lightblue', False: 'lightcoral'}, 
    ax=axes[0], 
    showfliers=False # 隐藏极端离群点，能让主体的箱体分布对比更明显
)
axes[0].set_title('Step-by-Step Change Rate: Incoherence ($\Delta$ incoh)', fontsize=13)
axes[0].set_ylabel('Change in Incoherence', fontsize=11)
axes[0].set_xlabel('')
axes[0].grid(True, axis='y', linestyle='--', alpha=0.7)
axes[0].axhline(0, color='gray', linewidth=1)

# 画 Friction 阶段变化箱线图
sns.boxplot(
    data=melted_fric, x='Stage', y='Delta_Value', hue='is_correct', 
    palette={True: 'lightblue', False: 'lightcoral'}, 
    ax=axes[1], 
    showfliers=False
)
axes[1].set_title('Step-by-Step Change Rate: Friction ($\Delta$ fric)', fontsize=13)
axes[1].set_ylabel('Change in Friction', fontsize=11)
axes[1].set_xlabel('Generation Stage', fontsize=12)
axes[1].grid(True, axis='y', linestyle='--', alpha=0.7)
axes[1].axhline(0, color='gray', linewidth=1)

plt.tight_layout()
plt.savefig('figure/delta_boxplots_stages.png', dpi=300)
plt.close()
print("各阶段变化率箱线图已保存至 figure/delta_boxplots_stages.png")