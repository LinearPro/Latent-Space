import pandas as pd
import numpy as np

# 1. 加载数据并过滤掉出错的行
df = pd.read_json('metrics.jsonl', lines=True)
valid_df = df[df['error'].isnull()].copy()

# 2. 假设每道题有 32 个候选 CoT，分配题目 ID
SAMPLES_PER_QUESTION = 32
valid_df['question_id'] = valid_df.index // SAMPLES_PER_QUESTION
valid_df['sample_id'] = valid_df.index % SAMPLES_PER_QUESTION

# ==========================================
# 归一化：按题目进行 0-1 归一化 (Min-Max Scaling)
# ==========================================
# 找出所有的原始指标列（去除非指标的辅助列）
metric_cols = [c for c in valid_df.columns if c not in ['is_correct', 'error', 'question_id', 'sample_id']]

def min_max_normalize(x):
    """将序列归一化到 0-1 之间。如果最大值等于最小值，则全设为0避免除零报错。"""
    span = x.max() - x.min()
    if span == 0:
        return 0.0
    return (x - x.min()) / span

# 使用 groupby 和 transform 对每道题 (question_id) 内的各个指标分别进行归一化
valid_df[metric_cols] = valid_df.groupby('question_id')[metric_cols].transform(min_max_normalize)

# ==========================================
# 新增复合指标：fric_first_100pct - incoh_last_10pct
# ==========================================
# 此时数据已归一化，直接相减即可
if 'fric_first_100pct' in valid_df.columns and 'incoh_last_10pct' in valid_df.columns:
    valid_df['fric_100_minus_incoh_10'] = valid_df['fric_first_100pct'] - 0.5 * valid_df['incoh_last_10pct']
    # 将复合指标也加入 metric_cols 列表中，以便后面一起遍历评估
    if 'fric_100_minus_incoh_10' not in metric_cols:
        metric_cols.append('fric_100_minus_incoh_10')

# ==========================================
# 计算基础 Pass@1 和 Pass@32 准确率
# ==========================================
# Pass@1: 相当于从每题的候选集中随机盲选 1 个的期望准确率
pass_at_1 = valid_df.groupby('question_id')['is_correct'].mean().mean() * 100

# Pass@32: 每道题只要有 >= 1 个候选项是正确的，这道题就算做对
pass_at_32 = valid_df.groupby('question_id')['is_correct'].any().mean() * 100

print("="*50)
print(f"基准测试结果 (每题 {SAMPLES_PER_QUESTION} 个候选):")
print(f"随机选择 (Pass@1) 准确率:  {pass_at_1:.2f}%")
print(f"理论上限 (Pass@32) 准确率: {pass_at_32:.2f}%")
print("="*50 + "\n")

# ==========================================
# 3. 遍历每个指标，执行“最佳 CoT”挑选
# ==========================================
results = []

for col in metric_cols:
    # 规则: 单一 incoh 指标越小越好；新增的复合指标(fric_100_minus_incoh_10)及其他指标要求越大越好
    if 'incoh' in col and col != 'fric_100_minus_incoh_10':
        ascending = True
    else:
        ascending = False
    
    # 找出每道题下，该指标表现最好的那一条 CoT 的所在行索引
    if ascending:
        best_indices = valid_df.groupby('question_id')[col].idxmin()
    else:
        best_indices = valid_df.groupby('question_id')[col].idxmax()
        
    # 根据选出的索引，直接取出那些被选中 CoT 的对错状态 (is_correct)
    selected_correctness = valid_df.loc[best_indices, 'is_correct']
    
    # 计算当前指标选出来的整体准确率
    accuracy = selected_correctness.mean() * 100
    results.append({'Metric': col, 'Accuracy (%)': round(accuracy, 2)})

# 4. 打印并排序各个指标的结果
results_df = pd.DataFrame(results).sort_values(by='Accuracy (%)', ascending=False)
print("各指标作为筛选器选出最佳 CoT 的最终准确率排名：")
print("-" * 50)
print(results_df.to_string(index=False))