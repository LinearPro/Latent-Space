import json
import re

# 定义输入和输出文件名
input_file = 'pred_32.jsonl'
output_file = 'merged_boxed.jsonl'

# 编译正则表达式：匹配一段连续的数字
number_pattern = re.compile(r'\d+')

# 计数器，用于统计处理了多少条数据
processed_count = 0
not_found_count = 0

print(f"开始处理文件: {input_file} ...")

# 以只读模式打开输入文件，以写入模式打开输出文件
with open(input_file, 'r', encoding='utf-8') as infile, \
     open(output_file, 'w', encoding='utf-8') as outfile:
    
    for line in infile:
        # 忽略空行
        if not line.strip():
            continue
            
        # 解析当前行的 JSON 数据
        data = json.loads(line)
        
        # 获取模型生成的完整回答文本
        pred_text = data.get('pred', '')
        
        # 使用正则查找文本中所有的连续数字
        numbers = number_pattern.findall(pred_text)
        
        # 提取最后一个数字
        if numbers:
            extracted_answer = numbers[-1]
        else:
            extracted_answer = None  # 如果没有找到任何数字，设为 None 或 ""
            not_found_count += 1
            
        # 将提取到的答案保存为 "extracted_answer" 字段
        # 这里我们保留了原有的 id, query, response, pred 等字段，方便您后续核对
        data['extracted_answer'] = extracted_answer
        
        # 确保 "id" 字段存在（基于您的要求）
        if 'id' not in data:
            data['id'] = 'unknown_id'
            
        # 将更新后的数据字典转换为 JSON 字符串，并写入输出文件
        # ensure_ascii=False 保证如果文本中有中文或特殊符号能正常保存而不是转码
        outfile.write(json.dumps(data, ensure_ascii=False) + '\n')
        
        processed_count += 1

print("-" * 30)
print(f"处理完成！")
print(f"共处理了 {processed_count} 条数据。")
if not_found_count > 0:
    print(f"警告：有 {not_found_count} 条数据未能提取到数字。")
print(f"结果已成功保存至: {output_file}")