import json
from collections import Counter

file_path = 'evaluation.jsonl'

grouped_data = {}

# 1. 逐行读取文件并解析 json 格式
with open(file_path, 'r', encoding='utf-8') as f:
    for line in f:
        if not line.strip():
            continue
        data = json.loads(line)
        
        # 提取题目的 id 序号（例如从 "1_sample_0" 提取出 "1"）
        q_id = data['id'].split('_')[0]
        
        if q_id not in grouped_data:
            grouped_data[q_id] = {
                'model_answers': [],
                'standard_answer': str(data['standard_answer'])
            }
            
        # 将模型给出的答案存入列表中
        grouped_data[q_id]['model_answers'].append(str(data['model_answer']))

correct_count = 0
total_questions = len(grouped_data)

print(f"Total Questions: {total_questions}")

# 2. 遍历每道题的32次回答，执行 Majority Vote (找众数)
for q_id in sorted(grouped_data.keys(), key=lambda x: int(x)):
    info = grouped_data[q_id]
    answers = info['model_answers']
    standard_answer = info['standard_answer']
    
    # 统计出现次数最多的答案作为最终投票结果
    counts = Counter(answers)
    majority_answer = counts.most_common(1)[0][0]
    
    # 判断多数投票结果是否等于标准答案
    is_correct = (majority_answer == standard_answer)
    if is_correct:
        correct_count += 1
        
    print(f"Q{q_id} | Standard: {standard_answer:<4} | Majority: {majority_answer:<4} | Correct: {is_correct}")

print(f"\nMajority Vote Correct: {correct_count}")
print(f"Accuracy: {correct_count/total_questions:.2%}")