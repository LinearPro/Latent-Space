import json

def merge_jsonl_files():
    file1_path = 'aime2026_formatted.jsonl'
    file2_path = 'merged_boxed.jsonl'
    output_path = 'for_compare.jsonl'

    # 同时打开两个输入文件进行读取，打开输出文件进行写入
    with open(file1_path, 'r', encoding='utf-8') as f1, \
         open(file2_path, 'r', encoding='utf-8') as f2, \
         open(output_path, 'w', encoding='utf-8') as out_f:
        
        # 使用 zip 按行对应遍历两个文件
        for line_num, (line1, line2) in enumerate(zip(f1, f2), 1):
            line1 = line1.strip()
            line2 = line2.strip()
            
            # 跳过空行
            if not line1 or not line2:
                continue
                
            try:
                data1 = json.loads(line1)
                data2 = json.loads(line2)
                
                # 提取指定的字段，使用 get 防止某些行缺少键而报错
                merged_data = {
                    "id": data1.get("id"),
                    "response": data1.get("response"),
                    "extracted_answer": data2.get("extracted_answer")
                }
                
                # 将合并后的字典转换为 JSON 字符串并写入新文件
                out_f.write(json.dumps(merged_data, ensure_ascii=False) + '\n')
                
            except json.JSONDecodeError as e:
                print(f"第 {line_num} 行 JSON 解析错误: {e}")

    print(f"处理完成！提取的数据已保存至: {output_path}")

if __name__ == "__main__":
    merge_jsonl_files()