import json
import os
import re

# ================= 核心清洗逻辑 (保持不变) =================

def normalize_text_basic(text):
    """基础文本清洗"""
    if not text:
        return ""
    text = str(text).strip().lower()
    text = re.sub(r"\\text\{([^}]+)\}", r"\1", text)
    if text.endswith("."):
        text = text[:-1]
    format_cmds = [
        r"\left", r"\right", r"\mathrm", r"\mathbf", r"\mathbb",
        r"\displaystyle", r"\quad", r"\,", r"\ "
    ]
    for cmd in format_cmds:
        text = text.replace(cmd, "")
    wrappers = [r"\(", r"\)", r"\[", r"\]", r"\boxed", r"$"]
    for w in wrappers:
        text = text.replace(w, "")
    text = re.sub(r"\\pmod\{?(\d+)\}?", r"mod\1", text)
    text = "".join(text.split())
    return text

def normalize_formula(text):
    """数学公式深度清洗"""
    text = text.replace(r"\dfrac", r"\frac")
    text = text.replace(r"\dbinom", r"\binom")
    text = re.sub(r"\{(.+?)\\choose(.+?)\}", r"\\binom{\1}{\2}", text)
    text = re.sub(r"\\frac\{(\w+)!([^}]*)\}\{(\w+)!?\((\1-\3)\)!?\}", r"\\binom{\1}{\3}\2", text)
    text = re.sub(r"\\frac\{(\w+)!\}\{(\w+)!?\((\1-\2)\)!?\}", r"\\binom{\1}{\2}", text)
    text = re.sub(r"\\frac\{(\w+)!\}\{\(\1-(\w+)\)!?(\2)!?\}", r"\\binom{\1}{\2}", text)
    return text

def check_equivalence(std_raw, model_raw, q_id="unknown"):
    """判定逻辑"""
    norm_std = normalize_formula(normalize_text_basic(std_raw))
    norm_model = normalize_formula(normalize_text_basic(model_raw))
    
    if norm_std == norm_model: return True

    try:
        if abs(float(norm_std) - float(norm_model)) < 1e-9: return True
    except (ValueError, TypeError): pass

    std_rhs = norm_std.split("=")[-1] if "=" in norm_std else norm_std
    model_rhs = norm_model.split("=")[-1] if "=" in norm_model else norm_model
    if std_rhs == model_rhs: return True
    
    try:
        if abs(float(std_rhs) - float(model_rhs)) < 1e-9: return True
    except (ValueError, TypeError): pass

    if norm_std.startswith("yes") and norm_model == "yes": return True

    def get_groups(s): return sorted(re.findall(r"\([^)]+\)", s))
    if get_groups(std_rhs) and get_groups(model_rhs) and get_groups(std_rhs) == get_groups(model_rhs): return True

    # 特定题目逻辑
    if "constant" in norm_model and "equal" in norm_std:
        if "sequences" in norm_model or "configurations" in norm_model: return True
    
    map_model = norm_model.replace("p^2", "squareofprime").replace("p", "prime")
    if "prime" in map_model and "square" in map_model and "prime" in norm_std: return True

    def extract_remainders(s):
        res1 = re.findall(r"6n_?0?\+(\d)", s)
        res2 = []
        if "mod6" in s:
            all_nums = re.findall(r"\d", s)
            res2 = [x for x in all_nums if x != '6']
        return set(res1 + res2)
    if extract_remainders(norm_std) and extract_remainders(norm_model) and extract_remainders(norm_std) == extract_remainders(norm_model): return True

    if "q^*" in norm_std or "q*" in norm_std:
        if "z" in norm_model and "2z" in norm_model: return True

    return False

# ================= 修改后的按行评测逻辑 =================

def evaluate_line_by_line(gt_path, pred_path, output_path):
    print(f"📂 读取标准答案: {gt_path}")
    gt_lines = []
    try:
        with open(gt_path, 'r', encoding='utf-8') as f:
            # 过滤空行，确保严谨
            gt_lines = [json.loads(line) for line in f if line.strip()]
    except FileNotFoundError:
        print(f"❌ 错误: 找不到文件 {gt_path}")
        return

    print(f"📂 读取预测结果: {pred_path}")
    pred_lines = []
    try:
        with open(pred_path, 'r', encoding='utf-8') as f:
            pred_lines = [json.loads(line) for line in f if line.strip()]
    except FileNotFoundError:
        print(f"❌ 错误: 找不到文件 {pred_path}")
        return

    # 简单的行数检查
    if len(gt_lines) != len(pred_lines):
        print(f"⚠️ 警告: 行数不一致！GT有 {len(gt_lines)} 行, Pred有 {len(pred_lines)} 行")
        print("➡️ 将以较短的文件长度为准进行截断评测...")
    
    correct_count = 0
    total_count = 0

    print("🚀 开始按行比对...")
    with open(output_path, 'w', encoding='utf-8') as f_out:
        # 使用 zip 同时遍历两个列表
        for i, (gt_item, pred_item) in enumerate(zip(gt_lines, pred_lines)):
            
            # 获取 ID (仅用于日志记录，不用于匹配)
            q_id = gt_item.get('id', str(i))
            
            # 获取内容
            gt_raw = gt_item.get('response', "")
            # 注意：这里假设你的预测文件里提取出的答案字段叫 'extracted_answer'
            # 如果没提取出来，尝试用 response 字段或者空字符串
            model_raw = pred_item.get('extracted_answer', "") 
            if not model_raw and 'response' in pred_item:
                 # 兼容逻辑：如果extracted_answer为空，但有response，可能需要这里临时提取一下，或者直接用
                 pass 

            # 执行判定
            is_correct = check_equivalence(gt_raw, model_raw, q_id)
            
            if is_correct:
                correct_count += 1
            total_count += 1

            # 写入结果
            res = {
                "id": q_id,
                "line_index": i,  # 记录行号方便排查
                "standard_answer": gt_raw,
                "model_answer": model_raw,
                "is_correct": is_correct
            }
            f_out.write(json.dumps(res, ensure_ascii=False) + '\n')

    # 计算最终指标
    acc = (correct_count / total_count * 100) if total_count > 0 else 0
    print("-" * 30)
    print(f"✅ 处理完成！")
    print(f"总计评估: {total_count}")
    print(f"正确数量: {correct_count}")
    print(f"准确率: {acc:.2f}%")
    print(f"结果已保存至: {output_path}")

if __name__ == "__main__":
    # 配置你的文件路径
    ground_truth_file = "ground_truth.jsonl"
    predictions_file = "merged_boxed.jsonl"
    output_file = "evaluation.jsonl"
    
    evaluate_line_by_line(ground_truth_file, predictions_file, output_file)