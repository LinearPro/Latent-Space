import json
import os

def merge_and_rename_to_32():
    # --- 文件名定义 ---
    file_2024 = 'predictions_manual1_aime2024_2024.jsonl'
    file_2025 = 'predictions_manual1_aime2024_2025.jsonl'
    file_merged_final = 'merged_final.jsonl'
    
    file_pred_7 = 'pred_7.jsonl'
    file_pred_25 = 'pred_25.jsonl'
    file_pred_32 = 'pred_32.jsonl'

    # ==========================================
    # 步骤 1：拼接 2024 和 2025，生成 pred_7.jsonl
    # ==========================================
    print("正在执行步骤 1：拼接生成 pred_7.jsonl...")
    lines_pred_7 = []
    for fname in [file_2024, file_2025]:
        if os.path.exists(fname):
            with open(fname, 'r', encoding='utf-8') as f:
                lines_pred_7.extend([line for line in f if line.strip()])
        else:
            print(f"⚠️ 警告: 未找到文件 {fname}")

    with open(file_pred_7, 'w', encoding='utf-8') as f:
        f.writelines(lines_pred_7)

    # ==========================================
    # 步骤 2：重命名 merged_final.jsonl 生成 pred_25.jsonl
    # ==========================================
    print("正在执行步骤 2：重命名生成 pred_25.jsonl...")
    lines_pred_25 = []
    if os.path.exists(file_merged_final):
        with open(file_merged_final, 'r', encoding='utf-8') as f:
            valid_lines = [line for line in f if line.strip()]
            for index, line in enumerate(valid_lines):
                item = json.loads(line)
                q_num = (index // 25) + 1
                s_num = index % 25
                item["id"] = f"{q_num}_sample_{s_num}"
                lines_pred_25.append(json.dumps(item, ensure_ascii=False) + '\n')
                
        with open(file_pred_25, 'w', encoding='utf-8') as f:
            f.writelines(lines_pred_25)
    else:
        print(f"⚠️ 错误: 未找到 {file_merged_final}，程序终止。")
        return

    # ==========================================
    # 步骤 3 & 4：交替合并 25+7，统一重命名生成 pred_32.jsonl
    # ==========================================
    print("正在执行步骤 3 & 4：交替合并并最终重命名为 pred_32.jsonl...")
    total_questions = 60
    chunk_25 = 25
    chunk_7 = 7
    
    final_lines_32 = []

    for i in range(total_questions):
        # 提取第 i+1 题的两部分数据
        start_25 = i * chunk_25
        q_lines_25 = lines_pred_25[start_25 : start_25 + chunk_25]
        
        start_7 = i * chunk_7
        q_lines_7 = lines_pred_7[start_7 : start_7 + chunk_7]
        
        # 将当前题目的 25 行和 7 行组合成 32 行
        combined_32 = q_lines_25 + q_lines_7
        
        # 步骤 4的逻辑：对这 32 行重新分配 id (0 到 31)
        for j, line in enumerate(combined_32):
            item = json.loads(line)
            q_num = i + 1
            s_num = j
            item["id"] = f"{q_num}_sample_{s_num}"
            final_lines_32.append(json.dumps(item, ensure_ascii=False) + '\n')

    # 将最终数据写入 pred_32.jsonl
    with open(file_pred_32, 'w', encoding='utf-8') as f_out:
        f_out.writelines(final_lines_32)

    print(f"✅ 全部完成！最终文件已保存为 {file_pred_32}")
    print(f"文件信息：共 {total_questions} 题，每题 {chunk_25 + chunk_7} 个解答，总计 {len(final_lines_32)} 行。")

if __name__ == "__main__":
    merge_and_rename_to_32()