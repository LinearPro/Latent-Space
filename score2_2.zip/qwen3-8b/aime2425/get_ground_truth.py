import json

def generate_ground_truth():
    input_file = 'merged_repeated_32_by_lines.jsonl'
    output_file = 'ground_truth.jsonl'
    
    processed_lines = 0

    with open(input_file, 'r', encoding='utf-8') as fin, \
         open(output_file, 'w', encoding='utf-8') as fout:
        
        for idx, line in enumerate(fin):
            if not line.strip():
                continue
            
            # 读取当前行的 JSON 数据
            item = json.loads(line)
            
            # 计算题目编号 (1 到 60) 和 sample 编号 (0 到 31)
            q_num = (idx // 32) + 1
            s_num = idx % 32
            
            # 覆写 id 字段
            item['id'] = f"{q_num}_sample_{s_num}"
            
            # 将处理后的数据写入新文件
            fout.write(json.dumps(item, ensure_ascii=False) + '\n')
            processed_lines += 1

    print(f"处理完成！共重命名并保存了 {processed_lines} 行。")
    print(f"文件已保存为：{output_file}")

if __name__ == "__main__":
    generate_ground_truth()