import json
import re

# 定义输入和输出文件名
input_file = 'pred_32.jsonl'
output_file = 'compare.jsonl'  # 修改了输出文件名

# 编译正则表达式：匹配一段连续的数字
number_pattern = re.compile(r'\d+')

# 计数器
processed_count = 0
not_found_count = 0

print(f"开始处理文件: {input_file} ...")

with open(input_file, 'r', encoding='utf-8') as infile, \
     open(output_file, 'w', encoding='utf-8') as outfile:
    
    for line in infile:
        # 忽略空行
        if not line.strip():
            continue
            
        # 解析当前行的 JSON 数据
        data = json.loads(line)
        
        # 1. 获取文本
        pred_text = data.get('pred', '')
        # 根据你的原代码注释，标准答案可能在 'response' 字段。这里做个兼容，如果没有就找 'answer'
        standard_text = str(data.get('response', data.get('answer', ''))) 
        
        # 2. 提取模型回答（最后一个数字）
        pred_numbers = number_pattern.findall(pred_text)
        if pred_numbers:
            model_answer = pred_numbers[-1]
        else:
            model_answer = None
            not_found_count += 1
            
        # 3. 提取标准答案（同样提取数字以便精准对比，如果标准答案本身就是干净的数字，这步也能完美兼容）
        std_numbers = number_pattern.findall(standard_text)
        standard_answer = std_numbers[-1] if std_numbers else standard_text
            
        # 4. 构建用于对比的精简数据字典
        compare_data = {
            'id': data.get('id', 'unknown_id'),
            'model_answer': model_answer,
            'standard_answer': standard_answer,
            # 可选：如果对比时发现错误，保留原始文本有助于定位问题，你可以把下面两行的注释取消
            # 'raw_pred': pred_text,
            # 'raw_standard': standard_text
        }
            
        # 写入 compare.jsonl
        outfile.write(json.dumps(compare_data, ensure_ascii=False) + '\n')
        
        processed_count += 1

print("-" * 30)
print(f"处理完成！")
print(f"共处理了 {processed_count} 条数据。")
if not_found_count > 0:
    print(f"警告：有 {not_found_count} 条数据未能从模型回答(pred)中提取到数字。")
print(f"对比结果已成功保存至: {output_file}")