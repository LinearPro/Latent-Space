import os
import pandas as pd
import json
import matplotlib.pyplot as plt

# 1. 读取 jsonl 数据
data = []
with open('metrics.jsonl', 'r') as f:
    for line in f:
        data.append(json.loads(line))
df = pd.DataFrame(data)

# 确保图片保存文件夹存在
os.makedirs('figure', exist_ok=True)

# 定义需要提取的 x 轴和 y 轴列名
x_cols = ['incoh_first_10pct', 'incoh_first_20pct', 'incoh_first_40pct', 'incoh_first_80pct', 'incoh_first_100pct']
y_cols = ['fric_first_10pct', 'fric_first_20pct', 'fric_first_40pct', 'fric_first_80pct', 'fric_first_100pct']

# 2. 按 'is_correct' 分组，计算所有回答在对应比例的均值
mean_stats = df.groupby('is_correct')[x_cols + y_cols].mean()

# 3. 开始绘图
plt.figure(figsize=(10, 8))

# 如果存在错误(False)的数据，绘制其平均轨迹（红线）
if False in mean_stats.index:
    x_vals_f = mean_stats.loc[False, x_cols].values
    y_vals_f = mean_stats.loc[False, y_cols].values
    plt.plot(x_vals_f, y_vals_f, marker='o', color='red', label='Incorrect (Average)', linewidth=2, markersize=8)

# 如果存在正确(True)的数据，绘制其平均轨迹（蓝线）
if True in mean_stats.index:
    x_vals_t = mean_stats.loc[True, x_cols].values
    y_vals_t = mean_stats.loc[True, y_cols].values
    plt.plot(x_vals_t, y_vals_t, marker='o', color='blue', label='Correct (Average)', linewidth=2, markersize=8)

# 为每个点添加文本标签 (10%, 20%, 40%, 80%, 100%)
labels = ['10%', '20%', '40%', '80%', '100%']
# 针对正确（蓝色，文字向上偏10）和错误（红色，文字向下偏15）的轨迹分别标注
for val, color, offset in [(True, 'blue', 10), (False, 'red', -15)]:
    if val in mean_stats.index:
        for i in range(5):
            plt.annotate(labels[i],
                         (mean_stats.loc[val, x_cols[i]], mean_stats.loc[val, y_cols[i]]),
                         textcoords="offset points", 
                         xytext=(0, offset), 
                         ha='center', 
                         color=color, 
                         fontweight='bold')

# 设置图表格式
plt.xlabel('Incoherence (incoh)')
plt.ylabel('Friction (fric)')
plt.title('Average Trajectory: Correct vs Incorrect CoT')
plt.grid(True)
plt.legend()

# 保存图片
plt.savefig('figure/average_trajectory_comparison.png')
plt.close()

print("平均轨迹对比图已保存至 figure/average_trajectory_comparison.png")