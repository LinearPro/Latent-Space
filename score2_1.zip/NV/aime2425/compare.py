import pandas as pd
import numpy as np

# 1. 加载数据并过滤掉出错的行
df = pd.read_json('metrics_new.jsonl', lines=True)
valid_df = df[df['error'].isnull()].copy()

# 2. 假设每道题有 32 个候选 CoT，分配题目 ID
SAMPLES_PER_QUESTION = 32
valid_df['question_id'] = valid_df.index // SAMPLES_PER_QUESTION
valid_df['sample_id'] = valid_df.index % SAMPLES_PER_QUESTION

# ==========================================
# 新增：计算基础 Pass@1 和 Pass@32 准确率
# ==========================================
# Pass@1: 相当于从每题的候选集中随机盲选 1 个的期望准确率
# 计算方法：先算每题的正确率（对/总数），再跨题目求平均
pass_at_1 = valid_df.groupby('question_id')['is_correct'].mean().mean() * 100

# Pass@32: 每道题只要有 >= 1 个候选项是正确的，这道题就算做对
# 计算方法：判断每题的分组内是否 .any() 为 True，再求整体平均比例
pass_at_32 = valid_df.groupby('question_id')['is_correct'].any().mean() * 100

print("="*50)
print(f"基准测试结果 (每题 {SAMPLES_PER_QUESTION} 个候选):")
print(f"随机选择 (Pass@1) 准确率:  {pass_at_1:.2f}%")
print(f"理论上限 (Pass@32) 准确率: {pass_at_32:.2f}%")
print("="*50 + "\n")

# ==========================================
# 3. 遍历每个指标，执行“最佳 CoT”挑选
# ==========================================
# 找出所有的指标列
metric_cols = [c for c in valid_df.columns if c not in ['is_correct', 'error', 'question_id', 'sample_id']]
results = []

for col in metric_cols:
    # 规则: incoh 越小（负得越多）越好，fric 越大越好
    ascending = True if 'incoh' in col else False
    
    # 找出每道题下，该指标表现最好的那一条 CoT 的所在行索引
    if ascending:
        best_indices = valid_df.groupby('question_id')[col].idxmin()
    else:
        best_indices = valid_df.groupby('question_id')[col].idxmax()
        
    # 根据选出的索引，直接取出那些被选中 CoT 的对错状态 (is_correct)
    selected_correctness = valid_df.loc[best_indices, 'is_correct']
    
    # 计算当前指标选出来的整体准确率
    accuracy = selected_correctness.mean() * 100
    results.append({'Metric': col, 'Accuracy (%)': round(accuracy, 2)})

# 4. 打印并排序各个指标的结果
results_df = pd.DataFrame(results).sort_values(by='Accuracy (%)', ascending=False)
print("各指标作为筛选器选出最佳 CoT 的最终准确率排名：")
print("-" * 50)
print(results_df.to_string(index=False))