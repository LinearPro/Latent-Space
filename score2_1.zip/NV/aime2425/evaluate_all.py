import pandas as pd
import numpy as np
import json
import os
from collections import Counter

def evaluate_metrics(file_path='metrics_qwen4b.jsonl'):
    """
    计算 Pass@1, Pass@32 以及基于各指标筛选最佳 CoT 的准确率
    """
    print(">>> 正在执行基于指标的 CoT 评估...")
    if not os.path.exists(file_path):
        print(f"未找到文件: {file_path}\n")
        return

    # 1. 加载数据并过滤掉出错的行
    df = pd.read_json(file_path, lines=True)
    valid_df = df[df['error'].isnull()].copy()

    # 2. 假设每道题有 32 个候选 CoT，分配题目 ID
    SAMPLES_PER_QUESTION = 32
    valid_df['question_id'] = valid_df.index // SAMPLES_PER_QUESTION
    valid_df['sample_id'] = valid_df.index % SAMPLES_PER_QUESTION

    # ==========================================
    # 计算基础 Pass@1 和 Pass@32 准确率
    # ==========================================
    pass_at_1 = valid_df.groupby('question_id')['is_correct'].mean().mean() * 100
    pass_at_32 = valid_df.groupby('question_id')['is_correct'].any().mean() * 100

    print("="*50)
    print(f"基准测试结果 (每题 {SAMPLES_PER_QUESTION} 个候选):")
    print(f"随机选择 (Pass@1) 准确率:  {pass_at_1:.2f}%")
    print(f"理论上限 (Pass@32) 准确率: {pass_at_32:.2f}%")
    print("="*50 + "\n")

    # ==========================================
    # 新增：计算自定义组合指标
    # fric_first_100pct - incoh_last_10pct
    # ==========================================
    custom_metric_name = 'custom_fric_minus_incoh'
    if 'fric_first_100pct' in valid_df.columns and 'incoh_last_10pct' in valid_df.columns:
        valid_df[custom_metric_name] = valid_df['fric_first_100pct'] - valid_df['incoh_last_10pct']
    else:
        print("警告: 数据中缺失 'fric_first_100pct' 或 'incoh_last_10pct' 列，无法计算组合指标。")

    # ==========================================
    # 3. 遍历每个指标，执行“最佳 CoT”挑选
    # ==========================================
    # 找出所有的指标列 (包括刚才新增的自定义指标)
    metric_cols = [c for c in valid_df.columns if c not in ['is_correct', 'error', 'question_id', 'sample_id']]
    results = []

    for col in metric_cols:
        # 确定指标的挑选规则：
        # incoh 越小越好 (ascending=True)
        # 组合指标 custom_fric_minus_incoh (大减去小) 则是越大越好 (ascending=False)
        # 其他指标（如 fric）越大越好 (ascending=False)
        if col == custom_metric_name:
            ascending = False
        else:
            ascending = True if 'incoh' in col else False
        
        # 找出每道题下，该指标表现最好的那一条 CoT 的所在行索引
        if ascending:
            best_indices = valid_df.groupby('question_id')[col].idxmin()
        else:
            best_indices = valid_df.groupby('question_id')[col].idxmax()
            
        # 根据选出的索引，直接取出那些被选中 CoT 的对错状态 (is_correct)
        selected_correctness = valid_df.loc[best_indices, 'is_correct']
        
        # 计算当前指标选出来的整体准确率
        accuracy = selected_correctness.mean() * 100
        results.append({'Metric': col, 'Accuracy (%)': round(accuracy, 2)})

    # 4. 打印并排序各个指标的结果
    results_df = pd.DataFrame(results).sort_values(by='Accuracy (%)', ascending=False)
    print("各指标作为筛选器选出最佳 CoT 的最终准确率排名：")
    print("-" * 50)
    print(results_df.to_string(index=False))
    print("\n")


def evaluate_majority_vote(file_path='evaluation.jsonl'):
    """
    计算多数投票 (Majority Vote) 的正确率
    """
    print(">>> 正在执行 Majority Vote 评估...")
    if not os.path.exists(file_path):
        print(f"未找到文件: {file_path}\n")
        return

    problems = {}

    # 1. 读取 jsonl 数据并按题目分组
    with open(file_path, 'r', encoding='utf-8') as f:
        for line in f:
            data = json.loads(line.strip())
            
            prob_id = data['id'].split('_sample_')[0]
            
            if prob_id not in problems:
                problems[prob_id] = {
                    'standard_answer': data['standard_answer'],
                    'model_answers': []
                }
            
            problems[prob_id]['model_answers'].append(data['model_answer'])

    correct_count = 0
    total_problems = len(problems)

    # 2. 计算 Majority Vote 并验证正确性
    for prob_id, prob_data in problems.items():
        standard_answer = prob_data['standard_answer']
        model_answers = prob_data['model_answers']
        
        counter = Counter(model_answers)
        majority_answer = counter.most_common(1)[0][0]
        
        if str(majority_answer) == str(standard_answer):
            correct_count += 1

    # 3. 输出计算结果
    accuracy = (correct_count / total_problems) * 100 if total_problems > 0 else 0

    print("="*50)
    print(f"Majority Vote 结果:")
    print(f"总题目数: {total_problems}")
    print(f"正确的题目数: {correct_count}")
    print(f"最终正确率: {accuracy:.2f}%")
    print("="*50 + "\n")


if __name__ == "__main__":
    # 分别调用两个评估函数，默认读取当前目录下的 metrics.jsonl 和 evaluation.jsonl
    evaluate_metrics(file_path='metrics.jsonl')
    evaluate_majority_vote(file_path='evaluation.jsonl')