import json
import os

def generate_final_test():
    train_file = "final_training_data.jsonl"
    truth_file = "ground_truth.jsonl"
    output_file = "final_test.jsonl"
    
    # 检查文件是否存在
    if not os.path.exists(train_file):
        print(f"❌ 找不到文件: {train_file}")
        return
    if not os.path.exists(truth_file):
        print(f"❌ 找不到文件: {truth_file}")
        return

    processed_lines = 0
    
    print("开始拼接数据...")
    
    # 定义需要被删除的提示词后缀和前缀
    suffix_to_remove = "\n\nPlease reason step by step, and put your final answer within \\boxed{}"
    prefix_to_remove_1 = "\n<think>\n"
    prefix_to_remove_2 = "<think>\n"  # 增加容错：如果开头没有换行符的情况
    
    # 使用 zip 同时逐行读取两个文件，避免大文件将内存撑爆
    with open(train_file, 'r', encoding='utf-8') as f_train, \
         open(truth_file, 'r', encoding='utf-8') as f_truth, \
         open(output_file, 'w', encoding='utf-8') as f_out:
        
        for train_line, truth_line in zip(f_train, f_truth):
            train_line = train_line.strip()
            truth_line = truth_line.strip()
            
            if not train_line or not truth_line:
                continue
                
            try:
                train_data = json.loads(train_line)
                truth_data = json.loads(truth_line)
            except json.JSONDecodeError as e:
                print(f"⚠️ 解析 JSON 失败，跳过该行: {e}")
                continue
            
            # 提取所需字段
            is_correct = train_data.get("is_correct")
            query = truth_data.get("query", "")
            original_pred = train_data.get("pred", "")
            
            # --- 1. 删除 query 末尾的特定字符串 ---
            if query.endswith(suffix_to_remove):
                query = query[:-len(suffix_to_remove)]
                
            # --- 2. 删除 original_pred 开头的特定字符串 ---
            if original_pred.startswith(prefix_to_remove_1):
                original_pred = original_pred[len(prefix_to_remove_1):]
            elif original_pred.startswith(prefix_to_remove_2):
                original_pred = original_pred[len(prefix_to_remove_2):]
            # -----------------------------------------------
            
            # 拼接 query 和 pred（中间加入一个换行符区分）
            combined_pred = f"{query}\n{original_pred}"
            
            # 构造新的字典
            new_data = {
                "is_correct": is_correct,
                "pred": combined_pred,
                "query": query
            }
            
            # 写入到新文件
            f_out.write(json.dumps(new_data, ensure_ascii=False) + "\n")
            processed_lines += 1
            
    print(f"✅ 处理完成！成功生成 {processed_lines} 条数据，已保存至 {output_file}")

if __name__ == "__main__":
    generate_final_test()