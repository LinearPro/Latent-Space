import json
from collections import Counter

file_path = 'evaluation.jsonl'
problems = {}

# 1. 读取 jsonl 数据并按题目分组
with open(file_path, 'r', encoding='utf-8') as f:
    for line in f:
        data = json.loads(line.strip())
        
        # 提取题目ID，如 "1_sample_0" 提取出 "1"
        prob_id = data['id'].split('_sample_')[0]
        
        if prob_id not in problems:
            problems[prob_id] = {
                'standard_answer': data['standard_answer'],
                'model_answers': []
            }
        
        # 收集该题目的所有模型生成的答案
        problems[prob_id]['model_answers'].append(data['model_answer'])

correct_count = 0
total_problems = len(problems)

# 2. 计算 Majority Vote 并验证正确性
for prob_id, prob_data in problems.items():
    standard_answer = prob_data['standard_answer']
    model_answers = prob_data['model_answers']
    
    # 统计出现频率最高的答案
    counter = Counter(model_answers)
    majority_answer = counter.most_common(1)[0][0]
    
    # 对比标准答案
    if str(majority_answer) == str(standard_answer):
        correct_count += 1

# 3. 输出计算结果
accuracy = (correct_count / total_problems) * 100

print(f"总题目数: {total_problems}")
print(f"Majority Vote 正确的题目数: {correct_count}")
print(f"Majority Vote 正确率: {accuracy:.2f}%")