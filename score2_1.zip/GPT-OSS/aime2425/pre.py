import json

def get_sort_key(id_str):
    """
    解析 id 字符串，返回用于排序的整数元组 (problem_id, sample_id)
    例如: "1_sample_2" -> (1, 2)
    """
    parts = id_str.split('_sample_')
    return int(parts[0]), int(parts[1])

def process_and_merge_jsonl(file_2024, file_2025, output_file):
    # ==========================================
    # 1. 处理 AIME 2024 数据
    # ==========================================
    data_2024 = []
    with open(file_2024, 'r', encoding='utf-8') as f:
        for line in f:
            if line.strip():
                data_2024.append(json.loads(line))
                
    # 按照 id 进行正确的数值排序
    data_2024.sort(key=lambda x: get_sort_key(x['id']))
    print(f"已加载并排序 2024 数据: {len(data_2024)} 条")

    # ==========================================
    # 2. 处理 AIME 2025 数据
    # ==========================================
    data_2025 = []
    with open(file_2025, 'r', encoding='utf-8') as f:
        for line in f:
            if line.strip():
                data_2025.append(json.loads(line))
                
    # 按照 id 进行正确的数值排序
    data_2025.sort(key=lambda x: get_sort_key(x['id']))
    
    # 遍历修改 2025 数据的 id (第一部分数字 +30)
    for item in data_2025:
        prob_id, sample_id = get_sort_key(item['id'])
        item['id'] = f"{prob_id + 30}_sample_{sample_id}"
        
    print(f"已加载、排序并修改 2025 数据: {len(data_2025)} 条")

    # ==========================================
    # 3. 合并并保存结果
    # ==========================================
    merged_data = data_2024 + data_2025

    with open(output_file, 'w', encoding='utf-8') as f:
        for item in merged_data:
            f.write(json.dumps(item, ensure_ascii=False) + '\n')
            
    print(f"处理完成！合并后的文件已保存至: {output_file}")
    print(f"合并后总数据量: {len(merged_data)} 条")

if __name__ == "__main__":
    # 配置文件路径
    INPUT_2024 = "aime2024_gpt_oss.jsonl"
    INPUT_2025 = "aime2025_gpt_oss.jsonl"
    OUTPUT_MERGED = "merged_aime_gpt_oss.jsonl"
    
    process_and_merge_jsonl(INPUT_2024, INPUT_2025, OUTPUT_MERGED)