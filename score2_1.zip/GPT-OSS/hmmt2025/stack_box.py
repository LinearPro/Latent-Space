import json
import re
import os

def extract_answer(text):
    """
    使用括号匹配算法提取 \boxed{} 内的完整答案。
    完美支持 LaTeX 中的嵌套大括号 (如 \frac{1}{2}) 以及无大括号的情况。
    """
    if not isinstance(text, str):
        return None
        
    boxed_str = r'\boxed'
    # 使用 rfind 寻找最后一个 \boxed（通常正确答案在最后）
    idx = text.rfind(boxed_str)
    if idx == -1:
        return None  # 如果文本里根本没有 \boxed，直接返回 None
        
    start_idx = idx + len(boxed_str)
    
    # 跳过 \boxed 后面的空白字符
    while start_idx < len(text) and text[start_idx].isspace():
        start_idx += 1
        
    if start_idx >= len(text):
        return None
        
    # 情况 1：带有大括号 \boxed{...}
    if text[start_idx] == '{':
        braces = 1
        content_start = start_idx + 1
        for i in range(content_start, len(text)):
            if text[i] == '{':
                braces += 1
            elif text[i] == '}':
                braces -= 1
                
            # 当大括号完美闭合时，提取中间的内容
            if braces == 0:
                return text[content_start:i].strip()
                
        # 如果模型生成截断导致大括号没有闭合，提取剩下所有的
        return text[content_start:].strip()
        
    # 情况 2：没有大括号，例如 \boxed-984 或 \boxed 103
    else:
        # 匹配直到遇到空格、逗号、句号或新的 LaTeX 反斜杠为止
        match = re.match(r'([^{\s,.\\]+)', text[start_idx:])
        if match:
            return match.group(1).strip()
            
    return None


def process_file(input_file, output_file):
    print(f">>> 开始处理文件: {input_file}")
    
    if not os.path.exists(input_file):
        print(f"错误: 找不到输入文件 '{input_file}'")
        return

    processed_count = 0
    extracted_count = 0

    with open(input_file, 'r', encoding='utf-8') as fin, \
         open(output_file, 'w', encoding='utf-8') as fout:
        
        for line in fin:
            line = line.strip()
            if not line:
                continue
                
            try:
                data = json.loads(line)
            except json.JSONDecodeError:
                continue
                
            processed_count += 1
            
            # 【致命修复】强制只从 'pred' 字段读取原始完整文本！
            # 绝对不能读 'model_answer'，因为它可能已经被污染成了纯数字
            raw_text = data.get('pred', '') 
            
            # 提取正确的答案
            extracted = extract_answer(raw_text)
            
            if extracted is not None:
                extracted_count += 1
                
            # 保存到 extracted_answer
            data['extracted_answer'] = extracted
            
            # 顺便修复之前被破坏的 model_answer，如果你后续评测需要用到的话
            # 如果提取成功，就用提取的完整符号答案覆盖错误的纯数字答案
            if extracted is not None:
                 data['model_answer'] = extracted
            
            fout.write(json.dumps(data, ensure_ascii=False) + '\n')
            
    print("-" * 40)
    print(">>> 处理完成！")
    print(f"总计读取数据: {processed_count} 条")
    print(f"成功通过 \\boxed 提取答案: {extracted_count} 条")
    print(f"结果已保存至: {output_file}")

if __name__ == '__main__':
    # 确保这里的输入文件是你最初包含长段推理文本的那个文件！
    INPUT_FILENAME = 'pred_32.jsonl'  
    OUTPUT_FILENAME = 'merged_boxed.jsonl'
    
    process_file(INPUT_FILENAME, OUTPUT_FILENAME)