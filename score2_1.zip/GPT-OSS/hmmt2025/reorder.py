import json

# 定义输入和输出文件名
input_file = 'hmmt2025_gpt_oss.jsonl'
output_file = 'pred_32.jsonl'

def get_sort_key(item):
    """
    解析 id 用于实现数值排序。
    将 '1_sample_3' 解析为元组 (1, 3)，这样排序时会按数字大小比较。
    """
    item_id = str(item.get('id', ''))
    try:
        if "_sample_" in item_id:
            parts = item_id.split('_sample_')
            return (int(parts[0]), int(parts[1]))
        else:
            # 如果不包含 "_sample_"，将无法解析的部分排在最前面
            return (-1, -1)
    except ValueError:
        # 容错处理：如果提取出的不是纯数字，则返回默认值
        return (-1, -1)

# 1. 读取所有的 JSONL 数据到列表中
data_list = []
print(f"正在读取文件: {input_file} ...")
with open(input_file, 'r', encoding='utf-8') as f:
    for line in f:
        if line.strip():
            data_list.append(json.loads(line))

# 2. 根据 id 进行排序
print("正在进行数值排序...")
data_list.sort(key=get_sort_key)

# 3. 提取所需字段并写入输出文件
print(f"正在提取字段并保存至: {output_file} ...")
with open(output_file, 'w', encoding='utf-8') as f:
    for item in data_list:
        # 构建只包含目标字段的新字典
        processed_item = {
            "id": item.get("id"),
            "query": item.get("query"),
            "response": item.get("response"),
            "pred": item.get("raw_pred")  # 提取 raw_pred 并直接命名为 pred
        }
        f.write(json.dumps(processed_item, ensure_ascii=False) + '\n')

print("处理完成！")