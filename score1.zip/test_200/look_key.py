import json

# 创建一个空集合，用于自动去重并存储所有发现的键
all_keys = set()

# 打开文件逐行读取
with open('metrics.jsonl', 'r', encoding='utf-8') as f:
    for line in f:
        # 跳过空行
        if not line.strip():
            continue
        
        # 解析当前行的 JSON 数据
        data = json.loads(line)
        
        # 将当前行包含的键加入集合中
        all_keys.update(data.keys())

print("该文件包含的所有键有：", all_keys)