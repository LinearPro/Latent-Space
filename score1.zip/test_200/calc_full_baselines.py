import json
import torch
import os
from tqdm import tqdm
from transformers import AutoModelForCausalLM, AutoTokenizer
import numpy as np

# ================= 配置区域 =================
MODEL_PATH = "/WORK/PUBLIC/dongyinp_work/lingp/models/Qwen3-4B-Thinking-2507"
# !!! 关键修改：输入文件必须是包含 PPL/LogProbs 的那个文件 !!!
INPUT_FILE = "aime2024_2025_with_logprobs.jsonl" 
OUTPUT_FILE = "aime2024_2025_with_all_metrics.jsonl"
ANSWER_FIELD = "pred"
# ===========================================

def load_model(model_path):
    print(f"🔄 加载模型: {model_path} ...")
    tokenizer = AutoTokenizer.from_pretrained(model_path, trust_remote_code=True)
    model = AutoModelForCausalLM.from_pretrained(
        model_path, device_map="auto", torch_dtype=torch.bfloat16, trust_remote_code=True
    )
    model.eval()
    return tokenizer, model

def compute_baselines(model, tokenizer, text):
    inputs = tokenizer(text, return_tensors="pt", add_special_tokens=True).to(model.device)
    
    # 显存优化：如果不使用 torch.no_grad() 会炸显存
    with torch.no_grad():
        outputs = model(**inputs, output_hidden_states=True)
        logits = outputs.logits
        hidden_states = outputs.hidden_states

    # 1. 计算 Entropy
    probs = torch.nn.functional.softmax(logits, dim=-1)
    log_probs = torch.nn.functional.log_softmax(logits, dim=-1)
    token_entropies = -(probs * log_probs).sum(dim=-1)
    avg_entropy = token_entropies.mean().item()

    # 2. 计算 Layer-wise Cosine Similarity
    layer_sims = []
    num_layers = len(hidden_states)
    
    # 转换为 float32 计算以避免精度溢出，并尽快转移到 CPU
    for i in range(1, num_layers - 1):
        h_current = hidden_states[i].to(torch.float32)
        h_next = hidden_states[i+1].to(torch.float32)
        sim = torch.nn.functional.cosine_similarity(h_current, h_next, dim=-1)
        layer_sims.append(sim.mean().item())
        
        # 手动释放显存引用
        del h_current, h_next
        
    avg_layer_sim = np.mean(layer_sims)
    
    # 清理显存
    del outputs, logits, hidden_states, inputs
    torch.cuda.empty_cache()

    return avg_entropy, avg_layer_sim

def main():
    tokenizer, model = load_model(MODEL_PATH)
    
    if not os.path.exists(INPUT_FILE):
        print(f"❌ 错误：找不到输入文件 {INPUT_FILE}。请确保您先运行了 calc_unconditional_logprobs.py 生成该文件。")
        return

    with open(INPUT_FILE, 'r', encoding='utf-8') as fin, \
         open(OUTPUT_FILE, 'w', encoding='utf-8') as fout:
        
        lines = fin.readlines()
        print(f"🚀 开始计算基线指标 ({len(lines)} 条)...")
        
        success_count = 0
        for i, line in tqdm(enumerate(lines), total=len(lines)):
            if not line.strip(): continue
            item = json.loads(line)
            text = item.get(ANSWER_FIELD, "")
            
            # 如果已有数据，跳过计算（断点续传）
            if 'predictive_entropy' in item and item['predictive_entropy'] is not None:
                fout.write(json.dumps(item, ensure_ascii=False) + '\n')
                success_count += 1
                continue

            if not text:
                fout.write(json.dumps(item, ensure_ascii=False) + '\n')
                continue

            try:
                entropy, layer_sim = compute_baselines(model, tokenizer, text)
                item['predictive_entropy'] = entropy
                item['layer_similarity'] = layer_sim
                success_count += 1
            except RuntimeError as e:
                if "out of memory" in str(e):
                    print(f"⚠️ 第 {i} 条 OOM (跳过): {str(e)[:50]}...")
                    torch.cuda.empty_cache()
                    item['predictive_entropy'] = None
                    item['layer_similarity'] = None
                else:
                    print(f"⚠️ 第 {i} 条错误: {e}")
                    item['predictive_entropy'] = None
                    item['layer_similarity'] = None
            except Exception as e:
                print(f"⚠️ 未知错误: {e}")

            fout.write(json.dumps(item, ensure_ascii=False) + '\n')
            
    print(f"✅ 完成！有效计算 {success_count} 条。结果已保存至 {OUTPUT_FILE}")

if __name__ == "__main__":
    main()