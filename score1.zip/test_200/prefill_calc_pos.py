import os
import json
import torch
import numpy as np
import argparse
from tqdm import tqdm
from transformers import AutoModelForCausalLM, AutoTokenizer
import torch.nn.functional as F

def calculate_dynamics_positional(hidden_states):
    """
    计算两套动力学指标（位置夹角版）：
    1. Macro (angle1, diff norms1): 先对层取平均 -> 计算 Diff Norm 和 Positional Angle
    2. Micro (angle2, diff norms2): 先计算每层的 Diff Norm 和 Positional Angle -> 对层取平均
    """
    # hidden_states: tuple (Batch, Seq, Hidden)
    # 跳过 embedding 层 (index 0)
    layers_data = hidden_states[1:] 
    
    # 堆叠: [Layers, Seq, Hidden]
    # 转到 CPU 防止显存溢出，转为 float32 保证计算精度
    stack = torch.stack([h[0].float().cpu() for h in layers_data])
    
    num_layers, seq_len, hidden_dim = stack.shape
    
    # 至少需要2个token才能计算相邻关系
    if seq_len < 2:
        return [], [], [], []

    # ================= Group 1: Macro (先平均层，再算指标) =================
    # 1. 对层取平均 -> [Seq, Hidden]
    macro_states = stack.mean(dim=0)
    
    # 2. Diff Norms 1 (计算相邻状态的距离)
    # Diff = h_t - h_{t-1}
    macro_diffs = macro_states[1:] - macro_states[:-1]
    diff_norms1 = torch.norm(macro_diffs, p=2, dim=-1) # [Seq-1]
    
    # 3. Angle 1 (Positional: 计算相邻状态向量的夹角)
    # Angle between h_t and h_{t-1}
    h_curr = macro_states[1:]   # t (从第2个token开始)
    h_prev = macro_states[:-1]  # t-1 (从第1个token开始)
    
    # Cosine Similarity
    cos_sim_macro = F.cosine_similarity(h_curr, h_prev, dim=-1, eps=1e-8)
    # Clamp to prevent NaN in acos
    cos_sim_macro = torch.clamp(cos_sim_macro, -1.0, 1.0)
    angle1 = torch.acos(cos_sim_macro) * (180.0 / np.pi) # [Seq-1]

    # ================= Group 2: Micro (先算每层指标，再平均层) =================
    # 1. Diff Norms 2
    # Layer Diffs = h_t^{(l)} - h_{t-1}^{(l)}
    layer_diffs = stack[:, 1:, :] - stack[:, :-1, :]
    layer_norms = torch.norm(layer_diffs, p=2, dim=-1) # [Layers, Seq-1]
    diff_norms2 = layer_norms.mean(dim=0)              # [Seq-1]
    
    # 2. Angle 2 (Positional: 每层计算状态夹角)
    h_curr_layer = stack[:, 1:, :]
    h_prev_layer = stack[:, :-1, :]
    
    # 计算每一层的 Cosine Similarity
    # F.cosine_similarity 支持多维，dim=-1 表示沿 hidden_dim 计算
    cos_sim_layer = F.cosine_similarity(h_curr_layer, h_prev_layer, dim=-1, eps=1e-8)
    cos_sim_layer = torch.clamp(cos_sim_layer, -1.0, 1.0)
    
    layer_angles = torch.acos(cos_sim_layer) * (180.0 / np.pi) # [Layers, Seq-1]
    angle2 = layer_angles.mean(dim=0)                          # [Seq-1]

    return angle1.tolist(), diff_norms1.tolist(), angle2.tolist(), diff_norms2.tolist()

def main():
    parser = argparse.ArgumentParser(description="Calculate Latent Dynamics (Positional Angle)")
    parser.add_argument("--input_file", type=str, required=True, help="Input .jsonl file")
    parser.add_argument("--output_file", type=str, required=True, help="Output .jsonl file")
    parser.add_argument("--model_path", type=str, 
                        default="/WORK/PUBLIC/dongyinp_work/lingp/models/Qwen3-4B-Thinking-2507")
    args = parser.parse_args()

    print(f"Loading model: {args.model_path}")
    try:
        tokenizer = AutoTokenizer.from_pretrained(args.model_path, trust_remote_code=True)
        model = AutoModelForCausalLM.from_pretrained(
            args.model_path, 
            device_map="auto", 
            torch_dtype=torch.bfloat16, 
            trust_remote_code=True,
            attn_implementation="sdpa"
        )
        model.eval()
    except Exception as e:
        print(f"Model load error: {e}")
        return

    # 检查输入文件
    if not os.path.exists(args.input_file):
        print(f"Error: Input file '{args.input_file}' not found.")
        return

    results = []
    
    # 读取所有行以显示进度条
    with open(args.input_file, 'r') as f:
        lines = f.readlines()
        
    print(f"Processing {len(lines)} samples...")

    for line in tqdm(lines):
        if not line.strip(): continue
        try:
            item = json.loads(line)
        except json.JSONDecodeError:
            continue
            
        pred_text = item.get("response", "") or item.get("pred", "")
        if not pred_text:
            # 保持空记录占位
            results.append({
                "is_correct": item.get("is_correct"), 
                "pred": "",
                "angle1": [], "diff norms1": [], "angle2": [], "diff norms2": []
            })
            continue

        # Tokenize
        inputs = tokenizer(pred_text, return_tensors="pt", add_special_tokens=False)
        inputs = {k: v.to(model.device) for k, v in inputs.items()}
        
        with torch.no_grad():
            outputs = model(**inputs, output_hidden_states=True)
        
        # 计算指标 (使用新的位置夹角函数)
        a1, n1, a2, n2 = calculate_dynamics_positional(outputs.hidden_states)
        
        out_item = {
            "is_correct": item.get("is_correct"),
            "pred": pred_text,
            "angle1": a1,
            "diff norms1": n1,
            "angle2": a2,
            "diff norms2": n2
        }
        results.append(out_item)
        
        del outputs
        torch.cuda.empty_cache()

    print(f"Saving results to {args.output_file}...")
    with open(args.output_file, 'w') as f:
        for res in results:
            f.write(json.dumps(res) + "\n")
    print("Done.")

if __name__ == "__main__":
    main()