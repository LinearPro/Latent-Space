import json
import numpy as np
import os

def main():
    # 配置输入输出文件名
    input_file = "aime2024_2025_score.jsonl"
    output_file = "avr_tf_pos.jsonl"
    
    if not os.path.exists(input_file):
        print(f"错误: 找不到输入文件 '{input_file}'")
        return
    
    print(f"正在处理: {input_file} -> {output_file} ...")
    
    count = 0
    with open(input_file, 'r', encoding='utf-8') as f_in, \
         open(output_file, 'w', encoding='utf-8') as f_out:
        
        for line in f_in:
            line = line.strip()
            if not line:
                continue
            
            try:
                data = json.loads(line)
            except json.JSONDecodeError:
                print(f"跳过无效的 JSON 行: {line[:50]}...")
                continue
            
            # 提取列表数据
            # 注意：如果您的上一步代码生成的键名有所不同，请在这里对应修改
            angle1_seq = data.get("angle1", [])
            diff_norms1_seq = data.get("diff norms1", [])
            angle2_seq = data.get("angle2", [])
            diff_norms2_seq = data.get("diff norms2", [])
            
            # 定义计算平均值的函数（处理空列表和 numpy 类型）
            def safe_mean(seq):
                if seq and len(seq) > 0:
                    return float(np.mean(seq))
                return 0.0 # 或者 None，视需求而定，这里设为0.0方便后续计算
            
            # 构建新的对象
            out_item = {
                "is_correct": data.get("is_correct"),
                "angle1": safe_mean(angle1_seq),
                "diff norms1": safe_mean(diff_norms1_seq),
                "angle2": safe_mean(angle2_seq),
                "diff norms2": safe_mean(diff_norms2_seq)
            }
            
            # 写入文件
            f_out.write(json.dumps(out_item) + "\n")
            count += 1
            
    print(f"处理完成！共生成 {count} 条数据，已保存至 {output_file}")

if __name__ == "__main__":
    main()