import json
import os

def extract_boxed_content(text):
    """
    从文本中提取 \boxed{...} 的内容。
    逻辑：
    1. 寻找文本中 '最后一个' \boxed{ 的位置（通常最后的才是最终答案）。
    2. 使用堆栈/计数器方法解析嵌套的大括号，确保提取完整且准确。
    """
    if not text or not isinstance(text, str):
        return None

    # 关键步骤：使用 rfind 找最后一个 \boxed{，这在 CoT（思维链）中很关键
    # 如果你想找第一个，可以改成 text.find("\\boxed{")
    target = "\\boxed{"
    start_index = text.rfind(target)
    
    if start_index == -1:
        return None
    
    # 内容开始的位置（跳过 \boxed{ 这7个字符）
    content_start = start_index + len(target)
    
    balance = 1
    current_index = content_start
    
    while current_index < len(text):
        char = text[current_index]
        
        if char == '{':
            balance += 1
        elif char == '}':
            balance -= 1
            
        if balance == 0:
            return text[content_start:current_index]
        
        current_index += 1
        
    return None

def process_file(input_path, output_path):
    print(f"开始处理文件: {input_path}")
    
    success_count = 0
    total_count = 0
    
    # 打开输入和输出文件
    # ensure_ascii=False 保证中文字符能正常显示，而不是 \uXXXX
    with open(input_path, 'r', encoding='utf-8') as f_in, \
         open(output_path, 'w', encoding='utf-8') as f_out:
        
        for line_num, line in enumerate(f_in, 1):
            line = line.strip()
            if not line:
                continue
            
            total_count += 1
            try:
                data = json.loads(line)
                
                # 获取 pred 字段，如果不存在则为空字符串
                pred_text = data.get("pred", "")
                
                # 执行提取
                answer = extract_boxed_content(pred_text)
                
                # 将提取结果放入新的字段，例如 'extracted_answer'
                data['extracted_answer'] = answer
                
                # 简单的统计
                if answer:
                    success_count += 1
                
                # 写入新文件
                f_out.write(json.dumps(data, ensure_ascii=False) + '\n')
                
            except json.JSONDecodeError:
                print(f"警告: 第 {line_num} 行不是有效的 JSON 数据，已跳过。")
            except Exception as e:
                print(f"错误: 处理第 {line_num} 行时发生未知错误: {e}")

    print("-" * 30)
    print(f"处理完成！")
    print(f"总行数: {total_count}")
    print(f"成功提取数: {success_count}")
    print(f"提取率: {success_count/total_count:.2%}" if total_count > 0 else "N/A")
    print(f"结果已保存至: {output_path}")

# --- 主程序执行入口 ---
if __name__ == "__main__":
    # 定义输入和输出文件名
    input_filename = "merged_origin_aime2425.jsonl"
    output_filename = "merged_boxed.jsonl"
    
    # 检查输入文件是否存在
    if not os.path.exists(input_filename):
        # 为了演示，如果没有文件，先创建一个假的测试文件
        print(f"未找到 {input_filename}，正在生成测试数据...")
        with open(input_filename, 'w', encoding='utf-8') as f:
            test_data = [
                {"question_id": 1, "pred": "The logic implies $x=5$. So \\boxed{5}."},
                {"question_id": 2, "pred": "Result is \\boxed{\\dfrac{365}{9}} finally."},
                {"question_id": 3, "pred": "I am not sure about the answer."},
                {"question_id": 4, "pred": "Step 1: \\boxed{3}, Step 2: \\boxed{4}. Final: \\boxed{7}"} 
            ]
            for item in test_data:
                f.write(json.dumps(item) + '\n')
    
    # 运行处理函数
    process_file(input_filename, output_filename)