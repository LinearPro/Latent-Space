import json
import torch
import os
from tqdm import tqdm
from transformers import AutoModelForCausalLM, AutoTokenizer

# ================= 配置区域 =================
# 您的本地模型路径
MODEL_PATH = "/WORK/PUBLIC/dongyinp_work/lingp/models/Qwen3-4B-Thinking-2507"

# 输入和输出文件
INPUT_FILE = "aime2024_2025_score.jsonl"
OUTPUT_FILE = "aime2024_2025_with_logprobs.jsonl"

# 包含 CoT 回答的字段名
ANSWER_FIELD = "pred"
# ===========================================

def load_model(model_path):
    print(f"🔄 正在加载模型: {model_path} ...")
    try:
        tokenizer = AutoTokenizer.from_pretrained(model_path, trust_remote_code=True)
        model = AutoModelForCausalLM.from_pretrained(
            model_path, 
            device_map="auto", 
            torch_dtype=torch.bfloat16, 
            trust_remote_code=True
        )
        model.eval()
        print("✅ 模型加载成功")
        return tokenizer, model
    except Exception as e:
        print(f"❌ 模型加载失败: {e}")
        exit(1)

def compute_logprobs(model, tokenizer, text):
    """
    计算文本的自回归 Log Probabilities
    """
    # 1. Tokenize
    # add_special_tokens=True 会在开头加 BOS (Begin of Sentence)
    inputs = tokenizer(text, return_tensors="pt", add_special_tokens=True).to(model.device)
    input_ids = inputs.input_ids

    # 2. Forward Pass
    with torch.no_grad():
        outputs = model(input_ids)
        logits = outputs.logits

    # 3. Shift Logits & Labels
    # shift_logits[i] 预测的是 input_ids[i+1]
    shift_logits = logits[..., :-1, :].contiguous()
    shift_labels = input_ids[..., 1:].contiguous()
    
    # 4. 计算 Log Softmax
    log_probs_all = torch.nn.functional.log_softmax(shift_logits, dim=-1)
    
    # 5. 提取真实 Token 对应的 Log Prob
    # gather 的作用是：在 vocab 维度上，只取 shift_labels 对应的那个概率
    token_log_probs = torch.gather(log_probs_all, 2, shift_labels.unsqueeze(2)).squeeze(2)
    
    # 结果转为 list
    # token_log_probs[0] 对应 batch 中的第一条（也是唯一一条）
    return token_log_probs[0].tolist()

def main():
    tokenizer, model = load_model(MODEL_PATH)
    
    if os.path.exists(OUTPUT_FILE):
        print(f"⚠️ 警告: 输出文件 {OUTPUT_FILE} 已存在，将被覆盖。")

    with open(INPUT_FILE, 'r', encoding='utf-8') as fin, \
         open(OUTPUT_FILE, 'w', encoding='utf-8') as fout:
        
        lines = fin.readlines()
        print(f"🚀 开始处理 {len(lines)} 条数据...")
        
        success_count = 0
        for i, line in tqdm(enumerate(lines), total=len(lines)):
            if not line.strip(): continue
            item = json.loads(line)
            
            # 获取 CoT 内容
            text = item.get(ANSWER_FIELD, "")
            
            if not text:
                item['log_probs'] = []
                fout.write(json.dumps(item, ensure_ascii=False) + '\n')
                continue

            try:
                # 计算 Log Probs
                log_probs = compute_logprobs(model, tokenizer, text)
                item['log_probs'] = log_probs
                
                # 计算 PPL (Perplexity)
                if log_probs:
                    avg_lp = sum(log_probs) / len(log_probs)
                    # PPL = exp(-avg_log_prob)
                    item['perplexity'] = float(torch.exp(torch.tensor(-avg_lp)))
                    success_count += 1
                else:
                    item['perplexity'] = None

            except RuntimeError as e:
                if "OOM" in str(e) or "out of memory" in str(e).lower():
                    print(f"❌ 显存不足 (OOM) 跳过第 {i} 条 (长度可能过长)")
                    torch.cuda.empty_cache()
                else:
                    print(f"❌ 未知错误 (ID {i}): {e}")
                item['log_probs'] = []

            # 写入结果
            fout.write(json.dumps(item, ensure_ascii=False) + '\n')

    print(f"🎉 处理完成！成功计算 {success_count} 条。结果保存在: {OUTPUT_FILE}")

if __name__ == "__main__":
    main()