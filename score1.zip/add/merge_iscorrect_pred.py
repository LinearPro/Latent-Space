import json
import os

def merge_datasets(eval_result_path, pred_extract_path, output_path):
    """
    提取 evaluation_results_cleaned.jsonl 中的 is_correct
    提取 merged_predictions_extracted.jsonl 中的 pred
    合并保存为新的 JSONL
    """
    
    # 1. 检查文件是否存在
    if not os.path.exists(eval_result_path):
        print(f"错误: 找不到文件 {eval_result_path}")
        return
    if not os.path.exists(pred_extract_path):
        print(f"错误: 找不到文件 {pred_extract_path}")
        return

    merged_data = []

    try:
        print(f"正在合并数据...")
        with open(eval_result_path, 'r', encoding='utf-8') as f_eval, \
             open(pred_extract_path, 'r', encoding='utf-8') as f_pred:
            
            # 使用 zip 同时遍历两个文件，确保行号对应
            for line_idx, (line_eval, line_pred_src) in enumerate(zip(f_eval, f_pred)):
                try:
                    data_eval = json.loads(line_eval)
                    data_pred_src = json.loads(line_pred_src)
                    
                    # 提取所需字段
                    # is_correct 来自判题结果文件
                    is_correct = data_eval.get("is_correct", False)
                    
                    # pred (通常包含完整推理过程) 来自原始预测文件
                    pred_content = data_pred_src.get("pred", "")
                    
                    # 也可以保留 extracted_answer 和 response 以便人工检查，如果不需要可注释掉
                    extracted_ans = data_eval.get("extracted_answer", "")
                    reference_resp = data_eval.get("response", "")

                    # 构建新的数据条目
                    entry = {
                        "is_correct": is_correct,
                        "pred": pred_content,
                    }
                    merged_data.append(entry)
                    
                except json.JSONDecodeError:
                    print(f"第 {line_idx+1} 行 JSON 解析失败，跳过。")

        # 2. 写入新文件
        if merged_data:
            with open(output_path, 'w', encoding='utf-8') as f_out:
                for entry in merged_data:
                    f_out.write(json.dumps(entry, ensure_ascii=False) + '\n')
            
            print(f"合并完成！文件已保存至: {output_path}")
            print(f"共合并 {len(merged_data)} 条数据。")
            
            # 简单统计
            correct_count = sum(1 for d in merged_data if d['is_correct'])
            print(f"其中正确数量: {correct_count} (准确率: {correct_count/len(merged_data)*100:.2f}%)")
        else:
            print("没有合并到有效数据。")

    except Exception as e:
        print(f"处理过程中发生错误: {e}")

if __name__ == "__main__":
    # 输入文件
    file_eval_results = 'evaluation_26.jsonl'       # 包含 is_correct
    file_predictions = 'merged_origin_aime2425.jsonl'      # 包含 pred
    
    # 输出文件
    file_output = 'final_training_data.jsonl'
    
    merge_datasets(file_eval_results, file_predictions, file_output)