import json
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import os

def analyze_kinematic_fingerprint_dynamics(input_file="metrics.jsonl", window_size=5):
    print("🔬 启动终极动力学分析：引入微观曲折度 (Tortuosity) 剥离重叠拓扑...")
    
    if not os.path.exists(input_file):
        print(f"❌ 文件 {input_file} 不存在。")
        return

    # 数据容器
    C_msd_trajectories, I_msd_trajectories = [], []
    C_lle, I_lle = [], []
    
    # === 新增：动力学指纹特征容器 ===
    C_kinematics = []
    I_kinematics = []
    
    num_steps = 100 
    
    with open(input_file, 'r', encoding='utf-8') as f:
        for line in f:
            if not line.strip(): continue
            try:
                item = json.loads(line)
                d1 = item.get('diff norm1', item.get('diff norms1'))
                d2 = item.get('diff norm2', item.get('diff norms2'))
                a1 = item.get('angle1')
                a2 = item.get('angle2')
                
                if not (d1 and d2 and a1 and a2): continue
                
                # 1. 提取微观速度场
                fric_vel = np.array(d2) - np.array(d1)
                incoh_vel = np.array(a2) - np.array(a1)
                
                total_len = len(fric_vel)
                if total_len < 15: continue 
                
                is_correct = item.get('is_correct', False)

                # ================= 核心重构 1：微观曲折度 (Tortuosity) 计算 =================
                # 1a. 计算总路径长度 L (微观步长的标量和)
                step_magnitudes = np.sqrt(fric_vel**2 + incoh_vel**2)
                path_length = np.sum(step_magnitudes)
                
                # 1b. 计算宏观净位移 D (终点距离起点的直线向量模长)
                net_fric = np.sum(fric_vel)
                net_incoh = np.sum(incoh_vel)
                net_displacement = np.sqrt(net_fric**2 + net_incoh**2) + 1e-8 # 加 epsilon 防止除零
                
                # 1c. 计算曲折度 T = L / D
                tortuosity = path_length / net_displacement
                
                if is_correct:
                    C_kinematics.append([net_displacement, tortuosity])
                else:
                    I_kinematics.append([net_displacement, tortuosity])
                # =========================================================================

                # 2. 积分还原绝对位置 (用于 MSD 和 LLE)
                fric_pos = np.cumsum(fric_vel)
                incoh_pos = np.cumsum(incoh_vel)
                
                orig_time = np.linspace(0, 1, total_len)
                norm_time = np.linspace(0, 1, num_steps)
                
                f_interp = np.interp(norm_time, orig_time, fric_pos)
                i_interp = np.interp(norm_time, orig_time, incoh_pos)
                
                # 3. 计算 MSD (用于图2)
                sd_t = (f_interp - f_interp[0])**2 + (i_interp - i_interp[0])**2
                if is_correct: C_msd_trajectories.append(sd_t)
                else: I_msd_trajectories.append(sd_t)

                # 4. 计算绝对宏观 LLE (用于图3)
                tail_start_idx = int(total_len * 0.7)
                tail_fric = fric_pos[tail_start_idx:]
                tail_incoh = incoh_pos[tail_start_idx:]
                
                abs_end_fric = np.mean(tail_fric[-3:]) 
                abs_end_incoh = np.mean(tail_incoh[-3:])
                
                eps = 1e-8
                distances = np.sqrt((tail_fric - abs_end_fric)**2 + (tail_incoh - abs_end_incoh)**2) + eps
                
                log_ratios = np.log(distances[1:] / distances[:-1])
                log_ratios = log_ratios[~np.isnan(log_ratios) & ~np.isinf(log_ratios)]
                
                if len(log_ratios) > 0:
                    local_lyapunov = np.mean(log_ratios)
                    if is_correct: C_lle.append(local_lyapunov)
                    else: I_lle.append(local_lyapunov)
                            
            except Exception as e: 
                continue

    # ================= 绘图 =================
    sns.set_style("whitegrid")
    fig, (ax1, ax2, ax3) = plt.subplots(1, 3, figsize=(24, 7))
    fig.suptitle("Kinematic Fingerprints of Hallucination: Strict Phase Separation & Macroscopic Divergence", fontsize=18, fontweight='bold', y=1.02)

    # --- 图 1：动力学指纹相空间 (微观曲折度 vs 宏观位移) ---
    ax1.set_title("Kinematic Phase Space: Strict Separation", fontsize=14)
    ax1.set_xlabel(r"Macroscopic Net Displacement ($\mathcal{D}$)", fontsize=12)
    ax1.set_ylabel(r"Microscopic Friction / Tortuosity ($\mathcal{T} = L/\mathcal{D}$)", fontsize=12)

    C_k_arr = np.array(C_kinematics)
    I_k_arr = np.array(I_kinematics)

    if len(C_k_arr) > 0:
        sns.kdeplot(x=C_k_arr[:, 0], y=C_k_arr[:, 1], cmap="Blues", fill=True, alpha=0.7, levels=10, ax=ax1, label='Correct (High Friction/Correction)', zorder=2)
    if len(I_k_arr) > 0:
        sns.kdeplot(x=I_k_arr[:, 0], y=I_k_arr[:, 1], cmap="Reds", fill=True, alpha=0.8, levels=10, ax=ax1, label='Incorrect (Slippery Slope Escape)', zorder=1)
    
    # 动态调整视图域以去除极端游离点的视觉压缩
    if len(C_k_arr) > 0 and len(I_k_arr) > 0:
        max_d = np.percentile(np.concatenate([C_k_arr[:, 0], I_k_arr[:, 0]]), 98)
        max_t = np.percentile(np.concatenate([C_k_arr[:, 1], I_k_arr[:, 1]]), 98)
        ax1.set_xlim(left=0, right=max_d * 1.1)
        ax1.set_ylim(bottom=1.0, top=max_t * 1.1)

    handles, labels = ax1.get_legend_handles_labels()
    if handles: ax1.legend(handles, labels, loc='upper right')

    # --- 图 2：绝对均方位移 (MSD) ---
    C_msd_matrix, I_msd_matrix = np.array(C_msd_trajectories), np.array(I_msd_trajectories)
    time_axis = np.linspace(0, 100, num_steps)

    ax2.set_title("Absolute Mean Squared Displacement (MSD)", fontsize=14)
    ax2.set_xlabel("Generation Progress (%)", fontsize=12)
    ax2.set_ylabel(r"Cumulative Space Divergence $\langle ||\int V dt||^2 \rangle$", fontsize=12)

    if len(I_msd_matrix) > 0:
        I_msd_mean = np.mean(I_msd_matrix, axis=0)
        I_msd_sem = np.std(I_msd_matrix, axis=0) / np.sqrt(len(I_msd_matrix))
        ax2.plot(time_axis, I_msd_mean, color='#D62728', linewidth=3, label='Incorrect Path (Unbounded Escape)')
        ax2.fill_between(time_axis, I_msd_mean - I_msd_sem, I_msd_mean + I_msd_sem, color='#D62728', alpha=0.15)

    if len(C_msd_matrix) > 0:
        C_msd_mean = np.mean(C_msd_matrix, axis=0)
        C_msd_sem = np.std(C_msd_matrix, axis=0) / np.sqrt(len(C_msd_matrix))
        ax2.plot(time_axis, C_msd_mean, color='#1F77B4', linewidth=3, label='Correct Path (Bounded Expansion)')
        ax2.fill_between(time_axis, C_msd_mean - C_msd_sem, C_msd_mean + C_msd_sem, color='#1F77B4', alpha=0.2)
        
        plateau_height = np.mean(C_msd_mean[-int(num_steps*0.3):])
        ax2.axhline(y=plateau_height, color='navy', linestyle='--', linewidth=2, alpha=0.6, label='Confinement Limit')

    ax2.set_xlim(0, 100)
    ax2.set_ylim(bottom=0)
    ax2.legend(loc='upper left')

    # --- 图 3：绝对局部李雅普诺夫指数 (Absolute LLE) ---
    ax3.set_title(r"Absolute Local Lyapunov Exponent $\lambda_{abs}$ (Tail 70-100%)", fontsize=14)
    ax3.set_ylabel(r"Macroscopic Divergence Rate ($\lambda_{abs}$)", fontsize=12)
    
    def filter_outliers(data):
        if len(data) == 0: return []
        p2, p98 = np.percentile(data, 2), np.percentile(data, 98)
        return [x for x in data if p2 <= x <= p98]
    
    clean_C_lle = filter_outliers(C_lle)
    clean_I_lle = filter_outliers(I_lle)

    lle_data = pd.DataFrame({
        'LLE': clean_C_lle + clean_I_lle,
        'Trajectory Type': ['Correct (Deep Restoring Force)'] * len(clean_C_lle) + ['Incorrect (Parasitic Attractor)'] * len(clean_I_lle)
    })
    
    if not lle_data.empty:
        sns.violinplot(x='Trajectory Type', y='LLE', data=lle_data, 
                       palette={'Correct (Deep Restoring Force)': '#6BAED6', 'Incorrect (Parasitic Attractor)': '#FB6A4A'}, 
                       inner="quartile", ax=ax3, alpha=0.8)
        
        ax3.axhline(0, color='black', linestyle='--', linewidth=2, label=r'Critical Stability Threshold ($\lambda=0$)')
        
        ymin, ymax = ax3.get_ylim()
        ax3.text(-0.25, ymax * 0.85, 'Strong Convergence\n(Tethered to Main Logic)', 
                 transform=ax3.get_xaxis_transform(), ha='center', color='#08519C', fontsize=11, fontweight='bold')
        ax3.text(1.25, ymax * 0.85, 'False Convergence\n(Trapped in Hallucination)', 
                 transform=ax3.get_xaxis_transform(), ha='center', color='#A50F15', fontsize=11, fontweight='bold')
        ax3.legend(loc='lower right')

    plt.tight_layout(rect=[0, 0.03, 1, 0.95])
    output_filename = "Kinematic_Fingerprint_Separation.png"
    plt.savefig(output_filename, dpi=300)
    print(f"\n🖼️ 分析完成！动力学指纹分离图表已保存为 {output_filename}")

if __name__ == "__main__":
    analyze_kinematic_fingerprint_dynamics("metrics.jsonl")