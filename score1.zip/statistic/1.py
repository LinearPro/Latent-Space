import json
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import os

def analyze_eigenvalue_evolution(input_file="metrics.jsonl", num_steps=100):
    print("🔬 启动相空间截面分析：计算协方差矩阵本征值演化...")
    
    if not os.path.exists(input_file):
        print(f"❌ 文件 {input_file} 不存在。")
        return

    C_trajectories = []
    I_trajectories = []
    
    with open(input_file, 'r', encoding='utf-8') as f:
        for line in f:
            if not line.strip(): continue
            try:
                item = json.loads(line)
                d1 = item.get('diff norm1', item.get('diff norms1'))
                d2 = item.get('diff norm2', item.get('diff norms2'))
                a1 = item.get('angle1')
                a2 = item.get('angle2')
                
                if not (d1 and d2 and a1 and a2): continue
                
                # 1. 提取速度场并积分还原为绝对位移
                fric_vel = np.array(d2) - np.array(d1)
                incoh_vel = np.array(a2) - np.array(a1)
                
                if len(fric_vel) < 10: continue
                
                fric_pos = np.cumsum(fric_vel)
                incoh_pos = np.cumsum(incoh_vel)
                
                # 2. 长度归一化插值
                orig_time = np.linspace(0, 1, len(fric_pos))
                norm_time = np.linspace(0, 1, num_steps)
                
                f_interp = np.interp(norm_time, orig_time, fric_pos)
                i_interp = np.interp(norm_time, orig_time, incoh_pos)
                
                # 组合为 2D 轨迹点
                traj_2d = np.column_stack((f_interp, i_interp))
                
                is_correct = item.get('is_correct', False)
                if is_correct:
                    C_trajectories.append(traj_2d)
                else:
                    I_trajectories.append(traj_2d)
                    
            except Exception as e:
                continue

    # 转化为 Tensor 格式 (N_trajectories, num_steps, 2)
    C_tensor = np.array(C_trajectories)
    I_tensor = np.array(I_trajectories)
    
    if len(C_tensor) < 2 or len(I_tensor) < 2:
        print("❌ 解析到的有效轨迹数量不足以计算协方差 (至少需要2条)。")
        return

    print(f"✅ 数据加载完毕。正确轨迹: {len(C_tensor)} 条, 错误轨迹: {len(I_tensor)} 条。")

    # ================= 核心计算：逐时间步计算本征值 =================
    def calc_eigenvalues(tensor):
        lambda1_list, lambda2_list = [], []
        for t in range(num_steps):
            # 获取所有轨迹在时刻 t 的 (X, Y) 坐标散点群
            points = tensor[:, t, :]
            # 计算 2x2 协方差矩阵 (rowvar=False 表示每列是一个变量)
            cov_matrix = np.cov(points, rowvar=False)
            # 计算特征值
            eigvals = np.linalg.eigvals(cov_matrix)
            # 提取实部并降序排列
            eigvals = np.sort(np.real(eigvals))[::-1]
            
            # 确保非负 (数值计算可能产生微小负数)
            l1 = max(0, eigvals[0])
            l2 = max(0, eigvals[1] if len(eigvals) > 1 else 0)
            
            lambda1_list.append(l1)
            lambda2_list.append(l2)
        return np.array(lambda1_list), np.array(lambda2_list)

    C_L1, C_L2 = calc_eigenvalues(C_tensor)
    I_L1, I_L2 = calc_eigenvalues(I_tensor)
    
    # 相空间截面积近似正比于两个特征值的乘积 (椭圆面积)
    C_Area = C_L1 * C_L2
    I_Area = I_L1 * I_L2
    
    time_axis = np.linspace(0, 100, num_steps)

    # ================= 绘图 =================
    sns.set_style("whitegrid")
    fig, (ax1, ax2, ax3) = plt.subplots(1, 3, figsize=(22, 6))
    fig.suptitle("Eigenvalue Evolution of Ensemble Covariance Matrix\nProbing Transverse Confinement vs. Dimensional Explosion", fontsize=16, fontweight='bold', y=1.02)

    # 图 1：主特征值 λ1 (纵向推进散布)
    ax1.set_title(r"Primary Variance ($\lambda_1$): Longitudinal Expansion", fontsize=14)
    ax1.plot(time_axis, I_L1, color='#D62728', linewidth=3, label='Incorrect Path')
    ax1.plot(time_axis, C_L1, color='#1F77B4', linewidth=3, label='Correct Path')
    ax1.set_xlabel("Generation Progress (%)", fontsize=12)
    ax1.set_ylabel(r"Eigenvalue $\lambda_1$", fontsize=12)
    ax1.legend(loc='upper left')

    # 图 2：次特征值 λ2 (横向游离散布) - 核心观测点！
    ax2.set_title(r"Secondary Variance ($\lambda_2$): Transverse Confinement", fontsize=14, color='darkred')
    ax2.plot(time_axis, I_L2, color='#D62728', linewidth=3, label='Incorrect Path (Unbound Escape)')
    ax2.plot(time_axis, C_L2, color='#1F77B4', linewidth=3, label='Correct Path (Logical Tube Confinement)')
    
    # 标注约束极限
    plateau_height = np.mean(C_L2[-int(num_steps*0.3):]) if len(C_L2) > 0 else 0
    ax2.axhline(y=plateau_height, color='navy', linestyle=':', linewidth=2, alpha=0.7, label='Confinement Radius')
    
    ax2.set_xlabel("Generation Progress (%)", fontsize=12)
    ax2.set_ylabel(r"Eigenvalue $\lambda_2$", fontsize=12)
    ax2.legend(loc='upper left')

    # 图 3：相空间截面积 (本征值乘积)
    ax3.set_title(r"Phase Space Volume Growth ($\lambda_1 \times \lambda_2$)", fontsize=14)
    ax3.plot(time_axis, I_Area, color='#D62728', linewidth=3, linestyle='-', label='Incorrect Path (Volume Explosion)')
    ax3.plot(time_axis, C_Area, color='#1F77B4', linewidth=3, linestyle='-', label='Correct Path (Volume Bounded)')
    
    # 对数尺度展示更容易看到爆炸性差异
    ax3.set_yscale('log')
    ax3.set_xlabel("Generation Progress (%)", fontsize=12)
    ax3.set_ylabel(r"Cross-section Area (Log Scale)", fontsize=12)
    ax3.legend(loc='upper left')

    plt.tight_layout()
    output_filename = "Eigenvalue_Evolution_Analysis.png"
    plt.savefig(output_filename, dpi=300)
    print(f"\n🖼️ 协方差本征值分析完毕！动态相变图表已保存为 {output_filename}")
    
    # 终端输出核心结论
    print("\n📊 终点态 (t=100%) 横向约束力 (λ2) 数据比对:")
    print(f"✅ 正确推理终端横向散布 (λ2): {C_L2[-1]:.2f}")
    print(f"❌ 错误推理终端横向散布 (λ2): {I_L2[-1]:.2f}")
    ratio = I_L2[-1] / C_L2[-1] if C_L2[-1] > 0 else float('inf')
    print(f"💡 结论: 错误推理在垂直于主逻辑的冗余维度上，其散布程度是正确推理的 {ratio:.1f} 倍！这构成了'维度破缺'的硬核物理证据。")

if __name__ == "__main__":
    analyze_eigenvalue_evolution("metrics.jsonl")