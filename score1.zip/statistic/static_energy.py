import json
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from scipy import stats
import argparse
import os
import pandas as pd

def analyze_energy_statistics(input_file):
    print(f"📊 正在分析能量指标统计: {input_file} ...")
    
    if not os.path.exists(input_file):
        print(f"❌ 错误: 文件 {input_file} 不存在。")
        return

    # 存储每条样本的平均能量
    data_records = []

    with open(input_file, 'r', encoding='utf-8') as f:
        for line in f:
            if not line.strip(): continue
            try:
                item = json.loads(line)
                
                is_correct = item.get("is_correct")
                if is_correct is None: continue
                
                ek_seq = item.get("kinetic_energy", [])
                u_seq = item.get("turbulent_energy", [])
                
                if not ek_seq or not u_seq: continue
                
                # 计算该样本的平均动能和平均湍流内能
                # 也可以考虑最大值、累积值等，这里先用平均值代表整体水平
                mean_ek = np.mean(ek_seq)
                mean_u = np.mean(u_seq)
                
                # 也可以计算由于思维链长度不同带来的总能量 (累积)
                # total_ek = np.sum(ek_seq)
                # total_u = np.sum(u_seq)
                
                data_records.append({
                    "is_correct": "Correct" if is_correct else "Incorrect",
                    "Mean_Kinetic_Energy": mean_ek,
                    "Mean_Turbulent_Energy": mean_u,
                    # "Total_Kinetic_Energy": total_ek,
                    # "Total_Turbulent_Energy": total_u,
                    "Length": len(ek_seq)
                })
                
            except Exception as e:
                continue

    if not data_records:
        print("❌ 没有找到有效数据。")
        return

    df = pd.DataFrame(data_records)
    
    # ================= 统计分析 =================
    print("\n" + "="*40)
    print("🔬 统计分析报告 (Statistical Summary)")
    print("="*40)
    
    # 分组统计
    summary = df.groupby("is_correct")[["Mean_Kinetic_Energy", "Mean_Turbulent_Energy"]].agg(['mean', 'std', 'count'])
    print(summary)
    
    # T检验
    correct_ek = df[df["is_correct"] == "Correct"]["Mean_Kinetic_Energy"]
    incorrect_ek = df[df["is_correct"] == "Incorrect"]["Mean_Kinetic_Energy"]
    
    correct_u = df[df["is_correct"] == "Correct"]["Mean_Turbulent_Energy"]
    incorrect_u = df[df["is_correct"] == "Incorrect"]["Mean_Turbulent_Energy"]
    
    print("\n🧪 独立样本 T 检验 (T-Test):")
    
    t_stat_ek, p_val_ek = stats.ttest_ind(correct_ek, incorrect_ek, equal_var=False)
    print(f"1. 动能 (Kinetic Energy):")
    print(f"   t-statistic = {t_stat_ek:.4f}, p-value = {p_val_ek:.4e}")
    print(f"   -> {'显著差异 (Significant)' if p_val_ek < 0.05 else '无显著差异 (Not Significant)'}")
    
    t_stat_u, p_val_u = stats.ttest_ind(correct_u, incorrect_u, equal_var=False)
    print(f"2. 湍流内能 (Turbulent Energy):")
    print(f"   t-statistic = {t_stat_u:.4f}, p-value = {p_val_u:.4e}")
    print(f"   -> {'显著差异 (Significant)' if p_val_u < 0.05 else '无显著差异 (Not Significant)'}")

    # ================= 可视化 =================
    sns.set_style("whitegrid")
    
    # 图 1: 箱线图对比
    fig, axes = plt.subplots(1, 2, figsize=(14, 6))
    
    sns.boxplot(x="is_correct", y="Mean_Kinetic_Energy", data=df, ax=axes[0], palette=["#1f77b4", "#d62728"])
    axes[0].set_title("Distribution of Kinetic Energy ($E_k$)", fontsize=14, fontweight='bold')
    axes[0].set_ylabel("Mean Kinetic Energy", fontsize=12)
    
    sns.boxplot(x="is_correct", y="Mean_Turbulent_Energy", data=df, ax=axes[1], palette=["#1f77b4", "#d62728"])
    axes[1].set_title("Distribution of Turbulent Energy ($U_{turb}$)", fontsize=14, fontweight='bold')
    axes[1].set_ylabel("Mean Turbulent Energy", fontsize=12)
    
    plt.tight_layout()
    plt.savefig("energy_statistics_boxplot.png", dpi=300)
    print(f"\n📊 箱线图已保存: energy_statistics_boxplot.png")
    
    # 图 2: 散点分布图 (动能 vs 内能)
    plt.figure(figsize=(10, 8))
    sns.scatterplot(data=df, x="Mean_Kinetic_Energy", y="Mean_Turbulent_Energy", hue="is_correct", 
                    style="is_correct", alpha=0.7, s=60, palette=["#1f77b4", "#d62728"])
    
    plt.title("Kinetic Energy vs. Turbulent Energy", fontsize=16, fontweight='bold')
    plt.xlabel("Mean Kinetic Energy ($E_k$)", fontsize=14)
    plt.ylabel("Mean Turbulent Energy ($U_{turb}$)", fontsize=14)
    plt.legend(title="Prediction", fontsize=12)
    
    plt.tight_layout()
    plt.savefig("energy_scatter_plot.png", dpi=300)
    print(f"📊 散点图已保存: energy_scatter_plot.png")

    # 图 3: 分布密度图 (KDE)
    fig, axes = plt.subplots(1, 2, figsize=(14, 6))
    
    sns.kdeplot(data=df, x="Mean_Kinetic_Energy", hue="is_correct", fill=True, ax=axes[0], palette=["#1f77b4", "#d62728"], alpha=0.4)
    axes[0].set_title("Density of Kinetic Energy", fontsize=14)
    
    sns.kdeplot(data=df, x="Mean_Turbulent_Energy", hue="is_correct", fill=True, ax=axes[1], palette=["#1f77b4", "#d62728"], alpha=0.4)
    axes[1].set_title("Density of Turbulent Energy", fontsize=14)
    
    plt.tight_layout()
    plt.savefig("energy_density_plot.png", dpi=300)
    print(f"📊 密度图已保存: energy_density_plot.png")

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Statistical Analysis of Energy Metrics")
    parser.add_argument("--input_file", type=str, default="metrics_energy.jsonl", help="Input energy.jsonl file")
    
    args = parser.parse_args()
    
    analyze_energy_statistics(args.input_file)