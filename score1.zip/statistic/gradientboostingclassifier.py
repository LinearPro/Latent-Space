import json
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.ensemble import GradientBoostingClassifier, RandomForestClassifier
from sklearn.metrics import classification_report, accuracy_score, confusion_matrix, roc_auc_score
from sklearn.preprocessing import StandardScaler
import argparse
import os

def extract_advanced_physics_features(item):
    """
    从原始物理序列中提取高级动力学特征
    """
    # 获取序列
    m = np.array(item['mass'])
    v = np.array(item['velocity'])
    ek = np.array(item['kinetic_energy'])
    u = np.array(item['internal_energy'])
    
    length = len(m)
    if length < 5: return None
    
    epsilon = 1e-6
    
    # === 1. 基础统计 (Global Stats) ===
    mean_mass = np.mean(m)
    mean_ek = np.mean(ek)
    mean_u = np.mean(u)
    
    # === 2. 能量效率特征 (Efficiency) ===
    # 瞬时效率序列
    efficiency_seq = ek / (ek + u + epsilon)
    mean_efficiency = np.mean(efficiency_seq)
    
    # 拉格朗日量 (Lagrangian L = T - V) -> 这里对应 Ek - U
    # 作用量 (Action S = integral L dt)
    lagrangian_seq = ek - u
    total_action = np.sum(lagrangian_seq) / length # 归一化作用量
    
    # === 3. 阶段特征 (Phase Dynamics) ===
    # 切分 Late Stage (最后 10%)
    idx_late = int(length * 0.90)
    if idx_late >= length: idx_late = length - 1
    
    late_mass = np.mean(m[idx_late:])
    late_u = np.mean(u[idx_late:])
    
    # 质量增益 (Mass Gain): 结尾是否比开头更严谨？
    idx_early = int(length * 0.1)
    early_mass = np.mean(m[:idx_early+1])
    mass_gain_ratio = late_mass / (early_mass + epsilon)
    
    # 内能衰减 (Cooling): 结尾是否比中间更冷静？
    # 比如对比中间段和结尾段
    mid_u = np.mean(u[idx_early:idx_late])
    cooling_ratio = late_u / (mid_u + epsilon) # < 1 表示冷却良好
    
    # === 4. 稳定性特征 (Stability) ===
    # 动能的波动率 (Jerkiness of thought)
    ek_stability = np.std(ek) / (mean_ek + epsilon)
    
    return {
        "Mean_Efficiency": mean_efficiency,  # 平均效率
        "Norm_Action": total_action,         # 归一化作用量
        "Late_Mass": late_mass,              # 末期质量 (严谨度)
        "Mass_Gain": mass_gain_ratio,        # 质量提升率
        "Late_Internal_E": late_u,           # 末期内耗 (纠结度)
        "Cooling_Ratio": cooling_ratio,      # 冷却比率
        "Ek_Stability": ek_stability,        # 动能稳定性
        "Mean_Kinetic_E": mean_ek,           # 平均动能
        "Total_Length": length               # 思考长度
    }

def train_physics_classifier(input_file):
    print(f"🚀 正在训练基于物理指标的 CoT 质量评估模型: {input_file} ...")
    
    if not os.path.exists(input_file):
        print("❌ 文件不存在")
        return

    features = []
    labels = []
    
    # 1. 特征提取
    print("Step 1: 提取高级物理特征...")
    with open(input_file, 'r', encoding='utf-8') as f:
        for line in f:
            if not line.strip(): continue
            try:
                item = json.loads(line)
                is_correct = item.get('is_correct')
                if is_correct is None: continue
                
                feat = extract_advanced_physics_features(item)
                if feat:
                    features.append(feat)
                    labels.append(1 if is_correct else 0)
            except: continue
            
    df = pd.DataFrame(features)
    y = np.array(labels)
    
    print(f"✅ 提取样本数: {len(df)}")
    print(f"   正样本 (Correct): {sum(y)}")
    print(f"   负样本 (Incorrect): {len(y) - sum(y)}")
    
    # 2. 数据集划分
    X = df.values
    feature_names = df.columns.tolist()
    
    # 标准化
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)
    
    X_train, X_test, y_train, y_test = train_test_split(X_scaled, y, test_size=0.2, random_state=42, stratify=y)
    
    # 3. 模型训练 (使用 Gradient Boosting)
    print("\nStep 2: 训练梯度提升分类器 (Gradient Boosting)...")
    clf = GradientBoostingClassifier(n_estimators=200, learning_rate=0.1, max_depth=4, random_state=42)
    clf.fit(X_train, y_train)
    
    # 4. 评估
    y_pred = clf.predict(X_test)
    y_prob = clf.predict_proba(X_test)[:, 1]
    
    acc = accuracy_score(y_test, y_pred)
    auc = roc_auc_score(y_test, y_prob)
    
    print("\n" + "="*40)
    print(f"🏆 模型评估结果 (Test Set)")
    print("="*40)
    print(f"Accuracy (准确率): {acc:.2%}")
    print(f"AUC Score (AUC值): {auc:.4f}")
    print("\nClassification Report:")
    print(classification_report(y_test, y_pred, target_names=['Incorrect', 'Correct']))
    
    # 5. 特征重要性分析
    feature_importance = clf.feature_importances_
    sorted_idx = np.argsort(feature_importance)
    
    plt.figure(figsize=(10, 6))
    plt.barh(range(len(sorted_idx)), feature_importance[sorted_idx], align='center', color='#1f77b4')
    plt.yticks(range(len(sorted_idx)), [feature_names[i] for i in sorted_idx])
    plt.xlabel('Feature Importance')
    plt.title('Which Physics Metric Matters Most for CoT Quality?')
    plt.tight_layout()
    plt.savefig("Physics_Feature_Importance.png", dpi=300)
    print("📊 特征重要性图表已保存: Physics_Feature_Importance.png")
    
    # 6. 混淆矩阵
    cm = confusion_matrix(y_test, y_pred)
    plt.figure(figsize=(6, 5))
    sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', xticklabels=['Pred Incorrect', 'Pred Correct'], yticklabels=['True Incorrect', 'True Correct'])
    plt.title('Confusion Matrix')
    plt.tight_layout()
    plt.savefig("Confusion_Matrix.png", dpi=300)

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--input_file", type=str, default="energy_collect.jsonl")
    args = parser.parse_args()
    
    train_physics_classifier(args.input_file)