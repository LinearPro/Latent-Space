import json
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from scipy import stats

# ================= 配置 =================
INPUT_FILE = 'avr_tf_pos.jsonl'
OUTPUT_BOXPLOT = 'Figure_Physics_Boxplots.png'
OUTPUT_SCATTER = 'Figure_Orthogonality.png'
# =======================================

def load_and_process_data(filename):
    print(f"📂 Loading data from {filename}...")
    data = []
    with open(filename, 'r', encoding='utf-8') as f:
        for line in f:
            if line.strip():
                try:
                    data.append(json.loads(line))
                except json.JSONDecodeError:
                    continue
    
    df = pd.DataFrame(data)
    
    # --- 计算关键物理指标 ---
    # 1. Internal Friction (Gap_Norm): Micro Norm (D2) - Macro Norm (D1)
    df['Gap_Norm'] = df['diff norms2'] - df['diff norms1']
    
    # 2. Incoherence (Gap_Angle): Micro Angle (A2) - Macro Angle (A1)
    df['Gap_Angle'] = df['angle2'] - df['angle1']
    
    return df

def plot_boxplots(df):
    print("🎨 Generating Boxplots...")
    
    # 定义要画的6个指标
    metrics = [
        ('diff norms1', 'Macro Norm ($D_1$)', 'Energy Baseline'),
        ('diff norms2', 'Micro Norm ($D_2$)', 'High-Freq Energy'),
        ('Gap_Norm', 'Internal Friction ($\Phi = D_2 - D_1$)', 'Work Done'),
        ('angle1', 'Macro Angle ($A_1$)', 'Direction Baseline'),
        ('angle2', 'Micro Angle ($A_2$)', 'Micro Direction'),
        ('Gap_Angle', 'Incoherence ($\mathcal{I} = A_2 - A_1$)', 'Structural Decay')
    ]
    
    # 设置绘图风格
    sns.set_style("whitegrid")
    sns.set_context("paper", font_scale=1.2)
    
    fig, axes = plt.subplots(2, 3, figsize=(18, 10))
    axes = axes.flatten()
    
    for i, (col, title, ylabel) in enumerate(metrics):
        ax = axes[i]
        
        # 1. 画箱线图
        sns.boxplot(
            data=df, x='is_correct', y=col, 
            hue='is_correct', legend=False,
            palette={True: '#1f77b4', False: '#d62728'}, 
            ax=ax, width=0.5, fliersize=3
        )
        
        # 2. 计算显著性 (t-test)
        correct = df[df['is_correct'] == True][col]
        incorrect = df[df['is_correct'] == False][col]
        t_stat, p_val = stats.ttest_ind(correct, incorrect, equal_var=False)
        
        # 3. 标注 P-value
        # 如果 p 非常小，用科学计数法
        p_text = f"p < 0.001" if p_val < 0.001 else f"p = {p_val:.3f}"
        sig_symbol = "***" if p_val < 0.001 else ("**" if p_val < 0.01 else ("*" if p_val < 0.05 else "n.s."))
        
        # 在图上方添加显著性标注
        y_max = df[col].max()
        y_range = y_max - df[col].min()
        ax.text(0.5, y_max + y_range*0.05, f"{sig_symbol}\n{p_text}", 
                ha='center', va='bottom', color='black', fontweight='bold')
        
        # 美化
        ax.set_title(title, fontweight='bold', fontsize=14)
        ax.set_ylabel(ylabel)
        ax.set_xlabel('Ground Truth')
        ax.set_xticklabels(['Incorrect', 'Correct'])
        
        # 调整 Y 轴范围以容纳标注
        ax.set_ylim(top=y_max + y_range*0.2)

    plt.tight_layout()
    plt.savefig(OUTPUT_BOXPLOT, dpi=300)
    print(f"✅ Boxplots saved to {OUTPUT_BOXPLOT}")

def plot_orthogonality(df):
    print("🎨 Generating Orthogonality Scatter Plot...")
    
    plt.figure(figsize=(8, 6))
    sns.set_style("whitegrid")
    
    # 计算相关系数
    corr, _ = stats.pearsonr(df['Gap_Norm'], df['Gap_Angle'])
    
    # 绘制散点图 (只画错误样本，观察幻觉的分布)
    # 或者画全量样本
    sns.scatterplot(
        data=df, x='Gap_Norm', y='Gap_Angle', 
        hue='is_correct', style='is_correct',
        palette={True: '#1f77b4', False: '#d62728'},
        alpha=0.7, s=60
    )
    
    plt.title(f"Orthogonality of Mechanisms (Pearson r={corr:.3f})", fontweight='bold', fontsize=14)
    plt.xlabel("Internal Friction ($\Phi$)", fontweight='bold', fontsize=12)
    plt.ylabel("Logical Incoherence ($\mathcal{I}$)", fontweight='bold', fontsize=12)
    plt.legend(title='Is Correct', loc='upper right')
    
    # 添加辅助线 (均值)
    plt.axvline(df['Gap_Norm'].mean(), color='gray', linestyle='--', alpha=0.5)
    plt.axhline(df['Gap_Angle'].mean(), color='gray', linestyle='--', alpha=0.5)
    
    plt.tight_layout()
    plt.savefig(OUTPUT_SCATTER, dpi=300)
    print(f"✅ Scatter plot saved to {OUTPUT_SCATTER}")

if __name__ == "__main__":
    # 1. 加载数据
    df = load_and_process_data(INPUT_FILE)
    
    # 2. 绘制箱线图 (用于展示显著性差异)
    plot_boxplots(df)
    
    # 3. 绘制散点图 (用于展示正交性)
    plot_orthogonality(df)