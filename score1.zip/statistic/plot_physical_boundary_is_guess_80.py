import json
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import PolynomialFeatures, StandardScaler
from sklearn.pipeline import make_pipeline
from sklearn.model_selection import train_test_split
import argparse
import os

def plot_physical_boundary_with_score(input_file):
    print(f"⚖️ 正在进行物理指标评估与相图绘制: {input_file} ...")
    
    # 定义需要高亮的特定行号 (1-based index)
    # 原始集合每个元素减去1后的结果
    TARGET_ROWS = {9, 73, 109, 173, 61, 161, 197, 17, 81, 117, 181, 24, 124, 188}
    print(f"🎯 目标高亮行号集合 (共{len(TARGET_ROWS)}个): {TARGET_ROWS}")
    
    # 1. 数据加载与清洗
    if not os.path.exists(input_file):
        print(f"❌ 错误: 文件 {input_file} 不存在。")
        return

    # 提取特征
    X_list, y_list = [], []
    highlight_list = [] 
    callback_data = []
    
    # 统计计数器
    found_targets_count = 0
    target_coords = [] 

    with open(input_file, 'r', encoding='utf-8') as f:
        # 使用 enumerate 获取行号，从 1 开始
        for line_idx, line in enumerate(f, 1):
            if not line.strip(): continue
            
            # 判断当前行是否在目标集合中
            is_target = (line_idx in TARGET_ROWS)

            try:
                item = json.loads(line)
                if 'diff norm1' in item:
                    item['diff norms1'] = item['diff norm1']
                    item['diff norms2'] = item['diff norm2']
                
                # 检查数据完整性
                if 'is_correct' not in item: 
                    if is_target: print(f"⚠️ 警告: 第 {line_idx} 行缺失 'is_correct'，跳过。")
                    continue
                
                d1 = item.get('diff norms1')
                d2 = item.get('diff norms2')
                a1 = item.get('angle1')
                a2 = item.get('angle2')
                if not (d1 and d2 and a1 and a2): 
                    if is_target: print(f"⚠️ 警告: 第 {line_idx} 行缺失物理指标数据，跳过。")
                    continue
                
                fric = np.array(d2) - np.array(d1)
                incoh = np.array(a2) - np.array(a1)
                
                if len(fric) < 5: 
                    if is_target: print(f"⚠️ 警告: 第 {line_idx} 行数据长度过短 (<5)，跳过。")
                    continue
                
                # 特征计算
                mean_fric = np.mean(fric)
                final_incoh = np.mean(incoh[int(len(incoh)*0.9):]) 
                
                label = 1 if item.get('is_correct', False) else 0
                
                if is_target:
                    found_targets_count += 1
                    target_coords.append((mean_fric, final_incoh))
                    print(f"✅ 成功加载目标行 {line_idx}: Friction={mean_fric:.4f}, Incoherence={final_incoh:.4f}")

                # 收集数据
                callback_record = {
                    "line_idx": line_idx,
                    "is_correct": bool(label),
                    "mean_fric": float(mean_fric),
                    "final_incoh": float(final_incoh),
                    "is_target_highlight": bool(is_target)
                }
                callback_data.append(callback_record)

                X_list.append([mean_fric, final_incoh])
                y_list.append(label)
                highlight_list.append(is_target)
                
            except Exception as e:
                if is_target: print(f"❌ 错误: 第 {line_idx} 行解析失败: {e}")
                continue
        
    print(f"📊 目标行加载统计: 预设 {len(TARGET_ROWS)} 个 -> 实际成功加载 {found_targets_count} 个")
    
    X = np.array(X_list)
    y = np.array(y_list)
    highlights = np.array(highlight_list)
    
    if len(y) < 10:
        print("❌ 错误：有效数据过少。")
        return

    # 2. 训练物理约束模型
    model = make_pipeline(
        StandardScaler(),
        PolynomialFeatures(degree=2, include_bias=False),
        LogisticRegression(C=1.0, penalty='l2')
    )
    
    # 全量拟合用于画图
    model.fit(X, y)
    accuracy = model.score(X, y)

    # 3. 绘制相图
    sns.set_style("whitegrid")
    plt.figure(figsize=(12, 10))
    
    # 数据过滤 (仅用于优化绘图范围)
    df_temp = pd.DataFrame(X, columns=['Friction', 'Incoherence'])
    mask_plot = (df_temp['Friction'] < df_temp['Friction'].quantile(0.99)) & \
                (df_temp['Incoherence'] < df_temp['Incoherence'].quantile(0.99))
    mask_final = mask_plot | highlights 
    
    X_plot = X[mask_final]
    y_plot = y[mask_final]
    highlights_plot = highlights[mask_final]
    
    # 创建网格
    x_min, x_max = X_plot[:, 0].min() - 1, X_plot[:, 0].max() + 1
    y_min, y_max = X_plot[:, 1].min() - 0.5, X_plot[:, 1].max() + 0.5
    xx, yy = np.meshgrid(np.linspace(x_min, x_max, 200), np.linspace(y_min, y_max, 200))
    
    Z = model.predict_proba(np.c_[xx.ravel(), yy.ravel()])[:, 1]
    Z = Z.reshape(xx.shape)

    contour = plt.contourf(xx, yy, Z, levels=20, cmap="RdBu", alpha=0.6)
    cbar = plt.colorbar(contour)
    cbar.set_label("Probability of Correctness $P(Correct)$", fontsize=12)

    plt.contour(xx, yy, Z, levels=[0.5], colors='black', linewidths=2.5, linestyles='--')

    # --- 绘制散点 ---
    
    # 1. 普通样本 (透明度高)
    mask_normal_correct = (y_plot == 1) & (~highlights_plot)
    plt.scatter(X_plot[mask_normal_correct, 0], X_plot[mask_normal_correct, 1], 
                c='white', edgecolors='#1f77b4', s=60, label='Correct', alpha=0.3, linewidth=1)
    
    mask_normal_incorrect = (y_plot == 0) & (~highlights_plot)
    plt.scatter(X_plot[mask_normal_incorrect, 0], X_plot[mask_normal_incorrect, 1], 
                c='white', edgecolors='#d62728', s=60, marker='X', label='Incorrect', alpha=0.3, linewidth=1)

    # 2. 🌟 高亮目标样本 (增加抖动 Jitter 以解决重叠问题)
    mask_highlight = highlights_plot
    if np.sum(mask_highlight) > 0:
        X_highlight = X_plot[mask_highlight]
        
        # 动态计算抖动幅度 (跨度的 1.5%)
        x_span = x_max - x_min
        y_span = y_max - y_min
        jitter_x = np.random.normal(0, x_span * 0.015, size=X_highlight.shape[0])
        jitter_y = np.random.normal(0, y_span * 0.015, size=X_highlight.shape[0])
        
        plt.scatter(X_highlight[:, 0] + jitter_x, X_highlight[:, 1] + jitter_y, 
                    c='lime', edgecolors='black', s=350, marker='*', 
                    label=f'Intuitive Guess (Ansatz 80)', 
                    alpha=0.9, linewidth=2.0, zorder=100)

    # 标注准确率
    plt.text(x_min + (x_max-x_min)*0.05, y_max*0.95, 
             f"Prediction Accuracy: {accuracy:.1%}", 
             fontsize=14, fontweight='bold', color='black',
             bbox=dict(facecolor='yellow', alpha=0.9, edgecolor='black', boxstyle='round,pad=0.5'))

    plt.title(f"Thermodynamic Phase Diagram (Highligting {np.sum(mask_highlight)} Points)", fontsize=16, fontweight='bold', pad=20)
    plt.xlabel(r"Cognitive Effort ($\bar{\Phi}_{diss}$)", fontsize=14, fontweight='bold')
    plt.ylabel(r"Logical Misalignment ($\mathcal{I}_{final}$)", fontsize=14, fontweight='bold')
    plt.legend(loc='lower right', framealpha=0.9, fontsize=11)
    plt.xlim(x_min, x_max)
    plt.ylim(y_min, y_max)
    plt.tight_layout()
    
    output_file = "Physical_Boundary_With_Highlights.png"
    plt.savefig(output_file, dpi=300)
    print(f"🖼️ 带高亮的相图已生成: {output_file}")

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--input_file", type=str, default="metrics.jsonl")
    args = parser.parse_args()
    
    plot_physical_boundary_with_score(args.input_file)