import joblib
import pandas as pd
import numpy as np

def inspect_saved_model(model_path="physics_quality_model.pkl"):
    print(f"🔍 正在加载模型文件: {model_path} ...")
    
    try:
        # 1. 加载模型包
        artifacts = joblib.load(model_path)
        print("✅ 加载成功！\n")
    except Exception as e:
        print(f"❌ 加载失败: {e}")
        return

    # --- 2. 查看整体结构 ---
    print("="*40)
    print("📦 模型包结构 (Keys)")
    print("="*40)
    for key in artifacts.keys():
        print(f"- {key}")
    
    if "description" in artifacts:
        print(f"\n📝 描述: {artifacts['description']}")

    # --- 3. 检查特征名称 ---
    features = artifacts["feature_names"]
    print(f"\n📋 包含特征 ({len(features)}个):")
    print(features)

    # --- 4. 检查分类器 (大脑) ---
    clf = artifacts["classifier"]
    print("\n" + "="*40)
    print("🧠 分类器详情 (The Brain)")
    print("="*40)
    print(f"类型: {type(clf).__name__}")
    print(f"参数: n_estimators={clf.n_estimators}, learning_rate={clf.learning_rate}, max_depth={clf.max_depth}")
    
    # *** 核心：打印特征重要性 ***
    print("\n📊 学到的物理法则 (特征重要性):")
    importances = clf.feature_importances_
    # 创建 DataFrame以此显示更清晰
    df_imp = pd.DataFrame({
        "Feature": features,
        "Importance": importances
    }).sort_values(by="Importance", ascending=False)
    
    print(df_imp)

    # --- 5. 检查归一化器 (度量衡) ---
    scaler = artifacts["scaler"]
    print("\n" + "="*40)
    print("⚖️ 归一化参数 (The Scaler)")
    print("="*40)
    print("模型记录的物理量均值 (Mean):")
    for name, mean_val in zip(features, scaler.mean_):
        print(f"  - {name}: {mean_val:.4f}")

    # --- 6. 模拟推理测试 ---
    print("\n" + "="*40)
    print("🚀 模拟推理测试 (Sanity Check)")
    print("="*40)
    
    # 随机生成一条假数据 (模拟一个高质量 CoT)
    # 假设: 效率高(0.8), 质量大(0.5), 稳定(0.1)
    fake_data = np.random.rand(1, len(features)) 
    
    # 必须先归一化
    fake_scaled = scaler.transform(fake_data)
    
    # 预测
    prob = clf.predict_proba(fake_scaled)[0, 1]
    pred = clf.predict(fake_scaled)[0]
    
    print(f"输入数据形状: {fake_data.shape}")
    print(f"预测结果: {'✅ Correct' if pred==1 else '❌ Incorrect'}")
    print(f"质量得分 (Probability): {prob:.4f}")
    
    print("\n✨ 检查完毕。模型完好无损，随时可以部署！")

if __name__ == "__main__":
    inspect_saved_model()