import json
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import PolynomialFeatures
from sklearn.pipeline import make_pipeline
import argparse
import os
import pandas as pd

def plot_friction_mass_heatmap(input_file, output_file="GlobalFriction_vs_LateMass_Heatmap.png"):
    print(f"🌡️ 正在绘制热力图 (X:全局摩擦 vs Y:末期质量): {input_file}")
    
    if not os.path.exists(input_file):
        print(f"❌ 错误: 文件 {input_file} 不存在。")
        return

    data_points = []
    
    with open(input_file, 'r', encoding='utf-8') as f:
        for line_idx, line in enumerate(f, 1):
            if not line.strip(): continue
            try:
                item = json.loads(line)
                
                # 获取字段
                a1 = item.get('angle1')
                a2 = item.get('angle2')
                d1 = item.get('diff norms1') or item.get('diff norm1')
                d2 = item.get('diff norms2') or item.get('diff norm2')
                is_correct = item.get('is_correct')
                
                if a1 is None or a2 is None or d1 is None or d2 is None or is_correct is None:
                    continue
                
                # 转 numpy
                angle1 = np.array(a1, dtype=float)
                angle2 = np.array(a2, dtype=float)
                diff1 = np.array(d1, dtype=float)
                diff2 = np.array(d2, dtype=float)
                
                # 长度对齐
                min_len = min(len(angle1), len(angle2), len(diff1), len(diff2))
                if min_len < 5: continue 
                
                # 截断
                angle1 = angle1[:min_len]
                angle2 = angle2[:min_len]
                diff1 = diff1[:min_len]
                diff2 = diff2[:min_len]
                
                # === 1. 计算 X轴: 全局摩擦 (Global Friction) ===
                # Friction = diff2 (微观) - diff1 (宏观)
                # 取整个序列的平均值
                friction_seq = diff2 - diff1
                global_friction = np.mean(friction_seq)
                
                # === 2. 计算 Y轴: 最后 10% 质量 (Late-Stage Mass) ===
                # Mass = 1 / |angle2 - angle1|
                start_idx = int(min_len * 0.9)
                if start_idx >= min_len: start_idx = min_len - 1
                if min_len - start_idx < 1: start_idx = max(0, min_len - 5)
                
                seg_a1 = angle1[start_idx:]
                seg_a2 = angle2[start_idx:]
                epsilon = 1e-6
                
                # 计算纯不一致性
                incoherence_pure = np.abs(seg_a2 - seg_a1)
                # 计算质量序列
                mass_seq = 1.0 / (incoherence_pure + epsilon)
                # 取平均
                late_mass = np.mean(mass_seq)
                
                data_points.append({
                    "Raw_Friction": global_friction,
                    "Raw_Mass": late_mass,
                    "Label": 1 if is_correct else 0
                })
                
            except Exception as e:
                continue
    
    if not data_points:
        print("❌ 未提取到有效数据。")
        return

    df = pd.DataFrame(data_points)
    print(f"✅ 成功提取样本数: {len(df)}")
    print(f"   Correct: {len(df[df['Label']==1])}, Incorrect: {len(df[df['Label']==0])}")
    
    # === 归一化 (Min-Max Normalization with Clipping) ===
    
    # 1. 摩擦 (X轴): 去除两端 1% 异常值
    f_min, f_max_cap = df["Raw_Friction"].quantile([0.01, 0.99])
    df["Clipped_Friction"] = df["Raw_Friction"].clip(f_min, f_max_cap)
    
    # 2. 质量 (Y轴): 去除两端 1% 异常值
    m_min, m_max_cap = df["Raw_Mass"].quantile([0.01, 0.99])
    df["Clipped_Mass"] = df["Raw_Mass"].clip(m_min, m_max_cap)
    
    # 3. 归一化到 [0, 1]
    df["Norm_Friction"] = (df["Clipped_Friction"] - df["Clipped_Friction"].min()) / (df["Clipped_Friction"].max() - df["Clipped_Friction"].min())
    df["Norm_Mass"] = (df["Clipped_Mass"] - df["Clipped_Mass"].min()) / (df["Clipped_Mass"].max() - df["Clipped_Mass"].min())
    
    print("✅ 数据归一化完成")
    
    # === 绘制相图 ===
    X = df[["Norm_Friction", "Norm_Mass"]].values
    y = df["Label"].values
    
    # 拟合背景热力图
    model = make_pipeline(
        PolynomialFeatures(degree=3, include_bias=False),
        LogisticRegression(C=10.0, max_iter=2000)
    )
    model.fit(X, y)
    acc = model.score(X, y)
    print(f"🎯 分类准确率: {acc:.2%}")

    # 绘图设置
    sns.set_style("whitegrid")
    plt.figure(figsize=(12, 10))
    
    xx, yy = np.meshgrid(np.linspace(0, 1, 200), np.linspace(0, 1, 200))
    Z = model.predict_proba(np.c_[xx.ravel(), yy.ravel()])[:, 1]
    Z = Z.reshape(xx.shape)
    
    # 1. 热力图
    contour = plt.contourf(xx, yy, Z, levels=20, cmap="RdBu", alpha=0.7)
    cbar = plt.colorbar(contour)
    cbar.set_label("Probability of Correctness $P(Correct)$", fontsize=12)
    
    # 2. 决策边界
    plt.contour(xx, yy, Z, levels=[0.5], colors='black', linewidths=2.5, linestyles='--')
    
    # 3. 散点
    mask_correct = (y == 1)
    plt.scatter(X[mask_correct, 0], X[mask_correct, 1],
                c='lime', edgecolors='black', s=50, alpha=0.6, label='Correct')
    
    mask_incorrect = (y == 0)
    plt.scatter(X[mask_incorrect, 0], X[mask_incorrect, 1],
                c='red', edgecolors='black', s=50, marker='X', alpha=0.6, label='Incorrect')
    
    # 标题与标签
    plt.title("Thermodynamics: Global Friction vs. Late-Stage Mass", fontsize=16, fontweight='bold', pad=20)
    plt.xlabel(r"Normalized Global Friction ($\bar{F}_{total}$)", fontsize=14, fontweight='bold')
    plt.ylabel(r"Normalized Late-Stage Mass ($m_{final}$)", fontsize=14, fontweight='bold')
    
    # 物理意义注释
    plt.text(0.1, 0.9, "Low Friction / High Mass\n(Ideal Flow)", ha='center', fontsize=11, fontweight='bold', bbox=dict(facecolor='white', alpha=0.8))
    plt.text(0.9, 0.1, "High Friction / Low Mass\n(Cognitive Struggle)", ha='center', fontsize=11, fontweight='bold', bbox=dict(facecolor='white', alpha=0.8))

    plt.legend(loc='lower right', framealpha=0.9, fontsize=12)
    plt.xlim(0, 1)
    plt.ylim(0, 1)
    plt.tight_layout()
    
    plt.savefig(output_file, dpi=300)
    print(f"🖼️ 热力图已生成: {output_file}")

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--input_file", type=str, default="metrics.jsonl")
    args = parser.parse_args()
    
    plot_friction_mass_heatmap(args.input_file)