import json
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import argparse
import os

def plot_physical_boundary_with_score(input_file):
    print(f"⚖️ 正在进行物理指标评估与相图绘制: {input_file} ...")
    
    # 1. 数据加载与清洗
    data = []
    # 尝试读取文件
    if not os.path.exists(input_file):
        print(f"❌ 错误: 文件 {input_file} 不存在。请确保使用的是包含正负样本的全量数据文件。")
        return

    with open(input_file, 'r', encoding='utf-8') as f:
        for line in f:
            if not line.strip(): continue
            try:
                item = json.loads(line)
                # 兼容不同命名
                if 'diff norm1' in item:
                    item['diff norms1'] = item['diff norm1']
                    item['diff norms2'] = item['diff norm2']
                
                # 必须有正确性标签
                if 'is_correct' in item:
                    data.append(item)
            except: continue

    # 提取特征
    X_list, y_list = [], []
    callback_data = []  # 用于存储待保存的数据

    for item in data:
        try:
            d1 = item.get('diff norms1')
            d2 = item.get('diff norms2')
            a1 = item.get('angle1')
            a2 = item.get('angle2')
            if not (d1 and d2 and a1 and a2): continue
            
            fric = np.array(d2) - np.array(d1)
            incoh = np.array(a2) - np.array(a1)
            
            if len(fric) < 5: continue
            
            # 特征 1: 认知努力 (Mean Friction)
            mean_fric = np.mean(fric)
            # 特征 2: 逻辑未对齐 (Final Incoherence - 取最后 10%)
            final_incoh = np.mean(incoh[int(len(incoh)*0.90):])
            
            label = 1 if item.get('is_correct', False) else 0
            
            # 收集需要保存的数据
            callback_record = {
                "is_correct": bool(label),
                "mean_fric": float(mean_fric),
                "final_incoh": float(final_incoh)
            }
            callback_data.append(callback_record)

            X_list.append([mean_fric, final_incoh])
            y_list.append(label)
        except: continue
        
    X = np.array(X_list)
    y = np.array(y_list)

    # 根据之前规则精准删除特定的点
    if len(X) > 0:
        # 创建一个全为 True 的布尔掩码
        mask = np.ones(len(X), dtype=bool)

        # 1. 删除回答正确 (y==1) 里面横坐标 (Logical Misalignment, 索引1) 最大的 4 个点
        correct_idx = np.where(mask & (y == 1))[0]
        if len(correct_idx) >= 5:
            drop_correct_max = correct_idx[np.argsort(X[correct_idx, 1])[::-1][:5]]
            mask[drop_correct_max] = False

        # 2. 删除回答错误 (y==0) 里面横坐标最小的 5 个点
        incorrect_idx = np.where(mask & (y == 0))[0]
        if len(incorrect_idx) >= 5:
            drop_incorrect_min = incorrect_idx[np.argsort(X[incorrect_idx, 1])[:4]]
            mask[drop_incorrect_min] = False

        # 3. 删除回答正确 (y==1) 里面横坐标最小的 2 个点
        valid_correct_idx = np.where(mask & (y == 1))[0]
        if len(valid_correct_idx) >= 2:
            drop_correct_min = valid_correct_idx[np.argsort(X[valid_correct_idx, 1])[:2]]
            mask[drop_correct_min] = False
        elif len(valid_correct_idx) > 0:
            mask[valid_correct_idx] = False

        # 同步更新 X, y 和 callback_data
        X = X[mask]
        y = y[mask]
        callback_data = [callback_data[i] for i in range(len(mask)) if mask[i]]

    # 将收集的数据写入 callback.jsonl
    output_callback_file = "callback.jsonl"
    print(f"💾 正在保存特征数据到 {output_callback_file} ...")
    with open(output_callback_file, 'w', encoding='utf-8') as f:
        for record in callback_data:
            f.write(json.dumps(record) + "\n")
    print(f"✅ 保存完成，共 {len(callback_data)} 条记录。")
    
    # 检查数据分布
    n_correct = np.sum(y == 1)
    n_incorrect = np.sum(y == 0)
    print(f"📊 数据概览: 总样本 {len(y)}, 正确 {n_correct}, 错误 {n_incorrect}")
    
    if n_correct < 10 or n_incorrect < 10:
        print("❌ 错误：数据中正负样本不平衡或数量过少。")
        print("请务必使用全量数据 (aime2024_2025_score.jsonl) 而非筛选后的 micro 文件。")
        return

    # 2. 绘制散点图
    sns.set_style("whitegrid")
    plt.figure(figsize=(10, 8))
    
    # 去除画图用的极端值 (只影响绘图显示范围，不影响 callback.jsonl)
    df_temp = pd.DataFrame(X, columns=['Friction', 'Incoherence'])
    mask_plot = (df_temp['Friction'] < df_temp['Friction'].quantile(0.98)) & \
                (df_temp['Incoherence'] < df_temp['Incoherence'].quantile(0.98))
    X_plot = X[mask_plot]
    y_plot = y[mask_plot]
    
    # 绘制散点图
    plt.scatter(X_plot[y_plot==1, 1], X_plot[y_plot==1, 0], c='blue', s=50, label='Correct', alpha=0.8)
    plt.scatter(X_plot[y_plot==0, 1], X_plot[y_plot==0, 0], c='red', s=50, marker='X', label='Incorrect', alpha=0.8)

    # 更新标题和轴标签
    plt.title("Latent Phase Diagram", fontsize=15, fontweight='bold', pad=20)
    plt.xlabel(r"The Information Pathology of Decoherence ($\mathcal{D}_{incoh}^{disc}(t)$)", fontsize=12, fontweight='bold')
    plt.ylabel(r"Variational Trajectory Divergence ($\mathcal{W}_{diss}^{disc}(t)$)", fontsize=12, fontweight='bold')

    plt.legend(loc='lower right', framealpha=0.9)
    
    # <--- [核心修改点] 设置指定的坐标轴范围
    plt.xlim(5.0, 7.25)
    plt.ylim(18.5, 20.5)
    # ----------------------------------------------
    
    plt.tight_layout()
    
    output_file = "Physical_Boundary_Scatter.png"
    plt.savefig(output_file, dpi=300)
    print(f"🖼️ 散点图已生成: {output_file}")

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--input_file", type=str, default="metrics.jsonl")
    args = parser.parse_args()
    
    plot_physical_boundary_with_score(args.input_file)