import json
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import os

def analyze_attractor_dynamics_with_lle(input_file="metrics.jsonl", window_size=5):
    print("🔬 启动多维动力学分析：拓扑平移、波动率演化与局部李雅普诺夫指数(LLE)计算...")
    
    if not os.path.exists(input_file):
        print(f"❌ 文件 {input_file} 不存在。")
        return

    # === 数据容器 ===
    # 1. 宏观轨迹与锚点
    C_trajs_fric, C_trajs_incoh = [], []
    I_trajs_fric, I_trajs_incoh = [], []
    C_ends_fric, C_ends_incoh = [], []
    I_ends_fric, I_ends_incoh = [], []
    
    # 2. 相对波动率
    C_rel_volatility, I_rel_volatility = [], []
    
    # 3. 局部李雅普诺夫指数 (Local Lyapunov Exponent)
    C_lle, I_lle = [], []
    
    with open(input_file, 'r', encoding='utf-8') as f:
        for line in f:
            if not line.strip(): continue
            try:
                item = json.loads(line)
                # 兼容不同命名
                d1 = item.get('diff norm1', item.get('diff norms1'))
                d2 = item.get('diff norm2', item.get('diff norms2'))
                a1 = item.get('angle1')
                a2 = item.get('angle2')
                
                if not (d1 and d2 and a1 and a2): continue
                
                fric = np.array(d2) - np.array(d1)
                incoh = np.array(a2) - np.array(a1)
                
                # 过滤过短的轨迹
                if len(fric) < window_size * 3: continue
                
                is_correct = item.get('is_correct', False)
                total_len = len(fric)
                
                # 定义各个分析区间
                start_idx = 0
                end_idx = int(total_len * 0.9)
                tail_start_idx = int(total_len * 0.7) # 最后 30% 用于计算 LLE
                
                # 1. 计算该条 CoT 在最后 90-100% 阶段的最终锚点坐标
                cot_end_fric = np.mean(fric[end_idx:])
                cot_end_incoh = np.mean(incoh[end_idx:])
                
                # 记录轨迹与锚点 (用于图 1)
                if is_correct:
                    C_trajs_fric.append(fric[start_idx:end_idx])
                    C_trajs_incoh.append(incoh[start_idx:end_idx])
                    C_ends_fric.append(cot_end_fric)
                    C_ends_incoh.append(cot_end_incoh)
                else:
                    I_trajs_fric.append(fric[start_idx:end_idx])
                    I_trajs_incoh.append(incoh[start_idx:end_idx])
                    I_ends_fric.append(cot_end_fric)
                    I_ends_incoh.append(cot_end_incoh)
                
                # 2. 动态波动率计算 (用于图 2)
                df = pd.DataFrame({'f': fric, 'i': incoh})
                rolling_std_f = df['f'].rolling(window=window_size, min_periods=1).std().fillna(0).values
                rolling_std_i = df['i'].rolling(window=window_size, min_periods=1).std().fillna(0).values
                total_volatility = np.sqrt(rolling_std_f**2 + rolling_std_i**2)
                
                orig_steps = np.linspace(0, 100, len(total_volatility))
                target_steps = np.linspace(0, 100, 11)
                vol_interp = np.interp(target_steps, orig_steps, total_volatility)
                baseline = np.mean(vol_interp[9:11])
                rel_vol = vol_interp[1:10] - baseline
                
                if is_correct:
                    C_rel_volatility.append(rel_vol)
                else:
                    I_rel_volatility.append(rel_vol)
                    
                # 3. 局部李雅普诺夫指数 LLE 计算 (用于图 3)
                # 截取末端 70%-100% 收敛窗口，评估扰动收缩率
                tail_fric = np.array(fric[tail_start_idx:])
                tail_incoh = np.array(incoh[tail_start_idx:])
                
                if len(tail_fric) > 5: # 确保有足够步数计算梯度
                    eps = 1e-8
                    # 计算轨迹每一步到其最终收敛中心的欧氏距离
                    distances = np.sqrt((tail_fric - cot_end_fric)**2 + (tail_incoh - cot_end_incoh)**2) + eps
                    
                    # 核心：计算对数偏离率均值 λ = mean(ln(D_t / D_t-1))
                    log_ratios = np.log(distances[1:] / distances[:-1])
                    # 清理可能出现的异常值 (inf/nan)
                    log_ratios = log_ratios[~np.isnan(log_ratios) & ~np.isinf(log_ratios)]
                    
                    if len(log_ratios) > 0:
                        local_lyapunov = np.mean(log_ratios)
                        if is_correct:
                            C_lle.append(local_lyapunov)
                        else:
                            I_lle.append(local_lyapunov)
                            
            except Exception as e: 
                continue

    # ================= 吸引子宏观中心计算与轨迹平移 (用于相图) =================
    mean_C_end_f = np.mean(C_ends_fric) if C_ends_fric else 0
    mean_C_end_i = np.mean(C_ends_incoh) if C_ends_incoh else 0
    mean_I_end_f = np.mean(I_ends_fric) if I_ends_fric else 0
    mean_I_end_i = np.mean(I_ends_incoh) if I_ends_incoh else 0

    C_fric_flat, C_incoh_flat = [], []
    I_fric_flat, I_incoh_flat = [], []

    for traj_f, traj_i, end_f, end_i in zip(C_trajs_fric, C_trajs_incoh, C_ends_fric, C_ends_incoh):
        C_fric_flat.extend(traj_f - end_f + mean_C_end_f)
        C_incoh_flat.extend(traj_i - end_i + mean_C_end_i)

    for traj_f, traj_i, end_f, end_i in zip(I_trajs_fric, I_trajs_incoh, I_ends_fric, I_ends_incoh):
        I_fric_flat.extend(traj_f - end_f + mean_I_end_f)
        I_incoh_flat.extend(traj_i - end_i + mean_I_end_i)

    # 抽样与施密特正交化
    max_pts = 10000
    len_C = len(C_fric_flat)
    len_I = len(I_fric_flat)
    
    idx_C = np.random.choice(len_C, min(max_pts, len_C), replace=False) if len_C > 0 else []
    idx_I = np.random.choice(len_I, min(max_pts, len_I), replace=False) if len_I > 0 else []

    C_f_plot = np.array(C_fric_flat)[idx_C] if len_C > 0 else np.array([])
    C_i_plot = np.array(C_incoh_flat)[idx_C] if len_C > 0 else np.array([])
    I_f_plot = np.array(I_fric_flat)[idx_I] if len_I > 0 else np.array([])
    I_i_plot = np.array(I_incoh_flat)[idx_I] if len_I > 0 else np.array([])

    X_all = np.concatenate([C_f_plot, I_f_plot]) if len_C > 0 or len_I > 0 else np.array([])
    Y_all = np.concatenate([C_i_plot, I_i_plot]) if len_C > 0 or len_I > 0 else np.array([])

    if len(X_all) > 0 and np.dot(X_all, X_all) != 0:
        proj_coeff = np.dot(Y_all, X_all) / np.dot(X_all, X_all)
        C_f_ortho = C_f_plot
        C_i_ortho = C_i_plot - proj_coeff * C_f_plot
        I_f_ortho = I_f_plot
        I_i_ortho = I_i_plot - proj_coeff * I_f_plot
    else:
        C_f_ortho, C_i_ortho = C_f_plot, C_i_plot
        I_f_ortho, I_i_ortho = I_f_plot, I_i_plot

    # ================= 绘图 =================
    sns.set_style("whitegrid")
    # 创建 1x3 的图表布局
    fig, (ax1, ax2, ax3) = plt.subplots(1, 3, figsize=(24, 7))
    fig.suptitle("LLM Reasoning Dynamics: Topological Basins, Volatility, and Local Stability (T=0.6 Ensemble)", fontsize=18, fontweight='bold')

    # --- 左图：平移对齐后的全局状态密度图 (Attractor Basins) ---
    ax1.set_title("Aligned Attractor Basins", fontsize=14)
    ax1.set_xlabel(r"Instant Cognitive Effort ($\Phi_{diss}$)", fontsize=12)
    ax1.set_ylabel(r"Orthogonalized Logical Misalignment ($\mathcal{I}_{\perp}$)", fontsize=12)

    # 蓝图置底, 红图置顶
    if len(C_f_ortho) > 0:
        sns.kdeplot(x=C_f_ortho, y=C_i_ortho, cmap="Blues", fill=True, alpha=0.6, levels=8, ax=ax1, label='Correct Attractor Well', zorder=1)
    if len(I_f_ortho) > 0:
        sns.kdeplot(x=I_f_ortho, y=I_i_ortho, cmap="Reds", fill=True, alpha=0.85, levels=8, ax=ax1, label='Incorrect Basin', zorder=2)
    
    handles, labels = ax1.get_legend_handles_labels()
    if handles: ax1.legend(handles, labels, loc='upper right')

    # --- 中图：相对波动率演化 (Pre-Convergence Volatility) ---
    ax2.set_title("Pre-Convergence Volatility (90-100% Baseline Subtracted)", fontsize=14)
    ax2.set_xlabel("CoT Generation Progress Intervals (%)", fontsize=12)
    ax2.set_ylabel(r"Relative Local Volatility ($\Delta$ from Final State)", fontsize=12)

    progress_x = np.linspace(10, 90, 9)
    tick_labels = [f"{0 if x==10 else int(x-9)}-{int(x)}%" for x in progress_x]
    
    ax2.axhline(0, color='gray', linestyle=':', linewidth=2, label='90-100% Final State Reference', zorder=0)

    if len(C_rel_volatility) > 0:
        mean_C_vol = np.mean(C_rel_volatility, axis=0)
        ax2.fill_between(progress_x, mean_C_vol, color='blue', alpha=0.1, zorder=1)
        ax2.plot(progress_x, mean_C_vol, color='blue', linewidth=3, marker='o', markersize=6, label='Correct Path $\Delta V$', zorder=2)

    if len(I_rel_volatility) > 0:
        mean_I_vol = np.mean(I_rel_volatility, axis=0)
        ax2.fill_between(progress_x, mean_I_vol, color='red', alpha=0.15, zorder=3)
        ax2.plot(progress_x, mean_I_vol, color='red', linewidth=3, linestyle='--', marker='s', markersize=6, label='Incorrect Path $\Delta V$', zorder=4)
    
    ax2.set_xticks(progress_x)
    ax2.set_xticklabels(tick_labels, rotation=45, ha='right')
    ax2.legend(loc='upper right')

    # --- 右图：局部李雅普诺夫指数 (Local Lyapunov Exponent) ---
    ax3.set_title("Local Lyapunov Exponent at CoT Tail (70-100%)", fontsize=14)
    ax3.set_ylabel(r"Local Lyapunov Exponent ($\lambda$)", fontsize=12)
    
    # 过滤掉极端异常值以保证绘图美观 (选取 1% - 99% 分位数)
    def filter_outliers(data):
        if len(data) == 0: return []
        p1, p99 = np.percentile(data, 1), np.percentile(data, 99)
        return [x for x in data if p1 <= x <= p99]
    
    clean_C_lle = filter_outliers(C_lle)
    clean_I_lle = filter_outliers(I_lle)

    lle_data = pd.DataFrame({
        'LLE': clean_C_lle + clean_I_lle,
        'Trajectory Type': ['Correct (True Attractor)'] * len(clean_C_lle) + ['Incorrect (Slippery Slope)'] * len(clean_I_lle)
    })
    
    if not lle_data.empty:
        # 小提琴图展示分布密度，内部包含箱线图
        sns.violinplot(x='Trajectory Type', y='LLE', data=lle_data, 
                       palette={'Correct (True Attractor)': '#6BAED6', 'Incorrect (Slippery Slope)': '#FB6A4A'}, 
                       inner="quartile", ax=ax3, alpha=0.8)
        
        # 添加物理临界线 λ = 0
        ax3.axhline(0, color='black', linestyle='--', linewidth=2, label=r'Critical Threshold ($\lambda=0$)')
        
        # 获取当前 y 轴范围，以动态设置文字位置
        ymin, ymax = ax3.get_ylim()
        
        # 标注物理意义
        ax3.text(-0.25, ymax - (ymax-ymin)*0.05, 'Deep Restoring Well\n(Strong Convergence $\lambda<0$)', 
                 transform=ax3.get_xaxis_transform(), ha='center', color='#08519C', fontsize=11, fontweight='bold')
        ax3.text(1.25, ymax - (ymax-ymin)*0.05, 'Shallow/Flat Well\n(Wandering/Diverging $\lambda>0$)', 
                 transform=ax3.get_xaxis_transform(), ha='center', color='#A50F15', fontsize=11, fontweight='bold')
        
        ax3.legend(loc='lower right')

    plt.tight_layout(rect=[0, 0.03, 1, 0.95])
    output_filename = "Attractor_Dynamics_T0.6_LLE.png"
    plt.savefig(output_filename, dpi=300)
    print(f"\n🖼️ 三联动力学分析完毕！相图已保存为 {output_filename}")
    
    # 打印简要的统计结果
    if len(clean_C_lle) > 0 and len(clean_I_lle) > 0:
        print("\n📊 局部李雅普诺夫指数 (LLE) 统计概要:")
        print(f"✅ 正确推理均值 λ: {np.mean(clean_C_lle):.4f} (中位数: {np.median(clean_C_lle):.4f})")
        print(f"❌ 错误推理均值 λ: {np.mean(clean_I_lle):.4f} (中位数: {np.median(clean_I_lle):.4f})")
        if np.mean(clean_C_lle) < np.mean(clean_I_lle):
            print("💡 结论支撑: 正确推理具有更强的向心恢复力 (λ更小)，错误推理更接近混沌游走！")

if __name__ == "__main__":
    analyze_attractor_dynamics_with_lle("metrics.jsonl")