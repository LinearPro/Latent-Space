import json
import numpy as np
import pandas as pd
import joblib  # 核心库：用于保存模型
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.ensemble import GradientBoostingClassifier
from sklearn.metrics import classification_report, accuracy_score, confusion_matrix, roc_auc_score
from sklearn.preprocessing import StandardScaler
import argparse
import os

# ==========================================
# 1. 特征提取逻辑 (核心物理法则)
# ==========================================
def extract_advanced_physics_features(item):
    """
    从原始物理序列中提取高级动力学特征
    (注意：已移除 Total_Length，确保纯物理驱动)
    """
    # 获取序列
    m = np.array(item['mass'])
    v = np.array(item['velocity'])
    ek = np.array(item['kinetic_energy'])
    u = np.array(item['internal_energy'])
    
    length = len(m)
    if length < 5: return None
    
    epsilon = 1e-6
    
    # === 基础统计 ===
    mean_mass = np.mean(m)
    mean_ek = np.mean(ek)
    mean_u = np.mean(u)
    
    # === 能量效率 ===
    efficiency_seq = ek / (ek + u + epsilon)
    mean_efficiency = np.mean(efficiency_seq)
    
    # 拉格朗日量 / 作用量
    lagrangian_seq = ek - u
    total_action = np.sum(lagrangian_seq) / length 
    
    # === 阶段演化 (最后 10%) ===
    idx_late = int(length * 0.90)
    if idx_late >= length: idx_late = length - 1
    
    late_mass = np.mean(m[idx_late:])
    late_u = np.mean(u[idx_late:])
    
    # 质量增益
    idx_early = int(length * 0.1)
    early_mass = np.mean(m[:idx_early+1])
    mass_gain_ratio = late_mass / (early_mass + epsilon)
    
    # 冷却比率
    mid_u = np.mean(u[idx_early:idx_late])
    cooling_ratio = late_u / (mid_u + epsilon)
    
    # === 稳定性 ===
    ek_stability = np.std(ek) / (mean_ek + epsilon)
    
    return {
        "Mean_Efficiency": mean_efficiency,
        "Norm_Action": total_action,
        "Late_Mass": late_mass,
        "Mass_Gain": mass_gain_ratio,
        "Late_Internal_E": late_u,
        "Cooling_Ratio": cooling_ratio,
        "Ek_Stability": ek_stability,
        "Mean_Kinetic_E": mean_ek
        # "Total_Length": length # 已移除
    }

# ==========================================
# 2. 训练与保存逻辑
# ==========================================
def train_and_save_physics_model(input_file, save_path="physics_quality_model.pkl"):
    print(f"🚀 开始训练流程: {input_file} ...")
    
    if not os.path.exists(input_file):
        print("❌ 输入文件不存在")
        return

    features = []
    labels = []
    
    # --- Step 1: 加载数据 ---
    print("Step 1: 提取特征...")
    with open(input_file, 'r', encoding='utf-8') as f:
        for line in f:
            if not line.strip(): continue
            try:
                item = json.loads(line)
                is_correct = item.get('is_correct')
                if is_correct is None: continue
                
                feat = extract_advanced_physics_features(item)
                if feat:
                    features.append(feat)
                    labels.append(1 if is_correct else 0)
            except: continue
            
    df = pd.DataFrame(features)
    y = np.array(labels)
    feature_names = df.columns.tolist()
    
    print(f"✅ 样本数: {len(df)} (正样本: {sum(y)} / 负样本: {len(y)-sum(y)})")
    
    # --- Step 2: 预处理 (Fitting Scaler) ---
    # 注意：必须保存这个 scaler，否则将来新数据无法正确归一化！
    scaler = StandardScaler()
    X = df.values
    X_scaled = scaler.fit_transform(X)
    
    X_train, X_test, y_train, y_test = train_test_split(X_scaled, y, test_size=0.2, random_state=42, stratify=y)
    
    # --- Step 3: 训练模型 ---
    print("\nStep 2: 训练 Gradient Boosting 分类器...")
    clf = GradientBoostingClassifier(n_estimators=200, learning_rate=0.1, max_depth=4, random_state=42)
    clf.fit(X_train, y_train)
    
    # --- Step 4: 评估 (确保模型是好的) ---
    y_pred = clf.predict(X_test)
    acc = accuracy_score(y_test, y_pred)
    auc = roc_auc_score(y_test, clf.predict_proba(X_test)[:, 1])
    
    print("\n" + "="*40)
    print(f"🏆 训练完成 - 评估结果")
    print("="*40)
    print(f"Accuracy: {acc:.2%}")
    print(f"AUC:      {auc:.4f}")
    
    # --- Step 5: 封装与保存 (核心步骤) ---
    print(f"\n💾 正在保存模型至: {save_path} ...")
    
    model_artifacts = {
        "classifier": clf,          # 训练好的模型
        "scaler": scaler,           # 训练好的归一化参数 (均值、方差)
        "feature_names": feature_names, # 特征名称列表 (保证顺序一致)
        "description": "GradientBoosting model for CoT Physics Quality (No Length)"
    }
    
    joblib.dump(model_artifacts, save_path)
    print(f"✅ 模型已成功保存！您可以随时加载并用于新数据的推理。")

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--input_file", type=str, default="energy_collect.jsonl")
    parser.add_argument("--save_path", type=str, default="physics_quality_model.pkl")
    args = parser.parse_args()
    
    train_and_save_physics_model(args.input_file, args.save_path)