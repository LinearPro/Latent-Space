import json
import numpy as np
import argparse
import os
from tqdm import tqdm

def calculate_token_wise_physics(input_file, output_file):
    print(f"⚛️ 正在计算逐Token物理指标 (质量/速度/动能/内能): {input_file} -> {output_file}")
    
    if not os.path.exists(input_file):
        print(f"❌ 错误: 输入文件 {input_file} 不存在。")
        return

    count = 0
    skipped = 0
    
    # 物理常数
    epsilon = 1e-6

    with open(input_file, 'r', encoding='utf-8') as fin, \
         open(output_file, 'w', encoding='utf-8') as fout:
        
        # 读取文件总行数用于进度条
        lines = fin.readlines()
        print(f"处理 {len(lines)} 条数据...")
        
        for line in tqdm(lines):
            if not line.strip(): continue
            try:
                item = json.loads(line)
                
                # 1. 获取原始指标
                # d1: Macro Velocity (diff norms1)
                # d2: Micro Velocity (diff norms2)
                # a1: Macro Angle (angle1)
                # a2: Micro Angle (angle2)
                d1 = item.get('diff norms1') or item.get('diff norm1')
                d2 = item.get('diff norms2') or item.get('diff norm2')
                a1 = item.get('angle1')
                a2 = item.get('angle2')
                is_correct = item.get('is_correct')
                
                # 完整性检查
                if d1 is None or d2 is None or a1 is None or a2 is None or is_correct is None:
                    skipped += 1
                    continue
                
                # 2. 转换为 Numpy 数组
                v_macro = np.array(d1, dtype=float)
                v_micro = np.array(d2, dtype=float)
                angle_macro = np.array(a1, dtype=float)
                angle_micro = np.array(a2, dtype=float)
                
                # 3. 长度对齐 (以最短的为准)
                min_len = min(len(v_macro), len(v_micro), len(angle_macro), len(angle_micro))
                if min_len == 0:
                    skipped += 1
                    continue
                    
                v_macro = v_macro[:min_len]
                v_micro = v_micro[:min_len]
                angle_macro = angle_macro[:min_len]
                angle_micro = angle_micro[:min_len]
                
                # ================= 核心物理计算 =================
                
                # A. 质量 (Mass)
                # 定义: 纯不一致性 (Pure Incoherence) 的倒数
                # m = 1 / (|angle2 - angle1| + epsilon)
                incoherence_pure = np.abs(angle_micro - angle_macro)
                mass = 1.0 / (incoherence_pure + epsilon)
                
                # B. 速度 (Velocity)
                # 定义: 宏观思维流速
                # v = diff norms1
                velocity = v_macro
                
                # C. 动能 (Kinetic Energy, Ek)
                # 定义: 1/2 * m * v^2
                kinetic_energy = 0.5 * mass * (velocity ** 2)
                
                # D. 内能 (Internal Energy, U_turb)
                # 定义: 湍流能量 (微观与宏观速度差的平方)
                # U = 1/2 * m * (v_micro - v_macro)^2
                turbulent_energy = 0.5 * mass * ((v_micro - v_macro) ** 2)
                
                # ==============================================
                
                # 4. 构造输出数据 (仅保留指定字段)
                output_record = {
                    "is_correct": is_correct,
                    "mass": mass.tolist(),
                    "velocity": velocity.tolist(),
                    "kinetic_energy": kinetic_energy.tolist(),
                    "internal_energy": turbulent_energy.tolist()
                }
                
                fout.write(json.dumps(output_record) + "\n")
                count += 1
                
            except Exception as e:
                skipped += 1
                continue

    print(f"✅ 计算完成。")
    print(f"   成功写入: {count} 条")
    print(f"   跳过/无效: {skipped} 条")
    print(f"   输出文件: {output_file}")

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Calculate Token-wise Physics Metrics")
    parser.add_argument("--input_file", type=str, default="metrics.jsonl", help="Input file with raw metrics")
    parser.add_argument("--output_file", type=str, default="energy_collect.jsonl", help="Output file")
    
    args = parser.parse_args()
    
    calculate_token_wise_physics(args.input_file, args.output_file)