import json
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.ensemble import GradientBoostingClassifier
from sklearn.preprocessing import MinMaxScaler
import argparse
import os

# ==========================================
# 1. 核心特征提取逻辑 (保持与您的训练代码完全一致)
# ==========================================
def extract_advanced_physics_features(item):
    m = np.array(item['mass'])
    v = np.array(item['velocity'])
    ek = np.array(item['kinetic_energy'])
    u = np.array(item['internal_energy'])
    
    length = len(m)
    if length < 5: return None
    
    epsilon = 1e-6
    
    # Global Stats
    mean_mass = np.mean(m)
    mean_ek = np.mean(ek)
    mean_u = np.mean(u)
    
    # Efficiency
    efficiency_seq = ek / (ek + u + epsilon)
    mean_efficiency = np.mean(efficiency_seq)
    
    # Lagrangian Action
    lagrangian_seq = ek - u
    total_action = np.sum(lagrangian_seq) / length 
    
    # Phase Dynamics (Last 10%)
    idx_late = int(length * 0.90)
    if idx_late >= length: idx_late = length - 1
    
    late_mass = np.mean(m[idx_late:])
    late_u = np.mean(u[idx_late:])
    
    # Mass Gain
    idx_early = int(length * 0.1)
    early_mass = np.mean(m[:idx_early+1])
    mass_gain_ratio = late_mass / (early_mass + epsilon)
    
    # Cooling
    mid_u = np.mean(u[idx_early:idx_late])
    cooling_ratio = late_u / (mid_u + epsilon) 
    
    # Stability
    ek_stability = np.std(ek) / (mean_ek + epsilon)
    
    return {
        "Mean_Efficiency": mean_efficiency,
        "Norm_Action": total_action,
        "Late_Mass": late_mass,
        "Mass_Gain": mass_gain_ratio,
        "Late_Internal_E": late_u,
        "Cooling_Ratio": cooling_ratio,
        "Ek_Stability": ek_stability,
        "Mean_Kinetic_E": mean_ek,
        "Total_Length": length
    }

# ==========================================
# 2. 自动相图绘制逻辑
# ==========================================
def plot_auto_phase_diagram(input_file, output_file="Advanced_Phase_Separation.png"):
    print(f"🔮 正在构建高维物理相图: {input_file}")
    
    if not os.path.exists(input_file):
        print("❌ 文件不存在")
        return

    # --- 数据加载 ---
    features = []
    labels = []
    
    with open(input_file, 'r', encoding='utf-8') as f:
        for line in f:
            if not line.strip(): continue
            try:
                item = json.loads(line)
                is_correct = item.get('is_correct')
                if is_correct is None: continue
                feat = extract_advanced_physics_features(item)
                if feat:
                    features.append(feat)
                    labels.append(1 if is_correct else 0)
            except: continue
            
    df = pd.DataFrame(features)
    y = np.array(labels)
    feature_names = df.columns.tolist()
    
    print(f"✅ 样本加载完成: {len(df)} 条")

    # --- 归一化 (使用 MinMax 方便绘图展示 [0,1] 区间) ---
    # 先做一下 Clipping 防止极端值破坏绘图
    for col in df.columns:
        low, high = df[col].quantile([0.01, 0.99])
        df[col] = df[col].clip(low, high)
        
    scaler = MinMaxScaler()
    X_scaled = scaler.fit_transform(df.values)
    df_scaled = pd.DataFrame(X_scaled, columns=feature_names)
    
    # --- 寻找最重要的两个特征 ---
    print("🤖 正在分析特征重要性...")
    clf = GradientBoostingClassifier(n_estimators=200, learning_rate=0.1, max_depth=4, random_state=42)
    clf.fit(X_scaled, y)
    
    importances = clf.feature_importances_
    sorted_idx = np.argsort(importances)[::-1] # 降序
    
    top1_idx = sorted_idx[0]
    top2_idx = sorted_idx[1]
    
    top1_name = feature_names[top1_idx]
    top2_name = feature_names[top2_idx]
    
    print(f"🌟 发现最关键的相分离维度:")
    print(f"   1. X轴: {top1_name} (Importance: {importances[top1_idx]:.4f})")
    print(f"   2. Y轴: {top2_name} (Importance: {importances[top2_idx]:.4f})")
    
    # --- 重新训练仅基于这两个特征的模型 (用于绘制 2D 背景) ---
    X_2d = X_scaled[:, [top1_idx, top2_idx]]
    clf_2d = GradientBoostingClassifier(n_estimators=200, learning_rate=0.1, max_depth=4, random_state=42)
    clf_2d.fit(X_2d, y)
    
    # --- 绘图 ---
    sns.set_style("whitegrid")
    plt.figure(figsize=(12, 10))
    
    # 1. 创建网格背景
    x_min, x_max = -0.1, 1.1
    y_min, y_max = -0.1, 1.1
    xx, yy = np.meshgrid(np.linspace(x_min, x_max, 300),
                         np.linspace(y_min, y_max, 300))
    
    # 预测网格概率
    Z = clf_2d.predict_proba(np.c_[xx.ravel(), yy.ravel()])[:, 1]
    Z = Z.reshape(xx.shape)
    
    # 2. 绘制等高线热力图
    contour = plt.contourf(xx, yy, Z, levels=20, cmap="RdBu", alpha=0.8)
    cbar = plt.colorbar(contour)
    cbar.set_label("Probability of Correctness $P(Correct)$", fontsize=12)
    
    # 决策边界
    plt.contour(xx, yy, Z, levels=[0.5], colors='black', linewidths=2, linestyles='--')
    
    # 3. 绘制数据点
    # Correct
    mask_correct = (y == 1)
    plt.scatter(X_2d[mask_correct, 0], X_2d[mask_correct, 1],
                c='lime', edgecolors='black', s=60, label='Correct CoT', zorder=5)
    
    # Incorrect
    mask_incorrect = (y == 0)
    plt.scatter(X_2d[mask_incorrect, 0], X_2d[mask_incorrect, 1],
                c='red', edgecolors='black', marker='X', s=60, label='Incorrect CoT', zorder=5)
    
    # 4. 装饰
    plt.title(f"Thermodynamic Phase Separation\n({top1_name} vs. {top2_name})", fontsize=16, fontweight='bold')
    plt.xlabel(f"Normalized {top1_name}", fontsize=14, fontweight='bold')
    plt.ylabel(f"Normalized {top2_name}", fontsize=14, fontweight='bold')
    
    # 添加区域注释 (根据一般物理规律推测)
    plt.text(0.9, 0.9, "Crystalline State\n(Rigorous Proof)", ha='center', fontsize=11, fontweight='bold', 
             bbox=dict(facecolor='white', alpha=0.7, edgecolor='none'))
    plt.text(0.1, 0.1, "Turbulent State\n(Confusion)", ha='center', fontsize=11, fontweight='bold', 
             bbox=dict(facecolor='white', alpha=0.7, edgecolor='none'))
    
    plt.legend(loc='lower right', framealpha=0.9)
    plt.xlim(0, 1)
    plt.ylim(0, 1)
    plt.tight_layout()
    
    plt.savefig(output_file, dpi=300)
    print(f"🖼️ 相分离热力图已生成: {output_file}")

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--input_file", type=str, default="energy_collect.jsonl")
    args = parser.parse_args()
    
    plot_auto_phase_diagram(args.input_file)