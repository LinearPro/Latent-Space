import json
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import os
from tqdm import tqdm

def fast_rolling_mean(arr, window_size):
    if len(arr) < window_size: return arr
    pad_front = np.ones(window_size - 1) * arr[0]
    padded_arr = np.concatenate((pad_front, arr))
    return np.convolve(padded_arr, np.ones(window_size)/window_size, mode='valid')

def analyze_vector_divergence_normalized(input_file="metrics.jsonl", window_size=5, grid_bins=18):
    print(f"🚀 启动引力分歧对峙图分析 (归一化方向放大版)...")
    
    if not os.path.exists(input_file):
        print(f"❌ 文件 {input_file} 不存在。")
        return

    C_x, C_y, C_u, C_v = [], [], [], []
    I_x, I_y, I_u, I_v = [], [], [], []
    All_fric, All_incoh = [], []
    
    total_lines = sum(1 for _ in open(input_file, 'r', encoding='utf-8'))
    
    with open(input_file, 'r', encoding='utf-8') as f:
        for line in tqdm(f, total=total_lines, desc="Processing JSONL"):
            if not line.strip(): continue
            try:
                item = json.loads(line)
                d1, d2 = item.get('diff norm1') or item.get('diff norms1'), item.get('diff norm2') or item.get('diff norms2')
                a1, a2 = item.get('angle1'), item.get('angle2')
                if not (d1 and d2 and a1 and a2): continue
                
                fric = np.array(d2) - np.array(d1)
                incoh = np.array(a2) - np.array(a1)
                
                if len(fric) < window_size * 2: continue
                
                end_idx = int(len(fric) * 0.9)
                fric_core = fric[:end_idx]
                incoh_core = incoh[:end_idx]
                
                f_smooth = fast_rolling_mean(fric_core, window_size)
                i_smooth = fast_rolling_mean(incoh_core, window_size)
                
                is_correct = item.get('is_correct', False)
                All_fric.extend(f_smooth)
                All_incoh.extend(i_smooth)
                
                u_vec = f_smooth[1:] - f_smooth[:-1]
                v_vec = i_smooth[1:] - i_smooth[:-1]
                x_vec = f_smooth[:-1]
                y_vec = i_smooth[:-1]
                
                if is_correct:
                    C_x.extend(x_vec); C_y.extend(y_vec)
                    C_u.extend(u_vec); C_v.extend(v_vec)
                else:
                    I_x.extend(x_vec); I_y.extend(y_vec)
                    I_u.extend(u_vec); I_v.extend(v_vec)
            except: continue

    All_fric, All_incoh = np.array(All_fric), np.array(All_incoh)
    proj_coeff = np.dot(All_incoh, All_fric) / np.dot(All_fric, All_fric) if len(All_fric) > 0 else 0

    def apply_ortho(x, y, u, v):
        return np.array(x), np.array(y) - proj_coeff * np.array(x), np.array(u), np.array(v) - proj_coeff * np.array(u)

    C_x_o, C_y_o, C_u_o, C_v_o = apply_ortho(C_x, C_y, C_u, C_v)
    I_x_o, I_y_o, I_u_o, I_v_o = apply_ortho(I_x, I_y, I_u, I_v)

    global_x_min, global_x_max = min(np.min(C_x_o), np.min(I_x_o)), max(np.max(C_x_o), np.max(I_x_o))
    global_y_min, global_y_max = min(np.min(C_y_o), np.min(I_y_o)), max(np.max(C_y_o), np.max(I_y_o))
    x_edges = np.linspace(global_x_min, global_x_max, grid_bins + 1)
    y_edges = np.linspace(global_y_min, global_y_max, grid_bins + 1)

    def get_grid_stats(x, y, u, v):
        count, _, _ = np.histogram2d(x, y, bins=[x_edges, y_edges])
        sum_u, _, _ = np.histogram2d(x, y, bins=[x_edges, y_edges], weights=u)
        sum_v, _, _ = np.histogram2d(x, y, bins=[x_edges, y_edges], weights=v)
        with np.errstate(divide='ignore', invalid='ignore'):
            return count, np.where(count > 0, sum_u / count, 0), np.where(count > 0, sum_v / count, 0)

    count_C, mean_u_C, mean_v_C = get_grid_stats(C_x_o, C_y_o, C_u_o, C_v_o)
    count_I, mean_u_I, mean_v_I = get_grid_stats(I_x_o, I_y_o, I_u_o, I_v_o)

    xc, yc = (x_edges[:-1] + x_edges[1:]) / 2, (y_edges[:-1] + y_edges[1:]) / 2
    X, Y = np.meshgrid(xc, yc, indexing='ij')

    threshold = max(np.max(count_C), np.max(count_I)) * 0.005
    overlap_mask = (count_C > threshold) & (count_I > threshold)

    X_v, Y_v = X[overlap_mask], Y[overlap_mask]
    Uc_v, Vc_v = mean_u_C[overlap_mask], mean_v_C[overlap_mask]
    Ui_v, Vi_v = mean_u_I[overlap_mask], mean_v_I[overlap_mask]

    mag_c = np.hypot(Uc_v, Vc_v)
    mag_i = np.hypot(Ui_v, Vi_v)
    
    dot_product = Uc_v * Ui_v + Vc_v * Vi_v
    with np.errstate(divide='ignore', invalid='ignore'):
        cos_theta = dot_product / (mag_c * mag_i)
        cos_theta = np.clip(np.nan_to_num(cos_theta, nan=1.0), -1.0, 1.0)
    angle_diff = np.arccos(cos_theta) * 180 / np.pi

    # ================= 核心修改：向量长度归一化 =================
    # 将所有的方向向量除以自己的模长，强制变成统一长度的“方向指示针”
    with np.errstate(divide='ignore', invalid='ignore'):
        Uc_norm = np.where(mag_c > 0, Uc_v / mag_c, 0)
        Vc_norm = np.where(mag_c > 0, Vc_v / mag_c, 0)
        Ui_norm = np.where(mag_i > 0, Ui_v / mag_i, 0)
        Vi_norm = np.where(mag_i > 0, Vi_v / mag_i, 0)

    print("🎨 正在渲染高清晰度方向对比图...")
    plt.figure(figsize=(14, 10))
    sns.set_style("whitegrid")

    sc = plt.scatter(X_v, Y_v, c=angle_diff, cmap='Reds', s=800, alpha=0.5, marker='s', label='Divergence Heatmap')
    cbar = plt.colorbar(sc, pad=0.02)
    cbar.set_label('Vector Divergence Angle (Degrees)', fontsize=12, weight='bold')

    plt.scatter(X_v, Y_v, color='black', s=30, zorder=5, label='Shared Coordinate Origin')

    # 使用归一化后的向量绘制，修改 scale 参数让箭头显得修长显眼
    # scale 的值越小，画出来的箭头越长
    vector_scale = 18 
    
    plt.quiver(X_v, Y_v, Uc_norm, Vc_norm, color='blue', alpha=0.8, scale=vector_scale, width=0.005, headwidth=5, label='Correct Direction (Normalized)', zorder=6)
    plt.quiver(X_v, Y_v, Ui_norm, Vi_norm, color='red', alpha=0.8, scale=vector_scale, width=0.005, headwidth=5, label='Incorrect Direction (Normalized)', zorder=7)

    plt.title("Normalized Vector Divergence: Amplified Directional Forces", fontsize=16, fontweight='bold', pad=20)
    plt.xlabel(r"Instant Cognitive Effort ($\Phi_{diss}$)", fontsize=14)
    plt.ylabel(r"Orthogonalized Logical Misalignment ($\mathcal{I}_{\perp}$)", fontsize=14)
    plt.legend(loc='upper right', fontsize=12, framealpha=0.9)

    plt.tight_layout()
    output_filename = "Attractor_Vector_Normalized_Overlay.png"
    plt.savefig(output_filename, dpi=300)
    print(f"\n✅ 渲染完成！所有线段已被强行拉长到相同标准。请查看 {output_filename}。")

if __name__ == "__main__":
    analyze_vector_divergence_normalized("metrics.jsonl")