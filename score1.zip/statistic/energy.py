import json
import numpy as np
import argparse
import os
from tqdm import tqdm

def calculate_energy_metrics(input_file, output_file):
    print(f"⚡ 正在计算动能与湍流内能 (使用纯不一致性定义质量): {input_file} -> {output_file}")
    
    if not os.path.exists(input_file):
        print(f"❌ 错误: 输入文件 {input_file} 不存在。")
        return

    results = []
    
    # 统计计数
    count = 0
    skipped = 0

    with open(input_file, 'r', encoding='utf-8') as f:
        # 读取所有行以显示进度
        lines = f.readlines()
        
    print(f"处理 {len(lines)} 条数据...")
    
    for line in tqdm(lines):
        if not line.strip(): continue
        try:
            item = json.loads(line)
            
            # 获取必要字段
            # d1: diff norms1 (Macro Velocity)
            # d2: diff norms2 (Micro Velocity)
            # a1: angle1 (Macro Angle)
            # a2: angle2 (Micro Angle)
            d1 = item.get('diff norms1') or item.get('diff norm1')
            d2 = item.get('diff norms2') or item.get('diff norm2')
            a1 = item.get('angle1')
            a2 = item.get('angle2')
            
            # 如果缺少任何一个指标，跳过
            if d1 is None or d2 is None or a1 is None or a2 is None:
                skipped += 1
                continue
                
            # 转换为 numpy 数组
            v_macro = np.array(d1, dtype=float) 
            v_micro = np.array(d2, dtype=float)
            angle_macro = np.array(a1, dtype=float)
            angle_micro = np.array(a2, dtype=float)
            
            # 确保长度一致
            min_len = min(len(v_macro), len(v_micro), len(angle_macro), len(angle_micro))
            if min_len == 0:
                skipped += 1
                continue
                
            # 截断到相同长度
            v_macro = v_macro[:min_len]
            v_micro = v_micro[:min_len]
            angle_macro = angle_macro[:min_len]
            angle_micro = angle_micro[:min_len]
            
            # ================= 物理量计算 (Updated) =================
            
            # 1. 纯不一致性 (Pure Incoherence)
            # 定义为层间转向 (angle2) 与 宏观转向 (angle1) 的差值绝对值
            # 代表了剥离了整体方向后的内部结构分歧
            incoherence_pure = np.abs(angle_micro - angle_macro)
            
            # 2. 质量 (Mass) = 1 / (Pure Incoherence + epsilon)
            # 物理含义：逻辑结构越致密（分歧越小），质量越大
            epsilon = 1e-6
            mass = 1.0 / (incoherence_pure + epsilon)
            
            # 3. 动能 (Kinetic Energy, Ek)
            # Ek = 1/2 * m * v_macro^2
            # 代表定向思维流的强度（重装甲部队的冲锋）
            kinetic_energy = 0.5 * mass * (v_macro ** 2)
            
            # 4. 湍流内能 (Turbulent Internal Energy, U_turb)
            # U_turb = 1/2 * m * (v_micro - v_macro)^2
            # 代表微观与宏观的速度差带来的内耗
            turbulent_energy = 0.5 * mass * ((v_micro - v_macro) ** 2)
            
            # ========================================================
            
            # 构建输出对象
            out_item = {
                "is_correct": item.get("is_correct"),
                "kinetic_energy": kinetic_energy.tolist(),
                "turbulent_energy": turbulent_energy.tolist()
            }
            results.append(out_item)
            count += 1
            
        except Exception as e:
            # print(f"处理出错: {e}") # 减少刷屏
            skipped += 1
            continue

    print(f"计算完成。成功: {count}, 跳过/失败: {skipped}")
    print(f"正在写入 {output_file} ...")
    
    with open(output_file, 'w', encoding='utf-8') as f:
        for res in results:
            f.write(json.dumps(res) + "\n")
            
    print("✅ Done.")

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Calculate Energy Metrics with Pure Incoherence Mass")
    parser.add_argument("--input_file", type=str, required=True, help="Input .jsonl file containing metrics")
    parser.add_argument("--output_file", type=str, default="energy.jsonl", help="Output .jsonl file")
    
    args = parser.parse_args()
    
    calculate_energy_metrics(args.input_file, args.output_file)