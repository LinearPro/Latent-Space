# 1. Macro Indicators
    macro_states = macro_sum_states / num_layers
    
    # ================= [新增部分：计算全局向心力 / 目标距离] =================
    # 取该序列最后一个 Token 的宏观状态作为“最终落点（Terminal State）”
    terminal_state = macro_states[-1].unsqueeze(0) # 形状: [1, Hidden]
    
    # 计算所有步骤到最终落点的余弦相似度，并转化为距离 (1 - cos)
    cos_sim_end = F.cosine_similarity(macro_states, terminal_state, dim=-1, eps=1e-8).clamp(-1, 1)
    dist_to_end = (1.0 - cos_sim_end).cpu().numpy() # 转移到 CPU 并转为 numpy 数组
    
    # 为了防止序列过长导致 JSONL 文件过大，直接在这里将其插值压缩为 100 个标准进度点
    orig_steps = np.linspace(0, 100, len(dist_to_end))
    target_steps = np.linspace(0, 100, 100)
    dist_traj = np.interp(target_steps, orig_steps, dist_to_end).tolist()
    # =========================================================================

    macro_diffs = macro_states[1:] - macro_states[:-1]
    # ... (保持你原有的后续代码不变) ...

    # 在函数最后的 metrics 字典中，保存这条轨迹
    metrics = {}
    metrics["dist_trajectory"] = dist_traj  # <--- [新增这行] 将轨迹保存到输出中