import json
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import os

def analyze_aligned_relative_attractor(input_file="metrics.jsonl", window_size=5):
    print("🔬 启动盆地平移观测：消除轨迹绝对偏移，将状态对齐至各自类别（正确/错误）的最终吸引子中心...")
    
    if not os.path.exists(input_file):
        print(f"❌ 文件 {input_file} 不存在。")
        return

    # 用于左图：分别存储各条 CoT 的演化轨迹和最终锚点
    C_trajs_fric, C_trajs_incoh = [], []
    I_trajs_fric, I_trajs_incoh = [], []
    
    C_ends_fric, C_ends_incoh = [], []
    I_ends_fric, I_ends_incoh = [], []
    
    # 用于右图：扣除最终基线后的相对波动率
    C_rel_volatility, I_rel_volatility = [], []
    
    with open(input_file, 'r', encoding='utf-8') as f:
        for line in f:
            if not line.strip(): continue
            try:
                item = json.loads(line)
                if 'diff norm1' in item:
                    item['diff norms1'] = item['diff norm1']
                    item['diff norms2'] = item['diff norm2']
                
                d1, d2 = item.get('diff norms1'), item.get('diff norms2')
                a1, a2 = item.get('angle1'), item.get('angle2')
                if not (d1 and d2 and a1 and a2): continue
                
                fric = np.array(d2) - np.array(d1)
                incoh = np.array(a2) - np.array(a1)
                
                if len(fric) < window_size * 2: continue
                
                # 定义观测区间与收敛区间
                start_idx = 0
                end_idx = int(len(fric) * 0.9)
                
                # 计算该条 CoT 在最后 90-100% 阶段的最终锚点坐标
                cot_end_fric = np.mean(fric[end_idx:])
                cot_end_incoh = np.mean(incoh[end_idx:])
                
                is_correct = item.get('is_correct', False)
                
                # 记录 0-90% 的轨迹以及其对应的最终锚点
                if is_correct:
                    C_trajs_fric.append(fric[start_idx:end_idx])
                    C_trajs_incoh.append(incoh[start_idx:end_idx])
                    C_ends_fric.append(cot_end_fric)
                    C_ends_incoh.append(cot_end_incoh)
                else:
                    I_trajs_fric.append(fric[start_idx:end_idx])
                    I_trajs_incoh.append(incoh[start_idx:end_idx])
                    I_ends_fric.append(cot_end_fric)
                    I_ends_incoh.append(cot_end_incoh)
                
                # --- 右图：局部绝对波动率计算 (保持不变) ---
                df = pd.DataFrame({'f': fric, 'i': incoh})
                rolling_std_f = df['f'].rolling(window=window_size, min_periods=1).std().fillna(0).values
                rolling_std_i = df['i'].rolling(window=window_size, min_periods=1).std().fillna(0).values
                total_volatility = np.sqrt(rolling_std_f**2 + rolling_std_i**2)
                
                orig_steps = np.linspace(0, 100, len(total_volatility))
                target_steps = np.linspace(0, 100, 11)
                vol_interp = np.interp(target_steps, orig_steps, total_volatility)
                
                baseline = np.mean(vol_interp[9:11])
                rel_vol = vol_interp[1:10] - baseline
                
                if is_correct:
                    C_rel_volatility.append(rel_vol)
                else:
                    I_rel_volatility.append(rel_vol)
                    
            except: continue

    # ================= 吸引子宏观中心计算与轨迹平移 =================
    mean_C_end_f = np.mean(C_ends_fric) if C_ends_fric else 0
    mean_C_end_i = np.mean(C_ends_incoh) if C_ends_incoh else 0
    
    mean_I_end_f = np.mean(I_ends_fric) if I_ends_fric else 0
    mean_I_end_i = np.mean(I_ends_incoh) if I_ends_incoh else 0

    C_fric_flat, C_incoh_flat = [], []
    I_fric_flat, I_incoh_flat = [], []

    for traj_f, traj_i, end_f, end_i in zip(C_trajs_fric, C_trajs_incoh, C_ends_fric, C_ends_incoh):
        C_fric_flat.extend(traj_f - end_f + mean_C_end_f)
        C_incoh_flat.extend(traj_i - end_i + mean_C_end_i)

    for traj_f, traj_i, end_f, end_i in zip(I_trajs_fric, I_trajs_incoh, I_ends_fric, I_ends_incoh):
        I_fric_flat.extend(traj_f - end_f + mean_I_end_f)
        I_incoh_flat.extend(traj_i - end_i + mean_I_end_i)

    # ================= 数据抽样与施密特正交化 =================
    max_pts = 10000
    
    len_C = len(C_fric_flat)
    len_I = len(I_fric_flat)
    
    idx_C = np.random.choice(len_C, min(max_pts, len_C), replace=False) if len_C > 0 else []
    idx_I = np.random.choice(len_I, min(max_pts, len_I), replace=False) if len_I > 0 else []

    C_f_plot = np.array(C_fric_flat)[idx_C] if len_C > 0 else np.array([])
    C_i_plot = np.array(C_incoh_flat)[idx_C] if len_C > 0 else np.array([])
    I_f_plot = np.array(I_fric_flat)[idx_I] if len_I > 0 else np.array([])
    I_i_plot = np.array(I_incoh_flat)[idx_I] if len_I > 0 else np.array([])

    X_all = np.concatenate([C_f_plot, I_f_plot]) if len_C > 0 or len_I > 0 else np.array([])
    Y_all = np.concatenate([C_i_plot, I_i_plot]) if len_C > 0 or len_I > 0 else np.array([])

    if len(X_all) > 0 and np.dot(X_all, X_all) != 0:
        proj_coeff = np.dot(Y_all, X_all) / np.dot(X_all, X_all)
        C_f_ortho = C_f_plot
        C_i_ortho = C_i_plot - proj_coeff * C_f_plot
        I_f_ortho = I_f_plot
        I_i_ortho = I_i_plot - proj_coeff * I_f_plot
    else:
        C_f_ortho, C_i_ortho = C_f_plot, C_i_plot
        I_f_ortho, I_i_ortho = I_f_plot, I_i_plot

    # ================= 绘图 =================
    sns.set_style("whitegrid")
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(16, 7))
    fig.suptitle("Attractor Topology: Macroscopic Basin Separation & Convergence Dynamics", fontsize=18, fontweight='bold')

    # --- 左图：平移对齐后的全局状态密度图 ---
    ax1.set_title("Aligned Attractor Basins (Anchored to Final Class Centers)", fontsize=14)
    ax1.set_xlabel(r"Instant Cognitive Effort ($\Phi_{diss}$)", fontsize=12)
    ax1.set_ylabel(r"Orthogonalized Logical Misalignment ($\mathcal{I}_{\perp}$)", fontsize=12)

    # ======= 图层层级修改 =======
    # 1. 先绘制蓝色（Correct），设置较低的 alpha 和 zorder=1，使其作为底层
    if len(C_f_ortho) > 0:
        sns.kdeplot(x=C_f_ortho, y=C_i_ortho, cmap="Blues", fill=True, alpha=0.6, levels=8, ax=ax1, label='Correct Attractor Well', zorder=1)
        
    # 2. 后绘制红色（Incorrect），设置较高的 alpha 和 zorder=2，强制悬浮在蓝色之上
    if len(I_f_ortho) > 0:
        sns.kdeplot(x=I_f_ortho, y=I_i_ortho, cmap="Reds", fill=True, alpha=0.85, levels=8, ax=ax1, label='Incorrect Basin', zorder=2)
    
    handles, labels = ax1.get_legend_handles_labels()
    if handles:
        ax1.legend(handles, labels, loc='upper right')

    # --- 右图：相对波动率演化 ---
    ax2.set_title("Pre-Convergence Volatility (90-100% Baseline Subtracted)", fontsize=14)
    ax2.set_xlabel("CoT Generation Progress Intervals (%)", fontsize=12)
    ax2.set_ylabel(r"Relative Local Volatility ($\Delta$ from Final State)", fontsize=12)

    progress_x = np.linspace(10, 90, 9)
    tick_labels = [f"{0 if x==10 else int(x-9)}-{int(x)}%" for x in progress_x]
    
    # 基准线在最底层
    ax2.axhline(0, color='gray', linestyle=':', linewidth=2, label='90-100% Final State Reference', zorder=0)

    # 同理，将右侧折线图的红色线也强行置于顶层 (zorder=4, 5)
    if len(C_rel_volatility) > 0:
        mean_C_vol = np.mean(C_rel_volatility, axis=0)
        ax2.fill_between(progress_x, mean_C_vol, color='blue', alpha=0.1, zorder=1)
        ax2.plot(progress_x, mean_C_vol, color='blue', linewidth=3, marker='o', markersize=6, label='Correct Path $\Delta V$', zorder=2)

    if len(I_rel_volatility) > 0:
        mean_I_vol = np.mean(I_rel_volatility, axis=0)
        ax2.fill_between(progress_x, mean_I_vol, color='red', alpha=0.15, zorder=3)
        ax2.plot(progress_x, mean_I_vol, color='red', linewidth=3, linestyle='--', marker='s', markersize=6, label='Incorrect Path $\Delta V$', zorder=4)
    
    ax2.set_xticks(progress_x)
    ax2.set_xticklabels(tick_labels, rotation=45, ha='right')
    ax2.legend(loc='upper right')

    plt.tight_layout(rect=[0, 0.03, 1, 0.95])
    output_filename = "Attractor_Aligned_Dynamics_RedOnTop.png"
    plt.savefig(output_filename, dpi=300)
    print(f"\n🖼️ 吸引子平移对齐处理完毕！红色图层已置顶，相图保存为 {output_filename}")

if __name__ == "__main__":
    analyze_aligned_relative_attractor("metrics.jsonl")