import json
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import os

def analyze_absolute_lyapunov_dynamics(input_file="metrics.jsonl", window_size=5):
    print("🔬 启动绝对流形动力学分析：积分还原、MSD演化与宏观局部李雅普诺夫指数(LLE)...")
    
    if not os.path.exists(input_file):
        print(f"❌ 文件 {input_file} 不存在。")
        return

    # 数据容器
    C_msd_trajectories, I_msd_trajectories = [], []
    C_lle, I_lle = [], []
    C_ends_fric, C_ends_incoh = [], []
    I_ends_fric, I_ends_incoh = [], []
    
    num_steps = 100 # 归一化步长
    
    with open(input_file, 'r', encoding='utf-8') as f:
        for line in f:
            if not line.strip(): continue
            try:
                item = json.loads(line)
                d1 = item.get('diff norm1', item.get('diff norms1'))
                d2 = item.get('diff norm2', item.get('diff norms2'))
                a1 = item.get('angle1')
                a2 = item.get('angle2')
                
                if not (d1 and d2 and a1 and a2): continue
                
                # 1. 提取微观速度场
                fric_vel = np.array(d2) - np.array(d1)
                incoh_vel = np.array(a2) - np.array(a1)
                
                total_len = len(fric_vel)
                if total_len < 15: continue # 过滤过短轨迹，保证积分和LLE的计算窗口
                
                # ================= 核心：积分还原绝对位置 =================
                fric_pos = np.cumsum(fric_vel)
                incoh_pos = np.cumsum(incoh_vel)
                # ==========================================================

                is_correct = item.get('is_correct', False)
                
                # 2. 长度归一化插值 (用于图1散点和图2 MSD)
                orig_time = np.linspace(0, 1, total_len)
                norm_time = np.linspace(0, 1, num_steps)
                
                f_interp = np.interp(norm_time, orig_time, fric_pos)
                i_interp = np.interp(norm_time, orig_time, incoh_pos)
                
                # 记录最终终点坐标 (用于图1的终态密度图)
                if is_correct:
                    C_ends_fric.append(f_interp[-1])
                    C_ends_incoh.append(i_interp[-1])
                else:
                    I_ends_fric.append(f_interp[-1])
                    I_ends_incoh.append(i_interp[-1])

                # 3. 计算 MSD (用于图2)
                sd_t = (f_interp - f_interp[0])**2 + (i_interp - i_interp[0])**2
                if is_correct: C_msd_trajectories.append(sd_t)
                else: I_msd_trajectories.append(sd_t)

                # ================= 核心：绝对宏观 LLE 计算 =================
                # 在真实未插值的绝对坐标上，截取末端 70%-100% 收敛窗口
                tail_start_idx = int(total_len * 0.7)
                tail_fric = fric_pos[tail_start_idx:]
                tail_incoh = incoh_pos[tail_start_idx:]
                
                # 该条轨迹的绝对终点中心
                abs_end_fric = np.mean(tail_fric[-3:]) 
                abs_end_incoh = np.mean(tail_incoh[-3:])
                
                eps = 1e-8
                # 计算末端轨迹每一步到绝对收敛中心的物理距离
                distances = np.sqrt((tail_fric - abs_end_fric)**2 + (tail_incoh - abs_end_incoh)**2) + eps
                
                # 计算对数偏离率 λ
                log_ratios = np.log(distances[1:] / distances[:-1])
                log_ratios = log_ratios[~np.isnan(log_ratios) & ~np.isinf(log_ratios)]
                
                if len(log_ratios) > 0:
                    local_lyapunov = np.mean(log_ratios)
                    if is_correct: C_lle.append(local_lyapunov)
                    else: I_lle.append(local_lyapunov)
                            
            except Exception as e: 
                continue

    # MSD 数据汇总
    C_msd_matrix, I_msd_matrix = np.array(C_msd_trajectories), np.array(I_msd_trajectories)
    time_axis = np.linspace(0, 100, num_steps)

    # ================= 绘图 =================
    sns.set_style("whitegrid")
    fig, (ax1, ax2, ax3) = plt.subplots(1, 3, figsize=(24, 7))
    fig.suptitle("Absolute Manifold Lyapunov Dynamics: Probing the True Roots of LLM Hallucinations", fontsize=18, fontweight='bold', y=1.02)

    # --- 图 1：绝对流形上的终态吸引子盆地 (Absolute Attractor Basins) ---
    ax1.set_title("Macroscopic Terminal Basins (Integral Space)", fontsize=14)
    ax1.set_xlabel(r"Cumulative Cognitive Effort ($\int \Phi_{diss} dt$)", fontsize=12)
    ax1.set_ylabel(r"Cumulative Logical Misalignment ($\int \mathcal{I}_{\perp} dt$)", fontsize=12)

    if len(C_ends_fric) > 0:
        sns.kdeplot(x=C_ends_fric, y=C_ends_incoh, cmap="Blues", fill=True, alpha=0.6, levels=8, ax=ax1, label='Correct Terminal Basin', zorder=1)
    if len(I_ends_fric) > 0:
        sns.kdeplot(x=I_ends_fric, y=I_ends_incoh, cmap="Reds", fill=True, alpha=0.85, levels=8, ax=ax1, label='Incorrect Terminal Basin', zorder=2)
    
    handles, labels = ax1.get_legend_handles_labels()
    if handles: ax1.legend(handles, labels, loc='upper left')

    # --- 图 2：绝对均方位移 (MSD) ---
    ax2.set_title("Absolute Mean Squared Displacement (MSD)", fontsize=14)
    ax2.set_xlabel("Generation Progress (%)", fontsize=12)
    ax2.set_ylabel(r"Cumulative Space Divergence $\langle ||\int V dt||^2 \rangle$", fontsize=12)

    if len(I_msd_matrix) > 0:
        I_msd_mean = np.mean(I_msd_matrix, axis=0)
        I_msd_sem = np.std(I_msd_matrix, axis=0) / np.sqrt(len(I_msd_matrix))
        ax2.plot(time_axis, I_msd_mean, color='#D62728', linewidth=3, label='Incorrect Path (Unbounded Escape)')
        ax2.fill_between(time_axis, I_msd_mean - I_msd_sem, I_msd_mean + I_msd_sem, color='#D62728', alpha=0.15)

    if len(C_msd_matrix) > 0:
        C_msd_mean = np.mean(C_msd_matrix, axis=0)
        C_msd_sem = np.std(C_msd_matrix, axis=0) / np.sqrt(len(C_msd_matrix))
        ax2.plot(time_axis, C_msd_mean, color='#1F77B4', linewidth=3, label='Correct Path (Bounded Expansion)')
        ax2.fill_between(time_axis, C_msd_mean - C_msd_sem, C_msd_mean + C_msd_sem, color='#1F77B4', alpha=0.2)
        
        # 添加逻辑约束极限参考线
        plateau_height = np.mean(C_msd_mean[-int(num_steps*0.3):])
        ax2.axhline(y=plateau_height, color='navy', linestyle='--', linewidth=2, alpha=0.6, label='Confinement Limit')

    ax2.set_xlim(0, 100)
    ax2.set_ylim(bottom=0)
    ax2.legend(loc='upper left')

    # --- 图 3：绝对局部李雅普诺夫指数 (Absolute LLE) ---
    ax3.set_title(r"Absolute Local Lyapunov Exponent $\lambda_{abs}$ (Tail 70-100%)", fontsize=14)
    ax3.set_ylabel(r"Macroscopic Divergence Rate ($\lambda_{abs}$)", fontsize=12)
    
    # 过滤极端异常值以保证绘图清晰
    def filter_outliers(data):
        if len(data) == 0: return []
        p2, p98 = np.percentile(data, 2), np.percentile(data, 98)
        return [x for x in data if p2 <= x <= p98]
    
    clean_C_lle = filter_outliers(C_lle)
    clean_I_lle = filter_outliers(I_lle)

    lle_data = pd.DataFrame({
        'LLE': clean_C_lle + clean_I_lle,
        'Trajectory Type': ['Correct (Restoring Force)'] * len(clean_C_lle) + ['Incorrect (Dimensional Collapse)'] * len(clean_I_lle)
    })
    
    if not lle_data.empty:
        sns.violinplot(x='Trajectory Type', y='LLE', data=lle_data, 
                       palette={'Correct (Restoring Force)': '#6BAED6', 'Incorrect (Dimensional Collapse)': '#FB6A4A'}, 
                       inner="quartile", ax=ax3, alpha=0.8)
        
        ax3.axhline(0, color='black', linestyle='--', linewidth=2, label=r'Critical Stability Threshold ($\lambda=0$)')
        
        ymin, ymax = ax3.get_ylim()
        ax3.text(-0.25, ymax * 0.9, 'Macroscopic Convergence\n(Tethered to Main Logic)', 
                 transform=ax3.get_xaxis_transform(), ha='center', color='#08519C', fontsize=11, fontweight='bold')
        ax3.text(1.25, ymax * 0.9, 'Macroscopic Divergence\n(Ballistic Hallucination)', 
                 transform=ax3.get_xaxis_transform(), ha='center', color='#A50F15', fontsize=11, fontweight='bold')
        ax3.legend(loc='lower right')

    plt.tight_layout(rect=[0, 0.03, 1, 0.95])
    output_filename = "Absolute_Manifold_Lyapunov.png"
    plt.savefig(output_filename, dpi=300)
    print(f"\n🖼️ 分析完成！绝对流形李雅普诺夫图表已保存为 {output_filename}")

if __name__ == "__main__":
    analyze_absolute_lyapunov_dynamics("metrics.jsonl")