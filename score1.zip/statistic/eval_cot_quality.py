import json
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from scipy import stats
import argparse
import os

def evaluate_cot_quality(input_file):
    print(f"📊 正在评估 CoT 质量动力学: {input_file} ...")
    
    data = []
    with open(input_file, 'r', encoding='utf-8') as f:
        for line in f:
            if line.strip():
                try:
                    item = json.loads(line)
                    # 确保包含必要字段
                    if 'diff norms1' in item and 'angle1' in item:
                        data.append(item)
                    # 兼容不同命名
                    elif 'diff norm1' in item:
                        item['diff norms1'] = item['diff norm1']
                        item['diff norms2'] = item['diff norm2']
                        data.append(item)
                except: continue

    if not data:
        print("❌ 数据为空")
        return

    # --- 1. 特征提取 ---
    features = []
    for item in data:
        # 提取原始序列
        d1 = np.array(item['diff norms1'])
        d2 = np.array(item['diff norms2'])
        a1 = np.array(item['angle1'])
        a2 = np.array(item['angle2'])
        
        # 计算核心指标序列
        friction_seq = d2 - d1
        incoh_seq = a2 - a1
        
        seq_len = len(friction_seq)
        if seq_len < 10: continue

        # --- 定义关键特征 ---
        
        # A. 整体努力程度 (Total Cognitive Effort)
        # 使用中位数或平均数，剔除极端异常值的影响
        mean_friction = np.mean(friction_seq)
        
        # B. 最终收敛度 (Final Convergence)
        # 取最后 15% 的片段，看是否"对齐"
        end_window = max(5, int(seq_len * 0.15))
        final_incoherence = np.mean(incoh_seq[-end_window:])
        
        # C. 逻辑稳定性 (Stability)
        # 不一致性的标准差，越低越稳
        incoh_stability = np.std(incoh_seq)
        
        # D. 峰值认知强度 (Peak Intensity)
        # 前 95% 分位数，代表 System 2 介入的最强时刻
        peak_friction = np.percentile(friction_seq, 95)

        features.append({
            'is_correct': "Correct" if item.get('is_correct', False) else "Incorrect",
            'Mean_Friction': mean_friction,
            'Final_Incoherence': final_incoherence,
            'Incoh_Stability': incoh_stability,
            'Peak_Friction': peak_friction,
            'Length': seq_len
        })

    df = pd.DataFrame(features)
    
    # --- 2. 统计检验 ---
    print("\nTotal Samples:", len(df))
    print("Correct:", len(df[df['is_correct']=="Correct"]))
    print("Incorrect:", len(df[df['is_correct']=="Incorrect"]))
    
    # 计算差异显著性 (T-test)
    print("\n--- Statistical Significance (T-test) ---")
    for metric in ['Mean_Friction', 'Final_Incoherence', 'Peak_Friction']:
        correct_vals = df[df['is_correct']=="Correct"][metric]
        wrong_vals = df[df['is_correct']=="Incorrect"][metric]
        
        t_stat, p_val = stats.ttest_ind(correct_vals, wrong_vals, equal_var=False)
        print(f"{metric}: p-value = {p_val:.5f} {'(Significant)' if p_val < 0.05 else ''}")
        print(f"   Avg Correct: {correct_vals.mean():.2f} vs Avg Incorrect: {wrong_vals.mean():.2f}")

    # --- 3. 可视化 (NeurIPS Style) ---
    plot_evaluation_charts(df)

def plot_evaluation_charts(df):
    sns.set_style("whitegrid")
    sns.set_context("paper", font_scale=1.4)
    
    fig, axes = plt.subplots(1, 2, figsize=(14, 6))
    
    # 颜色映射
    palette = {"Correct": "#1f77b4", "Incorrect": "#d62728"}
    
    # 图 1: 内摩擦 (越努力越幸运？)
    sns.violinplot(x='is_correct', y='Mean_Friction', data=df, ax=axes[0], palette=palette, inner='quartile')
    axes[0].set_title("Cognitive Effort Distribution\n(Internal Friction)", fontweight='bold')
    axes[0].set_ylabel("Mean Internal Friction")
    axes[0].set_xlabel("Answer Correctness")
    
    # 图 2: 不一致性 (越对齐越正确？)
    # 注意：我们关注的是 Final Incoherence
    sns.violinplot(x='is_correct', y='Final_Incoherence', data=df, ax=axes[1], palette=palette, inner='quartile')
    axes[1].set_title("Logical Convergence State\n(Final Incoherence)", fontweight='bold')
    axes[1].set_ylabel("Incoherence (Last 15% Tokens)")
    axes[1].set_xlabel("Answer Correctness")
    
    plt.tight_layout()
    plt.savefig("CoT_Quality_Evaluation.png", dpi=300)
    print("\n🖼️ 评估图表已保存: CoT_Quality_Evaluation.png")
    
    # --- 4. 散点图：构建质量判别平面 ---
    plt.figure(figsize=(8, 7))
    sns.scatterplot(data=df, x='Mean_Friction', y='Final_Incoherence', 
                    hue='is_correct', style='is_correct', 
                    palette=palette, alpha=0.7, s=80)
    
    plt.title("The 'Thermodynamic Health' Plane", fontweight='bold')
    plt.xlabel("Cognitive Effort (Mean Friction) $\\rightarrow$")
    plt.ylabel("Logical Misalignment (Final Incoherence) $\\leftarrow$")
    # 反转 Y 轴，因为不一致性越低越好，放在上面直观
    plt.gca().invert_yaxis()
    
    # 划分理想区域
    plt.axvline(x=df['Mean_Friction'].median(), color='gray', linestyle='--', alpha=0.5)
    plt.axhline(y=df['Final_Incoherence'].median(), color='gray', linestyle='--', alpha=0.5)
    
    plt.text(df['Mean_Friction'].max()*0.9, df['Final_Incoherence'].min(), "Ideal State:\nHigh Effort\nHigh Alignment", 
             ha='right', va='top', bbox=dict(facecolor='green', alpha=0.1))
    
    plt.tight_layout()
    plt.savefig("Thermodynamic_Health_Plane.png", dpi=300)
    print("🖼️ 判别平面图已保存: Thermodynamic_Health_Plane.png")

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--input_file", type=str, default="aime2024_2025_score.jsonl")
    args = parser.parse_args()
    
    if os.path.exists(args.input_file):
        evaluate_cot_quality(args.input_file)
    else:
        print("请提供正确的文件路径")