import json
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import PolynomialFeatures, MinMaxScaler
from sklearn.pipeline import make_pipeline

# ================= 配置区域 =================
INPUT_FILE = 'metrics.jsonl'            # 原始数据文件
OUTPUT_IMG = 'Phase_Diagram_Last10.png' # 输出图片名
# ===========================================

def extract_last_10pct_metrics(row):
    """
    核心逻辑：从完整序列中截取最后 10% 并计算均值
    """
    # 1. 尝试获取序列数据 (假设是列表)
    # 如果您的 json key 不同，请在此修改
    a1_seq = row.get('angle1', [])
    a2_seq = row.get('angle2', [])
    d1_seq = row.get('diff norms1', [])
    d2_seq = row.get('diff norms2', [])
    
    # 2. 检查数据有效性
    # 确保所有必需字段都是列表且非空
    if not (isinstance(a1_seq, list) and isinstance(d1_seq, list)):
        # 如果不是列表（可能是标量），则直接返回标量差值作为回退
        # 这兼容了只有汇总数据的情况
        try:
            fric = float(row.get('diff norms2', 0)) - float(row.get('diff norms1', 0))
            incoh = float(row.get('angle2', 0)) - float(row.get('angle1', 0))
            return fric, incoh
        except:
            return None, None

    n = len(a1_seq)
    if n < 5: return None, None # 序列太短忽略
        
    # 3. 截取最后 10%
    cut_idx = int(n * 0.90)
    if cut_idx == n: cut_idx = n - 1 # 至少保留一个点
    
    # 转换为 numpy 数组以便计算
    a1_slice = np.array(a1_seq[cut_idx:])
    a2_slice = np.array(a2_seq[cut_idx:])
    d1_slice = np.array(d1_seq[cut_idx:])
    d2_slice = np.array(d2_seq[cut_idx:])
    
    # 4. 计算热力学指标
    # Internal Friction = Micro Energy (D2) - Macro Energy (D1)
    # Incoherence = Micro Direction (A2) - Macro Direction (A1)
    
    fric_val = np.mean(d2_slice - d1_slice)
    incoh_val = np.mean(a2_slice - a1_slice)
    
    return fric_val, incoh_val

def main():
    print(f"🔄 正在读取原始文件: {INPUT_FILE} ...")
    
    data = []
    try:
        with open(INPUT_FILE, 'r', encoding='utf-8') as f:
            for line in f:
                if not line.strip(): continue
                item = json.loads(line)
                
                # 必须包含正确性标签
                if 'is_correct' not in item: continue
                
                # 提取指标
                f_val, i_val = extract_last_10pct_metrics(item)
                
                if f_val is not None:
                    data.append({
                        'is_correct': int(item['is_correct']),
                        'fric': f_val,
                        'incoh': i_val
                    })
    except FileNotFoundError:
        print(f"❌ 错误: 找不到文件 {INPUT_FILE}")
        return

    if not data:
        print("❌ 未提取到有效数据，请检查文件格式。")
        return

    df = pd.DataFrame(data)
    print(f"✅ 成功提取 {len(df)} 条样本。")
    print(f"   摩擦力 (Friction) 均值: {df['fric'].mean():.4f}")
    print(f"   不一致性 (Incoherence) 均值: {df['incoh'].mean():.4f}")

    # --- 归一化处理 ---
    print("⚖️ 正在归一化数据...")
    scaler = MinMaxScaler()
    df[['fric_norm', 'incoh_norm']] = scaler.fit_transform(df[['fric', 'incoh']])

    # --- 训练决策边界 ---
    print("🚀 拟合热力学边界...")
    X = df[['fric_norm', 'incoh_norm']].values
    y = df['is_correct'].values

    model = make_pipeline(
        PolynomialFeatures(degree=2, include_bias=False),
        LogisticRegression(C=1.0)
    )
    model.fit(X, y)
    acc = model.score(X, y)

    # --- 绘图 ---
    print("🎨 正在绘制相图...")
    sns.set_style("whitegrid")
    plt.figure(figsize=(10, 8))

    # 1. 绘制背景等高线
    x_min, x_max = -0.1, 1.1
    y_min, y_max = -0.1, 1.1
    xx, yy = np.meshgrid(np.linspace(x_min, x_max, 200), np.linspace(y_min, y_max, 200))
    Z = model.predict_proba(np.c_[xx.ravel(), yy.ravel()])[:, 1].reshape(xx.shape)
    
    plt.contourf(xx, yy, Z, levels=20, cmap="RdBu", alpha=0.6)
    plt.colorbar(label="Probability of Correctness")
    plt.contour(xx, yy, Z, levels=[0.5], colors='black', linewidths=2, linestyles='--')

    # 2. 绘制散点
    plt.scatter(X[y==1, 0], X[y==1, 1], c='white', edgecolors='#1f77b4', s=60, label='Correct')
    plt.scatter(X[y==0, 0], X[y==0, 1], c='white', edgecolors='#d62728', s=60, marker='X', label='Incorrect')

    # 3. 标注
    plt.title(f"Thermodynamic Phase Diagram (Last 10% Sequence)\nAccuracy: {acc:.1%}", fontweight='bold')
    plt.xlabel("Normalized Friction ($\Phi$)")
    plt.ylabel("Normalized Incoherence ($\mathcal{I}$)")
    plt.legend(loc='lower right')
    
    plt.tight_layout()
    plt.savefig(OUTPUT_IMG, dpi=300)
    print(f"🖼️ 图片已保存至: {OUTPUT_IMG}")

if __name__ == "__main__":
    main()