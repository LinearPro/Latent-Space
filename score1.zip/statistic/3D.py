import json
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import os
from tqdm import tqdm  # 引入进度条

# 纯 Numpy 实现的高速滑动平均 (替代极慢的 Pandas DataFrame)
def fast_rolling_mean(arr, window_size):
    if len(arr) < window_size:
        return arr  # 数组太短不平滑
    # 使用卷积实现滑动平均，mode='valid' 配合首尾 padding 模拟 min_periods=1 的效果
    pad_front = np.ones(window_size - 1) * arr[0]
    padded_arr = np.concatenate((pad_front, arr))
    return np.convolve(padded_arr, np.ones(window_size)/window_size, mode='valid')

def analyze_phase_space_vector_flow_optimized(input_file="metrics.jsonl", window_size=5, grid_bins=25):
    print(f"🚀 启动高速相空间流场分析 (网格 {grid_bins}x{grid_bins})...")
    
    if not os.path.exists(input_file):
        print(f"❌ 文件 {input_file} 不存在。")
        return

    C_x, C_y, C_u, C_v = [], [], [], []
    I_x, I_y, I_u, I_v = [], [], [], []
    All_fric, All_incoh = [], []
    
    # 统计文件总行数以便显示进度条
    total_lines = sum(1 for _ in open(input_file, 'r', encoding='utf-8'))
    
    print("⏳ 正在高速解析与计算向量场...")
    with open(input_file, 'r', encoding='utf-8') as f:
        for line in tqdm(f, total=total_lines, desc="Processing JSONL"):
            if not line.strip(): continue
            try:
                item = json.loads(line)
                d1, d2 = item.get('diff norm1') or item.get('diff norms1'), item.get('diff norm2') or item.get('diff norms2')
                a1, a2 = item.get('angle1'), item.get('angle2')
                if not (d1 and d2 and a1 and a2): continue
                
                fric = np.array(d2) - np.array(d1)
                incoh = np.array(a2) - np.array(a1)
                
                if len(fric) < window_size * 2: continue
                
                # 提取 0-90% 主体阶段
                end_idx = int(len(fric) * 0.9)
                fric_core = fric[:end_idx]
                incoh_core = incoh[:end_idx]
                
                # 使用 numpy 极速平滑
                f_smooth = fast_rolling_mean(fric_core, window_size)
                i_smooth = fast_rolling_mean(incoh_core, window_size)
                
                is_correct = item.get('is_correct', False)
                
                All_fric.extend(f_smooth)
                All_incoh.extend(i_smooth)
                
                # 使用 Numpy 向量化计算差分 (导数/动量)，替代慢速 for 循环
                u_vec = f_smooth[1:] - f_smooth[:-1]
                v_vec = i_smooth[1:] - i_smooth[:-1]
                x_vec = f_smooth[:-1]
                y_vec = i_smooth[:-1]
                
                if is_correct:
                    C_x.extend(x_vec); C_y.extend(y_vec)
                    C_u.extend(u_vec); C_v.extend(v_vec)
                else:
                    I_x.extend(x_vec); I_y.extend(y_vec)
                    I_u.extend(u_vec); I_v.extend(v_vec)
                        
            except: continue

    # ================= 施密特正交化 (保持不变) =================
    print("📐 正在进行施密特正交化投影...")
    All_fric = np.array(All_fric)
    All_incoh = np.array(All_incoh)
    
    if len(All_fric) > 0 and np.dot(All_fric, All_fric) != 0:
        proj_coeff = np.dot(All_incoh, All_fric) / np.dot(All_fric, All_fric)
    else:
        proj_coeff = 0

    def apply_orthogonalization(x, y, u, v):
        x_o = np.array(x)
        y_o = np.array(y) - proj_coeff * np.array(x)
        u_o = np.array(u)
        v_o = np.array(v) - proj_coeff * np.array(u)
        return x_o, y_o, u_o, v_o

    C_x_o, C_y_o, C_u_o, C_v_o = apply_orthogonalization(C_x, C_y, C_u, C_v)
    I_x_o, I_y_o, I_u_o, I_v_o = apply_orthogonalization(I_x, I_y, I_u, I_v)

    # ================= 计算网格流场 (保持不变) =================
    print("🌊 正在计算宏观流场张量...")
    global_x_min = min(np.min(C_x_o), np.min(I_x_o))
    global_x_max = max(np.max(C_x_o), np.max(I_x_o))
    global_y_min = min(np.min(C_y_o), np.min(I_y_o))
    global_y_max = max(np.max(C_y_o), np.max(I_y_o))
    
    x_edges = np.linspace(global_x_min, global_x_max, grid_bins + 1)
    y_edges = np.linspace(global_y_min, global_y_max, grid_bins + 1)

    def calc_flow_grid(x, y, u, v):
        count, _, _ = np.histogram2d(x, y, bins=[x_edges, y_edges])
        sum_u, _, _ = np.histogram2d(x, y, bins=[x_edges, y_edges], weights=u)
        sum_v, _, _ = np.histogram2d(x, y, bins=[x_edges, y_edges], weights=v)
        
        with np.errstate(divide='ignore', invalid='ignore'):
            mean_u = np.where(count > 0, sum_u / count, 0)
            mean_v = np.where(count > 0, sum_v / count, 0)
            
        xc = (x_edges[:-1] + x_edges[1:]) / 2
        yc = (y_edges[:-1] + y_edges[1:]) / 2
        X, Y = np.meshgrid(xc, yc, indexing='ij')
        
        mask = count > (np.max(count) * 0.01)
        return X[mask], Y[mask], mean_u[mask], mean_v[mask]

    C_X, C_Y, C_U, C_V = calc_flow_grid(C_x_o, C_y_o, C_u_o, C_v_o)
    I_X, I_Y, I_U, I_V = calc_flow_grid(I_x_o, I_y_o, I_u_o, I_v_o)

    # ================= 降采样绘图防卡死 =================
    print("🎨 正在渲染图像...")
    sns.set_style("white")
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(18, 8), sharex=True, sharey=True)
    fig.suptitle("Phase Space Vector Flow: Disentangling Attractor Gravity Forces", fontsize=18, fontweight='bold')

    for ax in [ax1, ax2]:
        ax.set_xlabel(r"Instant Cognitive Effort ($\Phi_{diss}$)", fontsize=12)
        ax.set_ylabel(r"Orthogonalized Logical Misalignment ($\mathcal{I}_{\perp}$)", fontsize=12)
        ax.grid(True, linestyle='--', alpha=0.5)

    # KDE 绘图降采样：最多只取 10000 个点画背景轮廓，防止卡死
    max_kde_points = 10000
    idx_c = np.random.choice(len(C_x_o), min(max_kde_points, len(C_x_o)), replace=False) if len(C_x_o) > 0 else []
    idx_i = np.random.choice(len(I_x_o), min(max_kde_points, len(I_x_o)), replace=False) if len(I_x_o) > 0 else []

    # --- 左图：正确轨迹 ---
    ax1.set_title("Correct Path Dynamics: Convergent Flow Field", fontsize=14)
    if len(idx_c) > 0:
        sns.kdeplot(x=C_x_o[idx_c], y=C_y_o[idx_c], cmap="Blues", fill=True, alpha=0.3, levels=5, ax=ax1)
    ax1.quiver(C_X, C_Y, C_U, C_V, color='darkblue', alpha=0.8, angles='xy', scale_units='xy', scale=0.5, headwidth=4)

    # --- 右图：错误轨迹 ---
    ax2.set_title("Incorrect Path Dynamics: Divergent / Misled Flow Field", fontsize=14)
    if len(idx_i) > 0:
        sns.kdeplot(x=I_x_o[idx_i], y=I_y_o[idx_i], cmap="Reds", fill=True, alpha=0.3, levels=5, ax=ax2)
    ax2.quiver(I_X, I_Y, I_U, I_V, color='darkred', alpha=0.8, angles='xy', scale_units='xy', scale=0.5, headwidth=4)

    plt.tight_layout(rect=[0, 0.03, 1, 0.95])
    output_filename = "Attractor_Vector_Flow_Turbo.png"
    plt.savefig(output_filename, dpi=300)
    print(f"\n✅ 渲染极速完成！图片已保存为 {output_filename}")

if __name__ == "__main__":
    analyze_phase_space_vector_flow_optimized("metrics.jsonl")