import json
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import os

def analyze_coarse_grained_attractor(input_file="metrics.jsonl", n_bins=11, window_size=5):
    # n_bins=11 意味着从 0 到 100，步长恰好为 10%
    print(f"🔬 启动粗粒化统计力学观测：时间分辨率降至 10% (共 {n_bins} 个节点)...")
    
    if not os.path.exists(input_file):
        print(f"❌ 文件 {input_file} 不存在。")
        return

    # 用于实验1：打散的所有瞬间状态
    C_fric_flat, C_incoh_flat = [], []
    I_fric_flat, I_incoh_flat = [], []
    
    # 用于实验2：对齐后的局部波动率
    C_volatility, I_volatility = [], []
    
    with open(input_file, 'r', encoding='utf-8') as f:
        for line in f:
            if not line.strip(): continue
            try:
                item = json.loads(line)
                if 'diff norm1' in item:
                    item['diff norms1'] = item['diff norm1']
                    item['diff norms2'] = item['diff norm2']
                
                d1, d2 = item.get('diff norms1'), item.get('diff norms2')
                a1, a2 = item.get('angle1'), item.get('angle2')
                if not (d1 and d2 and a1 and a2): continue
                
                fric = np.array(d2) - np.array(d1)
                incoh = np.array(a2) - np.array(a1)
                
                if len(fric) < window_size * 2: continue
                
                start_idx = int(len(fric) * 0.1)
                end_idx = int(len(fric) * 0.9)
                
                is_correct = item.get('is_correct', False)
                
                if is_correct:
                    C_fric_flat.extend(fric[start_idx:end_idx])
                    C_incoh_flat.extend(incoh[start_idx:end_idx])
                else:
                    I_fric_flat.extend(fric[start_idx:end_idx])
                    I_incoh_flat.extend(incoh[start_idx:end_idx])
                
                # 计算局部波动率
                df = pd.DataFrame({'f': fric, 'i': incoh})
                rolling_std_f = df['f'].rolling(window=window_size, min_periods=1).std().fillna(0).values
                rolling_std_i = df['i'].rolling(window=window_size, min_periods=1).std().fillna(0).values
                total_volatility = np.sqrt(rolling_std_f**2 + rolling_std_i**2)
                
                # 按照 10% 的步长进行粗粒化插值
                orig_steps = np.linspace(0, 100, len(total_volatility))
                target_steps = np.linspace(0, 100, n_bins)
                vol_interp = np.interp(target_steps, orig_steps, total_volatility)
                
                if is_correct:
                    C_volatility.append(vol_interp)
                else:
                    I_volatility.append(vol_interp)
                    
            except: continue

    # ================= 数据抽样与施密特正交化 =================
    max_pts = 10000
    
    # 增加安全性检查，防止数组为空导致错误
    len_C = len(C_fric_flat)
    len_I = len(I_fric_flat)
    
    idx_C = np.random.choice(len_C, min(max_pts, len_C), replace=False) if len_C > 0 else []
    idx_I = np.random.choice(len_I, min(max_pts, len_I), replace=False) if len_I > 0 else []

    C_f_plot = np.array(C_fric_flat)[idx_C] if len_C > 0 else np.array([])
    C_i_plot = np.array(C_incoh_flat)[idx_C] if len_C > 0 else np.array([])
    I_f_plot = np.array(I_fric_flat)[idx_I] if len_I > 0 else np.array([])
    I_i_plot = np.array(I_incoh_flat)[idx_I] if len_I > 0 else np.array([])

    # 合并数据以计算全局投影系数，保持统一的正交基
    X_all = np.concatenate([C_f_plot, I_f_plot]) if len_C > 0 or len_I > 0 else np.array([])
    Y_all = np.concatenate([C_i_plot, I_i_plot]) if len_C > 0 or len_I > 0 else np.array([])

    # 施密特正交化过程 (Gram-Schmidt)
    # 设 u1 = X, u2 = Y - proj_X(Y)
    if len(X_all) > 0 and np.dot(X_all, X_all) != 0:
        proj_coeff = np.dot(Y_all, X_all) / np.dot(X_all, X_all)
        
        # 生成正交化后的坐标
        C_f_ortho = C_f_plot  # 横坐标不变
        C_i_ortho = C_i_plot - proj_coeff * C_f_plot  # 纵坐标减去其在横坐标上的投影
        
        I_f_ortho = I_f_plot
        I_i_ortho = I_i_plot - proj_coeff * I_f_plot
    else:
        C_f_ortho, C_i_ortho = C_f_plot, C_i_plot
        I_f_ortho, I_i_ortho = I_f_plot, I_i_plot

    # ================= 绘图 =================
    sns.set_style("whitegrid")
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(16, 7))
    fig.suptitle("Coarse-Grained Dynamics: 10% Resolution Fluctuation Analysis", fontsize=18, fontweight='bold')

    # --- 左图：全局状态密度图 (正交化后) ---
    ax1.set_title("State Occupation Probability (Orthogonalized Heatmap)", fontsize=14)
    # 修改了坐标轴标签以反映正交化
    ax1.set_xlabel(r"Instant Cognitive Effort ($\Phi_{diss}$)", fontsize=12)
    ax1.set_ylabel(r"Orthogonalized Logical Misalignment ($\mathcal{I}_{\perp}$)", fontsize=12)

    if len(I_f_ortho) > 0:
        sns.kdeplot(x=I_f_ortho, y=I_i_ortho, cmap="Reds", fill=True, alpha=0.5, levels=8, ax=ax1, label='Incorrect Regime')
    if len(C_f_ortho) > 0:
        sns.kdeplot(x=C_f_ortho, y=C_i_ortho, cmap="Blues", fill=True, alpha=0.7, levels=8, ax=ax1, label='Correct Attractor Well')
    
    handles, labels = ax1.get_legend_handles_labels()
    if handles:
        ax1.legend(handles, labels, loc='upper right')

    # --- 右图：10% 粗粒化涨落演化 ---
    ax2.set_title("System Volatility vs. Progress (10% Steps)", fontsize=14)
    ax2.set_xlabel("CoT Generation Progress (%)", fontsize=12)
    ax2.set_ylabel("Local Volatility (Rolling Std Dev)", fontsize=12)

    progress_x = np.linspace(0, 100, n_bins)
    
    if len(C_volatility) > 0:
        mean_C_vol = np.mean(C_volatility, axis=0)
        ax2.plot(progress_x, mean_C_vol, color='blue', linewidth=3, marker='o', markersize=6, label='Correct Path Volatility')
        ax2.fill_between(progress_x, mean_C_vol, color='blue', alpha=0.1)

    if len(I_volatility) > 0:
        mean_I_vol = np.mean(I_volatility, axis=0)
        ax2.plot(progress_x, mean_I_vol, color='red', linewidth=3, linestyle='--', marker='s', markersize=6, label='Incorrect Path Volatility')
        ax2.fill_between(progress_x, mean_I_vol, color='red', alpha=0.1)
    
    # 设置 X 轴刻度为 10 的倍数，以便与 10% 的步长完全对齐
    ax2.set_xticks(np.arange(0, 105, 10))
    ax2.legend(loc='upper left')

    plt.tight_layout(rect=[0, 0.03, 1, 0.95])
    plt.savefig("Attractor_Coarse_Grained_Proof_10pct.png", dpi=300)
    print("\n🖼️ 施密特正交化处理完毕，10% 粗粒化相图已保存为 Attractor_Coarse_Grained_Proof_10pct.png")

if __name__ == "__main__":
    analyze_coarse_grained_attractor("metrics.jsonl")