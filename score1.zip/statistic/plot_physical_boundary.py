import json
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import PolynomialFeatures, StandardScaler
from sklearn.pipeline import make_pipeline
from sklearn.model_selection import train_test_split
import argparse
import os

def plot_physical_boundary_with_score(input_file):
    print(f"⚖️ 正在进行物理指标评估与相图绘制: {input_file} ...")
    
    # 1. 数据加载与清洗
    data = []
    # 尝试读取文件
    if not os.path.exists(input_file):
        print(f"❌ 错误: 文件 {input_file} 不存在。请确保使用的是包含正负样本的全量数据文件。")
        return

    with open(input_file, 'r', encoding='utf-8') as f:
        for line in f:
            if not line.strip(): continue
            try:
                item = json.loads(line)
                # 兼容不同命名
                if 'diff norm1' in item:
                    item['diff norms1'] = item['diff norm1']
                    item['diff norms2'] = item['diff norm2']
                
                # 必须有正确性标签
                if 'is_correct' in item:
                    data.append(item)
            except: continue

    # 提取特征
    X_list, y_list = [], []
    callback_data = []  # <--- [修改点] 用于存储待保存的数据

    for item in data:
        try:
            d1 = item.get('diff norms1')
            d2 = item.get('diff norms2')
            a1 = item.get('angle1')
            a2 = item.get('angle2')
            if not (d1 and d2 and a1 and a2): continue
            
            fric = np.array(d2) - np.array(d1)
            incoh = np.array(a2) - np.array(a1)
            
            if len(fric) < 5: continue
            
            # 特征 1: 认知努力 (Mean Friction)
            mean_fric = np.mean(fric)
            # 特征 2: 逻辑未对齐 (Final Incoherence - 取最后 10%)
            final_incoh = np.mean(incoh[int(len(incoh)*0.90):])
            
            label = 1 if item.get('is_correct', False) else 0
            
            # <--- [修改点] 收集需要保存的数据
            # 注意：将 numpy 类型转换为 python 原生类型，防止 json 序列化报错
            callback_record = {
                "is_correct": bool(label),
                "mean_fric": float(mean_fric),
                "final_incoh": float(final_incoh)
            }
            callback_data.append(callback_record)
            # ------------------------------------

            X_list.append([mean_fric, final_incoh])
            y_list.append(label)
        except: continue
        
    # <--- [修改点] 将收集的数据写入 callback.jsonl
    output_callback_file = "callback.jsonl"
    print(f"💾 正在保存特征数据到 {output_callback_file} ...")
    with open(output_callback_file, 'w', encoding='utf-8') as f:
        for record in callback_data:
            f.write(json.dumps(record) + "\n")
    print(f"✅ 保存完成，共 {len(callback_data)} 条记录。")
    # ----------------------------------------------

    X = np.array(X_list)
    y = np.array(y_list)
    
    # 检查数据分布
    n_correct = np.sum(y == 1)
    n_incorrect = np.sum(y == 0)
    print(f"📊 数据概览: 总样本 {len(y)}, 正确 {n_correct}, 错误 {n_incorrect}")
    
    if n_correct < 10 or n_incorrect < 10:
        print("❌ 错误：数据中正负样本不平衡或数量过少，无法计算有效准确率。")
        print("请务必使用全量数据 (aime2024_2025_score.jsonl) 而非筛选后的 micro 文件。")
        return

    # 2. 训练物理约束模型与计算准确率
    # 使用 2次多项式逻辑回归
    model = make_pipeline(
        StandardScaler(),
        PolynomialFeatures(degree=2, include_bias=False),
        LogisticRegression(C=1.0, penalty='l2')
    )
    
    # 简单切分训练测试集以计算验证准确率
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    model.fit(X_train, y_train)
    
    accuracy = model.score(X_test, y_test)
    print(f"\n🚀 SOTA Check: Unsupervised Physical Metric Accuracy = {accuracy:.2%}")

    # 用全量数据再拟合一次用于画图 (边界更平滑)
    model.fit(X, y)

    # 3. 绘制相图
    sns.set_style("whitegrid")
    plt.figure(figsize=(10, 8))
    
    # 去除画图用的极端值
    df_temp = pd.DataFrame(X, columns=['Friction', 'Incoherence'])
    mask = (df_temp['Friction'] < df_temp['Friction'].quantile(0.98)) & \
           (df_temp['Incoherence'] < df_temp['Incoherence'].quantile(0.98))
    X_plot = X[mask]
    y_plot = y[mask]
    
    # 创建网格
    x_min, x_max = X_plot[:, 0].min() - 1, X_plot[:, 0].max() + 1
    y_min, y_max = X_plot[:, 1].min() - 0.5, X_plot[:, 1].max() + 0.5
    xx, yy = np.meshgrid(np.linspace(x_min, x_max, 200), np.linspace(y_min, y_max, 200))
    
    # 预测概率
    Z = model.predict_proba(np.c_[xx.ravel(), yy.ravel()])[:, 1]
    Z = Z.reshape(xx.shape)

    # 绘制等高线
    contour = plt.contourf(xx, yy, Z, levels=20, cmap="RdBu", alpha=0.6)
    cbar = plt.colorbar(contour)
    cbar.set_label("Probability of Correctness $P(Correct)$", fontsize=12)

    # 绘制 50% 决策边界
    plt.contour(xx, yy, Z, levels=[0.5], colors='black', linewidths=2.5, linestyles='--')

    # 绘制散点
    plt.scatter(X_plot[y_plot==1, 0], X_plot[y_plot==1, 1], c='white', edgecolors='#1f77b4', s=50, label='Correct', alpha=0.8, linewidth=1.5)
    plt.scatter(X_plot[y_plot==0, 0], X_plot[y_plot==0, 1], c='white', edgecolors='#d62728', s=50, marker='X', label='Incorrect', alpha=0.8, linewidth=1.5)

    # 4. 在图上标注准确率
    plt.text(x_min + (x_max-x_min)*0.05, y_max*0.95, 
             f"Prediction Accuracy: {accuracy:.1%}", 
             fontsize=14, fontweight='bold', color='black',
             bbox=dict(facecolor='yellow', alpha=0.9, edgecolor='black', boxstyle='round,pad=0.5'))

    plt.title("Thermodynamic Phase Diagram with Predictive Score", fontsize=15, fontweight='bold', pad=20)
    plt.xlabel(r"Cognitive Effort ($\bar{\Phi}_{diss}$)", fontsize=12, fontweight='bold')
    plt.ylabel(r"Logical Misalignment ($\mathcal{I}_{final}$)", fontsize=12, fontweight='bold')

    plt.legend(loc='lower right', framealpha=0.9)
    plt.xlim(x_min, x_max)
    plt.ylim(y_min, y_max)
    plt.tight_layout()
    
    output_file = "Physical_Boundary_With_Score.png"
    plt.savefig(output_file, dpi=300)
    print(f"🖼️ 带分数的相图已生成: {output_file}")

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--input_file", type=str, default="metrics.jsonl")
    args = parser.parse_args()
    
    plot_physical_boundary_with_score(args.input_file)