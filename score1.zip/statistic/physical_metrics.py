import json
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.metrics import roc_auc_score

def analyze_gibbs_free_energy(input_file):
    print(f"🔥 正在进行【吉布斯自由能 & 熵】深度分析: {input_file}")
    
    data = []
    with open(input_file, 'r', encoding='utf-8') as f:
        for line in f:
            if not line.strip(): continue
            try:
                item = json.loads(line)
                
                # 获取原始数据
                m = np.array(item['mass'])
                ek = np.array(item['kinetic_energy'])
                u = np.array(item['internal_energy'])
                # 需要用到角度来计算熵 (假设 item 里有 angle2，即微观角度)
                # 如果没有，用 velocity 的波动代替
                # v_micro_est = v_macro + sqrt(2U/m)
                
                if len(m) < 10: continue
                epsilon = 1e-6
                
                # 截取最关键的"决断期" (最后 20%)
                idx_start = int(len(m) * 0.8)
                
                seg_m = m[idx_start:]
                seg_ek = ek[idx_start:]
                seg_u = u[idx_start:]
                
                # === 1. 计算思维熵 (Cognitive Entropy, S) ===
                # 定义：内能的波动率 (Volatility of Internal Energy)
                # 错误思维的特征：内耗忽大忽小（犹豫不决/瞎猜）
                # 正确思维的特征：内耗维持在一个高位但稳定的水平（持续计算）
                
                # S = std(U) / mean(U)  (变异系数)
                # 为了放大差异，乘以 1/Mass (质量越小越混乱)
                entropy = (np.std(seg_u) / (np.mean(seg_u) + epsilon)) / (np.mean(seg_m) + epsilon)
                
                # === 2. 计算焓 (Enthalpy, H) ===
                # H = U + pV (这里简化为总能量 Density)
                # 正确思维通常具有极高的能量密度
                enthalpy = np.mean(seg_u + seg_ek)
                
                # === 3. 计算吉布斯自由能 (Gibbs Free Energy, G) ===
                # G = H / S (这里做除法而不是减法，是为了无量纲化处理)
                # 物理含义：单位混乱度下的能量密度
                # 越高越好：能量极大，但混乱极小
                gibbs_energy = enthalpy / (entropy + epsilon)
                
                # === 4. 对照组：简单的能量密度 ===
                energy_density = np.mean(seg_u)

                data.append({
                    "Label": 1 if item.get('is_correct') else 0,
                    "Entropy (S)": entropy,
                    "Enthalpy (H)": enthalpy,
                    "Gibbs Energy (G)": np.log10(gibbs_energy + 1), # 取对数平滑
                    "Is_Correct": "Correct" if item.get('is_correct') else "Incorrect"
                })
            except Exception as e:
                continue
            
    df = pd.DataFrame(data)
    
    # === 统计验证 ===
    print("\n📊 热力学指标区分度 (AUC):")
    
    # 熵应该越小越好 (反向指标，所以 AUC < 0.5 是好的，或者 1-AUC)
    auc_s = roc_auc_score(df['Label'], df['Entropy (S)'])
    # 修正 AUC 方向，使其 > 0.5 表示区分度
    auc_s_corrected = auc_s if auc_s > 0.5 else 1 - auc_s
    
    auc_h = roc_auc_score(df['Label'], df['Enthalpy (H)'])
    auc_g = roc_auc_score(df['Label'], df['Gibbs Energy (G)'])
    
    print(f"  - 思维熵 (S) [越低越好]:      {auc_s_corrected:.4f} ({auc_s:.4f})")
    print(f"  - 总能量/焓 (H) [越高越好]:   {auc_h:.4f}")
    print(f"  - 吉布斯自由能 (G=H/S):     {auc_g:.4f} (⭐⭐ 核心预测 ⭐⭐)")
    
    # === 绘制相图 ===
    plt.figure(figsize=(10, 8))
    
    # X轴：熵 (混乱度)
    # Y轴：焓 (能量强度)
    sns.scatterplot(
        data=df,
        x="Entropy (S)",
        y="Enthalpy (H)",
        hue="Is_Correct",
        style="Is_Correct",
        s=150,
        palette={"Correct": "#006400", "Incorrect": "#DC143C"}, # 深绿 vs 深红
        alpha=0.8
    )
    
    plt.yscale('log') # 能量通常跨度大
    # plt.xscale('log') # 熵也可能跨度大
    
    plt.title("The 'Gibbs Free Energy' Phase Diagram\n(Order vs. Intensity)", fontsize=14, fontweight='bold')
    plt.xlabel("Cognitive Entropy ($S$)\n(Volatility/Chaos $\\rightarrow$ Lower is Better)", fontsize=12)
    plt.ylabel("Cognitive Enthalpy ($H$)\n(Total Energy Density $\\rightarrow$ Higher is Better)", fontsize=12)
    
    # 标注理想区域
    # 理想是：左上角 (低熵，高能)
    plt.text(df["Entropy (S)"].min(), df["Enthalpy (H)"].max(), 
             "CRYSTAL TRUTH ZONE\n(Low Entropy, High Energy)", ha='left', va='top', fontsize=12, fontweight='bold', color='green')
    
    plt.grid(True, linestyle='--', alpha=0.5)
    plt.tight_layout()
    
    plt.savefig("gibbs_energy_phase.png", dpi=300)
    print(f"\n🖼️ 吉布斯相图已生成: gibbs_energy_phase.png")
    
    return df

if __name__ == "__main__":
    analyze_gibbs_free_energy("energy_collect.jsonl")