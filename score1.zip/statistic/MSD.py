import json
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import os

def analyze_absolute_manifold_msd(input_file="metrics.jsonl", num_steps=100):
    print("🔬 启动动力学升维：积分还原绝对流形，计算真实空间均方位移 (MSD)...")
    
    if not os.path.exists(input_file):
        print(f"❌ 文件 {input_file} 不存在。")
        return

    # 存储重采样后的绝对位移平方轨迹
    C_msd_trajectories = []
    I_msd_trajectories = []
    
    with open(input_file, 'r', encoding='utf-8') as f:
        for line in f:
            if not line.strip(): continue
            try:
                item = json.loads(line)
                d1 = item.get('diff norm1', item.get('diff norms1'))
                d2 = item.get('diff norm2', item.get('diff norms2'))
                a1 = item.get('angle1')
                a2 = item.get('angle2')
                
                if not (d1 and d2 and a1 and a2): continue
                
                # 1. 提取局部梯度 (速度场)
                fric_vel = np.array(d2) - np.array(d1)
                incoh_vel = np.array(a2) - np.array(a1)
                
                if len(fric_vel) < 10: continue
                
                # ================= 核心修正：时间积分 =================
                # 2. 将速度场积分 (累加求和)，还原为相空间中的绝对物理坐标
                fric_pos = np.cumsum(fric_vel)
                incoh_pos = np.cumsum(incoh_vel)
                # ======================================================
                
                # 3. 长度归一化：将任意长度的轨迹重采样到 0-100 的标准化时间轴上
                orig_time = np.linspace(0, 1, len(fric_pos))
                norm_time = np.linspace(0, 1, num_steps)
                
                f_interp = np.interp(norm_time, orig_time, fric_pos)
                i_interp = np.interp(norm_time, orig_time, incoh_pos)
                
                # 4. 计算每一时刻距离起始点 X(0) 的真实空间位移平方
                f_0, i_0 = f_interp[0], i_interp[0]
                sd_t = (f_interp - f_0)**2 + (i_interp - i_0)**2
                
                is_correct = item.get('is_correct', False)
                if is_correct:
                    C_msd_trajectories.append(sd_t)
                else:
                    I_msd_trajectories.append(sd_t)
                    
            except Exception as e:
                continue

    # 转化为 Numpy 矩阵方便列级计算 (Shape: [N_trajectories, num_steps])
    C_msd_matrix = np.array(C_msd_trajectories)
    I_msd_matrix = np.array(I_msd_trajectories)
    
    if len(C_msd_matrix) == 0 or len(I_msd_matrix) == 0:
        print("❌ 解析到的有效轨迹不足。")
        return

    # 计算系综平均均方位移 (MSD) 和 标准误差 (SEM)
    time_axis = np.linspace(0, 100, num_steps)
    
    C_msd_mean = np.mean(C_msd_matrix, axis=0)
    C_msd_sem = np.std(C_msd_matrix, axis=0) / np.sqrt(len(C_msd_matrix))
    
    I_msd_mean = np.mean(I_msd_matrix, axis=0)
    I_msd_sem = np.std(I_msd_matrix, axis=0) / np.sqrt(len(I_msd_matrix))

    # ================= 绘图 =================
    sns.set_style("whitegrid")
    fig, ax = plt.subplots(figsize=(11, 7))
    fig.suptitle("Absolute Manifold Dynamics: Mean Squared Displacement (Integral Corrected)", fontsize=16, fontweight='bold', y=0.96)
    ax.set_title("Revealing the true macroscopic divergence between correct reasoning and hallucination", fontsize=12, color='dimgray', pad=15)
    
    ax.set_xlabel("Normalized Generation Progress (%)", fontsize=12)
    ax.set_ylabel(r"Cumulative Mean Squared Displacement $\langle ||\int V(t) dt||^2 \rangle$", fontsize=12)

    # 绘制错误推理 (无界发散) - 红色
    ax.plot(time_axis, I_msd_mean, color='#D62728', linewidth=3.5, label='Incorrect Path (Unbounded Divergence)')
    ax.fill_between(time_axis, I_msd_mean - I_msd_sem, I_msd_mean + I_msd_sem, color='#D62728', alpha=0.15)

    # 绘制正确推理 (有界膨胀) - 蓝色
    ax.plot(time_axis, C_msd_mean, color='#1F77B4', linewidth=3.5, label='Correct Path (Bounded Expansion / Plateau)')
    ax.fill_between(time_axis, C_msd_mean - C_msd_sem, C_msd_mean + C_msd_sem, color='#1F77B4', alpha=0.2)

    # --- 添加物理学参考辅助线 ---
    ref_idx = int(num_steps * 0.2)
    ref_t = time_axis[ref_idx:]
    
    # 理论抛物线发散参考
    scale_factor = I_msd_mean[ref_idx] / (ref_t[0]**1.5 + 1e-5)
    ideal_divergence = scale_factor * (ref_t**1.5)
    ax.plot(ref_t, ideal_divergence, color='darkred', linestyle=':', linewidth=2, alpha=0.6, label=r'Theoretical Super-diffusion')
    
    # 获取蓝色渐近线高度
    plateau_height = np.mean(C_msd_mean[-int(num_steps*0.3):])
    ax.axhline(y=plateau_height, color='navy', linestyle='--', linewidth=2, alpha=0.6, label=r'Logical Confinement Limit')

    # 图表细节修饰
    ax.set_xlim(0, 100)
    ax.set_ylim(bottom=0)
    
    # 动态调整 Y 轴上限，防止极值把主体曲线压扁
    max_y = max(np.max(I_msd_mean), np.max(C_msd_mean))
    ax.set_ylim(0, max_y * 1.1)

    ax.legend(loc='upper left', fontsize=11, frameon=True, shadow=True)
    
    # 文本高亮框
    props = dict(boxstyle='round,pad=0.5', facecolor='white', alpha=0.9, edgecolor='lightgray')
    ax.text(55, plateau_height * 1.3, "Strong Restoring Force\nTrajectory trapped in 'Correct Well'", color='#08519C', fontsize=11, fontweight='bold', ha='center', va='bottom', bbox=props)
    
    ax.text(85, max_y * 0.85, "Loss of Confinement\nCatastrophic Hallucination Escape", color='#A50F15', fontsize=11, fontweight='bold', ha='center', va='center', bbox=props)

    plt.tight_layout(rect=[0, 0, 1, 0.95])
    output_filename = "Absolute_Manifold_MSD.png"
    plt.savefig(output_filename, dpi=300)
    print(f"\n🖼️ 积分重构完毕！绝对流形动力学图表已保存为 {output_filename}")
    
    # 终端输出关键数据点比对
    print("\n📊 终点态 (t=100%) 绝对 MSD 数据比对:")
    print(f"✅ 正确推理终端绝对散布范围: {C_msd_mean[-1]:.2f}")
    print(f"❌ 错误推理终端绝对散布范围: {I_msd_mean[-1]:.2f}")
    ratio = I_msd_mean[-1] / C_msd_mean[-1] if C_msd_mean[-1] > 0 else float('inf')
    print(f"💡 结论: 错误推理在宏观语义空间中的漂移发散量是正确推理的 {ratio:.1f} 倍！")

if __name__ == "__main__":
    analyze_absolute_manifold_msd("metrics.jsonl")