import json
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import PolynomialFeatures
from sklearn.pipeline import make_pipeline
import argparse
import os
import pandas as pd

def plot_normalized_phase_separation(input_file, output_file="Normalized_Phase_Heatmap.png"):
    # 强制检查：只接受 metrics.jsonl 或用户指定的文件
    print(f"⚖️ [配置已锁定] 正在读取物理指标文件: {input_file}")
    print("   (已移除对 final_training_data.jsonl 的所有依赖)")
    
    if not os.path.exists(input_file):
        print(f"❌ 错误: 文件 {input_file} 不存在。请确保当前目录下有 metrics.jsonl。")
        return

    data_points = []
    
    with open(input_file, 'r', encoding='utf-8') as f:
        for line_idx, line in enumerate(f, 1):
            if not line.strip(): continue
            try:
                item = json.loads(line)
                
                # 获取必要字段
                a1 = item.get('angle1')
                a2 = item.get('angle2')
                d1 = item.get('diff norms1') or item.get('diff norm1')
                is_correct = item.get('is_correct')
                
                if a1 is None or a2 is None or d1 is None or is_correct is None:
                    continue
                
                # 转numpy
                angle1 = np.array(a1, dtype=float)
                angle2 = np.array(a2, dtype=float)
                velocity = np.array(d1, dtype=float)
                
                # 长度对齐
                min_len = min(len(angle1), len(angle2), len(velocity))
                if min_len < 5: continue 
                
                angle1 = angle1[:min_len]
                angle2 = angle2[:min_len]
                velocity = velocity[:min_len]
                
                # === 计算最后 10% 的指标 ===
                start_idx = int(min_len * 0.9)
                if start_idx >= min_len: start_idx = min_len - 1
                if min_len - start_idx < 1: start_idx = max(0, min_len - 5)
                
                # 1. 质量 (Mass) 基于纯不一致性 |angle2 - angle1|
                seg_a1 = angle1[start_idx:]
                seg_a2 = angle2[start_idx:]
                epsilon = 1e-6
                
                incoherence_pure = np.abs(seg_a2 - seg_a1)
                mass_seq = 1.0 / (incoherence_pure + epsilon)
                mean_mass = np.mean(mass_seq)
                
                # 2. 速度 (Velocity) 基于 diff norms1
                seg_v = velocity[start_idx:]
                mean_velocity = np.mean(seg_v)
                
                data_points.append({
                    "Raw_Mass": mean_mass,
                    "Raw_Velocity": mean_velocity,
                    "Label": 1 if is_correct else 0
                })
                
            except Exception as e:
                continue
    
    if not data_points:
        print("❌ 未提取到有效数据。请检查 metrics.jsonl 内容格式。")
        return

    df = pd.DataFrame(data_points)
    print(f"✅ 成功提取样本数: {len(df)}")
    
    # === 归一化 (Min-Max Normalization) ===
    # 1. Clipping (1%-99%) 去除极端异常值
    v_min, v_max_cap = df["Raw_Velocity"].quantile([0.01, 0.99])
    m_min, m_max_cap = df["Raw_Mass"].quantile([0.01, 0.99])
    
    df["Clipped_Velocity"] = df["Raw_Velocity"].clip(v_min, v_max_cap)
    df["Clipped_Mass"] = df["Raw_Mass"].clip(m_min, m_max_cap)
    
    # 2. Scaling to [0, 1]
    df["Norm_Velocity"] = (df["Clipped_Velocity"] - df["Clipped_Velocity"].min()) / (df["Clipped_Velocity"].max() - df["Clipped_Velocity"].min())
    df["Norm_Mass"] = (df["Clipped_Mass"] - df["Clipped_Mass"].min()) / (df["Clipped_Mass"].max() - df["Clipped_Mass"].min())
    
    print("✅ 数据已完成归一化 (Min-Max Scaling to [0, 1])")
    
    # === 绘制相图 ===
    X = df[["Norm_Velocity", "Norm_Mass"]].values
    y = df["Label"].values
    
    # 训练逻辑回归分类器用于绘制平滑的概率背景
    model = make_pipeline(
        PolynomialFeatures(degree=3, include_bias=False),
        LogisticRegression(C=10.0, max_iter=2000)
    )
    model.fit(X, y)
    acc = model.score(X, y)
    print(f"🎯 归一化后相分离准确率: {acc:.2%}")

    # 绘图
    sns.set_style("whitegrid")
    plt.figure(figsize=(12, 10))
    
    # 创建网格 [0, 1] x [0, 1]
    xx, yy = np.meshgrid(np.linspace(0, 1, 200), np.linspace(0, 1, 200))
    Z = model.predict_proba(np.c_[xx.ravel(), yy.ravel()])[:, 1]
    Z = Z.reshape(xx.shape)
    
    # 1. 热力图
    contour = plt.contourf(xx, yy, Z, levels=20, cmap="RdBu", alpha=0.7)
    cbar = plt.colorbar(contour)
    cbar.set_label("Probability of Correctness $P(Correct)$", fontsize=12)
    
    # 2. 决策边界
    plt.contour(xx, yy, Z, levels=[0.5], colors='black', linewidths=2.5, linestyles='--')
    
    # 3. 散点 (带透明度)
    mask_correct = (y == 1)
    plt.scatter(X[mask_correct, 0], X[mask_correct, 1],
                c='lime', edgecolors='black', s=60, alpha=0.6, label='Correct (High Quality)')
    
    mask_incorrect = (y == 0)
    plt.scatter(X[mask_incorrect, 0], X[mask_incorrect, 1],
                c='red', edgecolors='black', s=60, marker='X', alpha=0.6, label='Incorrect (Low Quality)')
    
    # 标题与坐标
    plt.title("Normalized Thermodynamic Phase Diagram (Based on metrics.jsonl)", fontsize=16, fontweight='bold', pad=20)
    plt.xlabel(r"Normalized Velocity ($v_{norm}$) $\rightarrow$ Speed", fontsize=14, fontweight='bold')
    plt.ylabel(r"Normalized Structural Mass ($m_{norm}$) $\rightarrow$ Quality", fontsize=14, fontweight='bold')
    
    # 添加区域注释
    plt.text(0.15, 0.15, "Low Mass / Slow\n(Stagnation)", ha='center', fontsize=11, fontweight='bold', bbox=dict(facecolor='white', alpha=0.8))
    plt.text(0.85, 0.85, "High Mass / Fast\n(Flow State)", ha='center', fontsize=11, fontweight='bold', bbox=dict(facecolor='white', alpha=0.8))

    plt.legend(loc='lower right', framealpha=0.9, fontsize=12)
    plt.xlim(0, 1)
    plt.ylim(0, 1)
    plt.tight_layout()
    
    plt.savefig(output_file, dpi=300)
    print(f"🖼️ 归一化相图已生成: {output_file}")

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    # 默认值修改为 metrics.jsonl
    parser.add_argument("--input_file", type=str, default="metrics.jsonl")
    args = parser.parse_args()
    
    plot_normalized_phase_separation(args.input_file)