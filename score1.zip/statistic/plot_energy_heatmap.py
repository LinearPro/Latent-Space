import json
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import PolynomialFeatures
from sklearn.pipeline import make_pipeline
import argparse
import os
import pandas as pd

def plot_energy_phase_heatmap(input_file, output_file="Energy_Phase_Heatmap.png"):
    print(f"🌡️ 正在绘制能量相分离热力图: {input_file}")
    print("   X轴: 平均动能 (Mean Kinetic Energy)")
    print("   Y轴: 最后10%内能 (Late-Stage Internal Energy)")
    
    if not os.path.exists(input_file):
        print(f"❌ 错误: 文件 {input_file} 不存在。")
        return

    data_points = []
    
    with open(input_file, 'r', encoding='utf-8') as f:
        for line_idx, line in enumerate(f, 1):
            if not line.strip(): continue
            try:
                item = json.loads(line)
                
                # 获取字段
                is_correct = item.get('is_correct')
                ek_seq = item.get('kinetic_energy')
                u_seq = item.get('internal_energy')
                
                if is_correct is None or not ek_seq or not u_seq:
                    continue
                
                # 转 numpy
                ek_arr = np.array(ek_seq, dtype=float)
                u_arr = np.array(u_seq, dtype=float)
                
                seq_len = len(ek_arr)
                if seq_len < 5: continue 
                
                # === 1. 计算 X轴: 平均动能 (全过程) ===
                mean_ek = np.mean(ek_arr)
                
                # === 2. 计算 Y轴: 最后 10% 内能 (收敛阶段) ===
                start_idx = int(seq_len * 0.9)
                if start_idx >= seq_len: start_idx = seq_len - 1
                if seq_len - start_idx < 1: start_idx = max(0, seq_len - 5)
                
                late_u = np.mean(u_arr[start_idx:])
                
                data_points.append({
                    "Raw_Ek": mean_ek,
                    "Raw_U_Late": late_u,
                    "Label": 1 if is_correct else 0
                })
                
            except Exception as e:
                continue
    
    if not data_points:
        print("❌ 未提取到有效数据。")
        return

    df = pd.DataFrame(data_points)
    print(f"✅ 成功提取样本数: {len(df)}")
    print(f"   Correct: {len(df[df['Label']==1])}, Incorrect: {len(df[df['Label']==0])}")
    
    # === 归一化 (Min-Max Normalization with Clipping) ===
    # 为了防止能量值的长尾分布破坏绘图，先截断两端 1%
    
    # 1. 动能 (X轴)
    ek_min, ek_max_cap = df["Raw_Ek"].quantile([0.01, 0.99])
    df["Clipped_Ek"] = df["Raw_Ek"].clip(ek_min, ek_max_cap)
    
    # 2. 内能 (Y轴)
    u_min, u_max_cap = df["Raw_U_Late"].quantile([0.01, 0.99])
    df["Clipped_U"] = df["Raw_U_Late"].clip(u_min, u_max_cap)
    
    # 3. 归一化到 [0, 1]
    df["Norm_Ek"] = (df["Clipped_Ek"] - df["Clipped_Ek"].min()) / (df["Clipped_Ek"].max() - df["Clipped_Ek"].min())
    df["Norm_U"] = (df["Clipped_U"] - df["Clipped_U"].min()) / (df["Clipped_U"].max() - df["Clipped_U"].min())
    
    print("✅ 数据归一化完成")
    
    # === 绘制相图 ===
    X = df[["Norm_Ek", "Norm_U"]].values
    y = df["Label"].values
    
    # 拟合背景热力图 (Decision Boundary)
    model = make_pipeline(
        PolynomialFeatures(degree=3, include_bias=False),
        LogisticRegression(C=10.0, max_iter=2000)
    )
    model.fit(X, y)
    acc = model.score(X, y)
    print(f"🎯 相分离分类准确率: {acc:.2%}")

    # 绘图设置
    sns.set_style("whitegrid")
    plt.figure(figsize=(12, 10))
    
    # 创建网格
    xx, yy = np.meshgrid(np.linspace(0, 1, 200), np.linspace(0, 1, 200))
    Z = model.predict_proba(np.c_[xx.ravel(), yy.ravel()])[:, 1]
    Z = Z.reshape(xx.shape)
    
    # 1. 热力图
    contour = plt.contourf(xx, yy, Z, levels=20, cmap="RdBu", alpha=0.7)
    cbar = plt.colorbar(contour)
    cbar.set_label("Probability of Correctness $P(Correct)$", fontsize=12)
    
    # 2. 决策边界 (50% 概率线)
    plt.contour(xx, yy, Z, levels=[0.5], colors='black', linewidths=2.5, linestyles='--')
    
    # 3. 散点
    # Correct
    mask_correct = (y == 1)
    plt.scatter(X[mask_correct, 0], X[mask_correct, 1],
                c='lime', edgecolors='black', s=50, alpha=0.6, label='Correct')
    
    # Incorrect
    mask_incorrect = (y == 0)
    plt.scatter(X[mask_incorrect, 0], X[mask_incorrect, 1],
                c='red', edgecolors='black', s=50, marker='X', alpha=0.6, label='Incorrect')
    
    # 标题与标签
    plt.title("Thermodynamics: Mean Kinetic Energy vs. Late-Stage Internal Energy", fontsize=16, fontweight='bold', pad=20)
    plt.xlabel(r"Normalized Mean Kinetic Energy ($\bar{E}_{k}$) $\rightarrow$ Drive", fontsize=14, fontweight='bold')
    plt.ylabel(r"Normalized Late-Stage Internal Energy ($U_{final}$) $\rightarrow$ Rigor/Struggle", fontsize=14, fontweight='bold')
    
    # 物理意义注释
    plt.text(0.9, 0.9, "High Drive / High Rigor\n(Proof Phase)", ha='center', fontsize=11, fontweight='bold', bbox=dict(facecolor='white', alpha=0.7))
    plt.text(0.1, 0.1, "Low Drive / Low Rigor\n(Giving Up)", ha='center', fontsize=11, fontweight='bold', bbox=dict(facecolor='white', alpha=0.7))

    plt.legend(loc='lower right', framealpha=0.9, fontsize=12)
    plt.xlim(0, 1)
    plt.ylim(0, 1)
    plt.tight_layout()
    
    plt.savefig(output_file, dpi=300)
    print(f"🖼️ 能量相分离热力图已生成: {output_file}")

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    # 默认读取 energy_collect.jsonl
    parser.add_argument("--input_file", type=str, default="energy_collect.jsonl")
    args = parser.parse_args()
    
    plot_energy_phase_heatmap(args.input_file)